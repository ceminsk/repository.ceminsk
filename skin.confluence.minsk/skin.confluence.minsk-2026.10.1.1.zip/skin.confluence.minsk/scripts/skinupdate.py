import os
import re
import json
import time
import shutil
import tempfile
import sys
from urllib.request import Request, urlopen
import xbmc
import xbmcgui
import xbmcvfs
import base64
import traceback
import zipfile
import ssl

SKIN_ADDON_ID = "skin.confluence.minsk"
TOTAL_EXPECTED_SIZE = 27 * 1024 * 1024

IS_ANDROID = xbmc.getCondVisibility("System.Platform.Android")

if IS_ANDROID:
    DOWNLOAD_DIR = xbmcvfs.translatePath("special://home/downloads/")
    CACHE_DIR = xbmcvfs.translatePath("special://temp/")
else:
    DOWNLOAD_DIR = "/storage/downloads/"
    CACHE_DIR = tempfile.gettempdir()

DEBUG_ARCHIVE_DIR = os.path.join(DOWNLOAD_DIR, "skin_update_debug")

# 模拟 Chrome 浏览器的完整 Headers
BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
}

def init_directories():
    try:
        if IS_ANDROID:
            if not xbmcvfs.exists(DOWNLOAD_DIR):
                xbmcvfs.mkdirs(DOWNLOAD_DIR)
            if not xbmcvfs.exists(DEBUG_ARCHIVE_DIR):
                xbmcvfs.mkdirs(DEBUG_ARCHIVE_DIR)
            if not xbmcvfs.exists(CACHE_DIR):
                xbmcvfs.mkdirs(CACHE_DIR)
        else:
            if not os.path.exists(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR, exist_ok=True)
            if not os.path.exists(DEBUG_ARCHIVE_DIR):
                os.makedirs(DEBUG_ARCHIVE_DIR, exist_ok=True)
            if not os.path.exists(CACHE_DIR):
                os.makedirs(CACHE_DIR, exist_ok=True)
    except Exception as e:
        xbmc.log(f"[Skin Update] 初始化目录失败: {str(e)}, 异常详情: {traceback.format_exc()}", xbmc.LOGERROR)

init_directories()

def decode_base64_url(encoded_url):
    try:
        padding = 4 - len(encoded_url) % 4
        if padding != 4:
            encoded_url += '=' * padding
        decoded_bytes = base64.b64decode(encoded_url)
        decoded_url = decoded_bytes.decode('utf-8')
        return decoded_url
    except Exception as e:
        xbmc.log(f"[Skin Update] Base64解码失败: {encoded_url[:20]}..., 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return None

PRIMARY_VER_URL = "aHR0cHM6Ly9naXRlZS5jb20vY2UtZmFucy9taW5zay1za2luL3Jhdy9tYXN0ZXIvbWluc2stc2tpbi92ZXJzaW9ubmV3LnR4dA=="
BACKUP_VER_BASE_URL = "aHR0cHM6Ly9naC1wcm94eS5vcmcvaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2NlbWluc2svcmVwb3NpdG9yeS5jZW1pbnNrL21hc3Rlci9za2luLmNvbmZsdWVuY2UubWluc2svdmVyc2lvbm5ldy50eHQ="

PRIMARY_DL_PRE_URL = "aHR0cHM6Ly9naXRlZS5jb20vY2UtZmFucy9taW5zay1za2luL3Jhdy9tYXN0ZXIvbWluc2stc2tpbi9za2luLmNvbmZsdWVuY2UubWluc2st"
BACKUP_DL_PRE_URL = "aHR0cHM6Ly9naC1wcm94eS5vcmcvaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2NlbWluc2svcmVwb3NpdG9yeS5jZW1pbnNrL21hc3Rlci9za2luLmNvbmZsdWVuY2UubWluc2svc2tpbi5jb25mbHVlbmNlLm1pbnNrLQ=="

DL_BASE_SUFFIX = ".zip"
SPLIT_SUFFIXES = ["001", "002", "003"]

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
SKIN_DIR = os.path.join(ADDONS_DIR, SKIN_ADDON_ID)

def clean_up_files(file_list):
    for file_path in file_list:
        try:
            if IS_ANDROID:
                if xbmcvfs.exists(file_path):
                    try:
                        stat_obj = xbmcvfs.Stat(file_path)
                        try:
                            mode = stat_obj.st_mode()
                        except AttributeError:
                            try:
                                file_obj = xbmcvfs.File(file_path)
                                data = file_obj.read(1)
                                if data is not None:
                                    xbmcvfs.delete(file_path)
                                else:
                                    try:
                                        if os.path.exists(file_path) and os.path.isdir(file_path):
                                            shutil.rmtree(file_path, ignore_errors=True)
                                    except:
                                        pass
                                    try:
                                        xbmcvfs.rmdir(file_path, force=True)
                                    except:
                                        pass
                                file_obj.close()
                            except:
                                try:
                                    xbmcvfs.delete(file_path)
                                except:
                                    try:
                                        if os.path.exists(file_path) and os.path.isdir(file_path):
                                            shutil.rmtree(file_path, ignore_errors=True)
                                    except:
                                        pass
                                    try:
                                        xbmcvfs.rmdir(file_path, force=True)
                                    except:
                                        pass
                        else:
                            import stat
                            if stat.S_ISDIR(mode):
                                try:
                                    if os.path.exists(file_path) and os.path.isdir(file_path):
                                        shutil.rmtree(file_path, ignore_errors=True)
                                except:
                                    pass
                                try:
                                    xbmcvfs.rmdir(file_path, force=True)
                                except:
                                    pass
                            else:
                                xbmcvfs.delete(file_path)
                    except:
                        try:
                            xbmcvfs.delete(file_path)
                        except:
                            try:
                                if os.path.exists(file_path) and os.path.isdir(file_path):
                                    shutil.rmtree(file_path, ignore_errors=True)
                            except:
                                pass
                            try:
                                xbmcvfs.rmdir(file_path, force=True)
                            except:
                                pass
            else:
                if os.path.exists(file_path):
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path, ignore_errors=True)
        except Exception as e:
            xbmc.log(f"[Skin Update] 清理文件失败: {file_path}, 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGWARNING)

def get_current_skin_version():
    try:
        rpc_request = {
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {"addonid": SKIN_ADDON_ID, "properties": ["version"]},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(rpc_request))
        result = json.loads(response)
        if "result" in result and "addon" in result["result"]:
            return result["result"]["addon"]["version"]
        return None
    except Exception as e:
        xbmc.log(f"[Skin Update] 获取当前皮肤版本失败: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return None

def get_versions_from_url(encoded_url, add_timestamp=False):
    try:
        url = decode_base64_url(encoded_url)
        if not url:
            xbmc.log(f"[Skin Update] 无法解码URL: {encoded_url[:20]}...", xbmc.LOGERROR)
            return None
            
        if add_timestamp:
            timestamp = int(time.time())
            separator = '&' if '?' in url else '?'
            url = f"{url}{separator}t={timestamp}"
            
        req = Request(url, headers=BROWSER_HEADERS)
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
        
        with urlopen(req, timeout=3, context=ctx) as response:
            raw_content = response.read()
            try:
                content = raw_content.decode('utf-8').strip()
            except UnicodeDecodeError:
                xbmc.log(f"[Skin Update] UTF-8解码失败，尝试备用解码方式", xbmc.LOGWARNING)
                try:
                    content = raw_content.decode('latin-1').strip()
                except:
                    content = raw_content.decode('utf-8', errors='ignore').strip()

            versions = []
            for line in content.splitlines():
                line = line.strip()
                if re.match(r'^\d+\.\d+\.\d+\.\d+$', line) or re.match(r'^\d+\.\d+\.\d+$', line):
                    versions.append(line)
            if versions:
                xbmc.log(f"[Skin Update] 从URL获取到版本: {versions}", xbmc.LOGINFO)
                return versions
        return None
    except Exception as e:
        xbmc.log(f"[Skin Update] 从URL获取版本失败: {encoded_url[:20]}..., 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return None

def get_remote_versions_with_retry():
    max_retries = 2
    retry_delay = 10
    
    for attempt in range(max_retries):
        xbmc.log(f"[Skin Update] 尝试获取远程版本 (第 {attempt+1} 次)", xbmc.LOGINFO)
        primary_versions = get_versions_from_url(PRIMARY_VER_URL)
        if primary_versions:
            xbmc.log(f"[Skin Update] 成功从主源获取版本: {primary_versions}", xbmc.LOGINFO)
            return primary_versions, "primary"

        xbmc.log(f"[Skin Update] 主源获取失败，尝试备份源", xbmc.LOGINFO)
        backup_versions = get_versions_from_url(BACKUP_VER_BASE_URL, add_timestamp=True)
        if backup_versions:
            xbmc.log(f"[Skin Update] 成功从备份源获取版本: {backup_versions}", xbmc.LOGINFO)
            return backup_versions, "backup"

        if attempt < max_retries - 1:
            xbmc.log(f"[Skin Update] 等待 {retry_delay} 秒后重试", xbmc.LOGINFO)
            time.sleep(retry_delay)

    xbmc.log("[Skin Update] 所有版本获取尝试均失败", xbmc.LOGERROR)
    return None, None

def get_latest_version(versions):
    if not versions:
        xbmc.log("[Skin Update] 版本列表为空，无法获取最新版本", xbmc.LOGWARNING)
        return None
    latest = versions[0]
    for ver in versions[1:]:
        if compare_versions(ver, latest) > 0:
            latest = ver
    xbmc.log(f"[Skin Update] 最新版本: {latest}", xbmc.LOGINFO)
    return latest

def get_download_info(version, source_type):
    """
    根据源类型返回下载信息。
    Primary: 返回分片URL列表
    Backup: 返回单个完整ZIP的URL
    """
    encoded_base_url = PRIMARY_DL_PRE_URL if source_type == "primary" else BACKUP_DL_PRE_URL
    base_url = decode_base64_url(encoded_base_url)
    if not base_url:
        xbmc.log(f"[Skin Update] 无法解码基础URL: {encoded_base_url[:20]}...", xbmc.LOGERROR)
        return None
        
    if source_type == "backup":
        full_url = f"{base_url}{version}{DL_BASE_SUFFIX}"
        xbmc.log(f"[Skin Update] 构造备份源完整ZIP URL: {full_url}", xbmc.LOGINFO)
        return {"type": "single", "urls": [full_url], "source": "backup"}
    else:
        base_filename = f"{base_url}{version}{DL_BASE_SUFFIX}"
        split_urls = []
        for suffix in SPLIT_SUFFIXES:
            url = f"{base_filename}.{suffix}"
            split_urls.append(url)
        xbmc.log(f"[Skin Update] 构造的主源分片URLs: {split_urls}", xbmc.LOGINFO)
        return {"type": "split", "urls": split_urls, "source": "primary"}

def get_backup_download_info(version):
    """专门用于故障转移时获取备用源信息"""
    return get_download_info(version, "backup")

def compare_versions(ver1, ver2):
    try:
        v1 = [int(p) for p in ver1.split('.')]
        v2 = [int(p) for p in ver2.split('.')]
        for i in range(max(len(v1), len(v2))):
            num1 = v1[i] if i < len(v1) else 0
            num2 = v2[i] if i < len(v2) else 0
            if num1 > num2:
                return 1
            elif num1 < num2:
                return -1
        return 0
    except Exception as e:
        xbmc.log(f"[Skin Update] 版本比较失败: {ver1} vs {ver2}, 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return None

def download_file(url, save_path, dialog, total_expected_size, current_total_downloaded):
    """Helper function to download a single file"""
    ctx = ssl.create_default_context()
    download_headers = {
        'User-Agent': BROWSER_HEADERS['User-Agent'],
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }
    req = Request(url, headers=download_headers)
    
    downloaded_size = 0
    try:
        with urlopen(req, timeout=30, context=ctx) as response:
            content_length = int(response.headers.get("Content-Length", 0))
            
            with open(save_path, "wb") as out_file:
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    out_file.write(chunk)
                    downloaded_size += len(chunk)
                    
                    if total_expected_size > 0:
                        percent = min(int(((current_total_downloaded + downloaded_size) / total_expected_size) * 100), 100)
                    else:
                        percent = int((downloaded_size / content_length) * 100) if content_length > 0 else 0
                        
                    dialog.update(percent, f"下载中... {percent}%")
                    
                    if dialog.iscanceled():
                        dialog.close()
                        xbmcgui.Dialog().ok("下载取消", "您已取消下载。")
                        raise Exception("DownloadCancelled")

        xbmc.log(f"[Skin Update] 下载完成: {save_path}, 大小: {downloaded_size} 字节", xbmc.LOGINFO)
        return downloaded_size
    except Exception as e:
        if str(e) == "DownloadCancelled":
            raise e
        xbmc.log(f"[Skin Update] 下载失败: {url}, 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        if os.path.exists(save_path):
            try:
                os.remove(save_path)
            except:
                pass
        # Re-raise the exception so the caller knows it failed
        raise e

def download_all_parts(download_info, version, download_dir):
    """
    下载文件。支持单文件(zip)或分片文件。
    包含故障转移逻辑：如果主源失败，自动切换到备用源。
    """
    try:
        if IS_ANDROID:
            if not xbmcvfs.exists(download_dir):
                xbmcvfs.mkdirs(download_dir)
        else:
            os.makedirs(download_dir, exist_ok=True)
        
        urls = download_info['urls']
        dl_type = download_info['type']
        current_source = download_info.get('source', 'primary')
        
        downloaded_files = []
        total_downloaded_bytes = 0
        
        dialog = xbmcgui.DialogProgress()
        dialog.create("皮肤更新", f"准备下载...")
        
        # 标记是否已经尝试过故障转移
        failover_attempted = False

        try:
            for i, url in enumerate(urls, 1):
                filename = os.path.basename(url)
                save_path = os.path.join(download_dir, filename)
                
                xbmc.log(f"[Skin Update] 开始下载 ({i}/{len(urls)}): {url}", xbmc.LOGINFO)
                
                try:
                    size = download_file(url, save_path, dialog, TOTAL_EXPECTED_SIZE, total_downloaded_bytes)
                    if size == 0:
                         raise Exception("Download returned 0 bytes")
                    
                    total_downloaded_bytes += size
                    downloaded_files.append(save_path)
                    
                except Exception as e:
                    if str(e) == "DownloadCancelled":
                        raise e
                    
                    # 如果是主源且尚未尝试故障转移，则切换
                    if current_source == "primary" and not failover_attempted:
                        xbmc.log(f"[Skin Update] 主源下载失败，尝试切换到备用源...", xbmc.LOGWARNING)
                        dialog.update(0, "主源连接不稳定，切换至备用源...")
                        
                        # 清理已下载的部分主源文件
                        clean_up_files(downloaded_files)
                        downloaded_files = []
                        total_downloaded_bytes = 0
                        
                        # 获取备用源信息
                        backup_info = get_backup_download_info(version)
                        if not backup_info:
                            raise Exception("Failed to get backup download info")
                        
                        # 更新状态
                        urls = backup_info['urls']
                        dl_type = backup_info['type']
                        current_source = "backup"
                        failover_attempted = True
                        
                        # 重置循环索引，从备用源的第一个文件开始
                        # 注意：这里我们重新遍历新的urls列表
                        xbmc.log(f"[Skin Update] 已切换至备用源，开始下载完整ZIP", xbmc.LOGINFO)
                        
                        # 由于结构变化，我们直接跳出当前循环，进入备用源下载逻辑
                        # 为了简化，我们直接调用递归或者重新处理，但这里手动处理更清晰
                        # 我们只需要下载备用源的这一个文件
                        backup_url = urls[0]
                        backup_filename = os.path.basename(backup_url)
                        backup_save_path = os.path.join(download_dir, backup_filename)
                        
                        dialog.update(0, f"正在从备用源下载...")
                        size = download_file(backup_url, backup_save_path, dialog, TOTAL_EXPECTED_SIZE, 0)
                        if size > 0:
                            downloaded_files.append(backup_save_path)
                            total_downloaded_bytes += size
                        else:
                            raise Exception("Backup download failed")
                        
                        # 备用源下载完成后，直接跳出主循环
                        break 
                    else:
                        # 如果已经是备用源失败，或者已经尝试过故障转移还失败，则抛出异常
                        raise e

                if dialog.iscanceled():
                    dialog.close()
                    return []

        except Exception as e:
             if str(e) != "DownloadCancelled":
                 # 如果是其他错误且不是取消，确保对话框关闭前记录日志
                 xbmc.log(f"[Skin Update] 下载循环中断: {str(e)}", xbmc.LOGERROR)
             
        dialog.update(100, "下载完成，准备处理...")
        time.sleep(1)
        dialog.close()
        xbmc.log(f"[Skin Update] 总共下载了 {len(downloaded_files)} 个文件", xbmc.LOGINFO)
        return downloaded_files
        
    except Exception as e:
        if str(e) == "DownloadCancelled":
             return []
        xbmc.log(f"[Skin Update] 下载过程中发生异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        try:
            dialog.close()
        except:
            pass
        return []

def process_downloaded_files(downloaded_files, output_path, version, source_type):
    """
    处理下载的文件：如果是分片则合并，如果是单文件则直接验证。
    返回: (is_valid, archive_dir_or_none)
    """
    try:
        version_archive_dir = os.path.join(DEBUG_ARCHIVE_DIR, version)
        if IS_ANDROID:
            if not xbmcvfs.exists(version_archive_dir):
                xbmcvfs.mkdirs(version_archive_dir)
        else:
            if not os.path.exists(version_archive_dir):
                os.makedirs(version_archive_dir, exist_ok=True)

        # 判断实际使用的源类型，可以通过检查文件名后缀或者传入的参数
        # 这里我们简化逻辑：如果只有一个文件且以.zip结尾，视为single；否则视为split
        
        is_single_zip = len(downloaded_files) == 1 and downloaded_files[0].endswith(".zip")
        
        if is_single_zip:
            # Single zip file (either from backup or theoretically primary if config changed)
            if not downloaded_files:
                return False, None
            
            src_zip = downloaded_files[0]
            archived_path = os.path.join(version_archive_dir, os.path.basename(src_zip))
            shutil.copy2(src_zip, archived_path)
            
            # Copy to output path
            shutil.copy2(src_zip, output_path)
            
            is_valid = zipfile.is_zipfile(output_path)
            xbmc.log(f"[Skin Update] ZIP文件验证结果: {is_valid}, 路径: {output_path}", xbmc.LOGINFO)
            return is_valid, version_archive_dir

        else:
            # Split files logic (Primary source)
            required_suffixes = set(SPLIT_SUFFIXES)
            found_suffixes = set()
            for file in downloaded_files:
                for suffix in required_suffixes:
                    if file.endswith(f".{suffix}"):
                        found_suffixes.add(suffix)
                        break
            missing = required_suffixes - found_suffixes
            if missing:
                xbmc.log(f"[Skin Update] 缺少分片文件: {missing}", xbmc.LOGERROR)
                return False, version_archive_dir

            def get_split_order(file_path):
                file_name = os.path.basename(file_path)
                for i, suffix in enumerate(SPLIT_SUFFIXES):
                    if file_name.endswith(f".{suffix}"):
                        return i
                return 999

            split_files_sorted = sorted(downloaded_files, key=get_split_order)

            archived_files = []
            for file in split_files_sorted:
                archive_path = os.path.join(version_archive_dir, os.path.basename(file))
                shutil.copy2(file, archive_path)
                archived_files.append(archive_path)

            merged_archive_path = os.path.join(version_archive_dir, f"merged_{version}{DL_BASE_SUFFIX}")
            with open(merged_archive_path, 'wb') as outfile:
                for file in archived_files:
                    with open(file, 'rb') as infile:
                        while True:
                            chunk = infile.read(1024 * 1024)
                            if not chunk:
                                break
                            outfile.write(chunk)

            is_valid = zipfile.is_zipfile(merged_archive_path)
            xbmc.log(f"[Skin Update] ZIP文件验证结果: {is_valid}, 路径: {merged_archive_path}", xbmc.LOGINFO)
            
            shutil.copy2(merged_archive_path, output_path)
            xbmc.log(f"[Skin Update] 合并文件已保存到: {output_path}", xbmc.LOGINFO)
            return is_valid, version_archive_dir
            
    except Exception as e:
        xbmc.log(f"[Skin Update] 处理下载文件失败: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return False, None

def refresh_addon_database():
    try:
        xbmc.executebuiltin('UpdateLocalAddons')
        time.sleep(2)
        xbmc.log("[Skin Update] 插件数据库已刷新", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Skin Update] 刷新插件数据库失败: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)

def copy_override(src_dir, dst_dir):
    failed_files = []
    try:
        if IS_ANDROID:
            if not xbmcvfs.exists(dst_dir):
                xbmcvfs.mkdirs(dst_dir)
        else:
            if not os.path.exists(dst_dir):
                os.makedirs(dst_dir, exist_ok=True)

        for root, dirs, files in os.walk(src_dir):
            rel_path = os.path.relpath(root, src_dir)
            target_root = os.path.join(dst_dir, rel_path)
            
            if IS_ANDROID:
                if not xbmcvfs.exists(target_root):
                    xbmcvfs.mkdirs(target_root)
            else:
                if not os.path.exists(target_root):
                    os.makedirs(target_root, exist_ok=True)

            for file in files:
                src_file = os.path.join(root, file)
                dst_file = os.path.join(target_root, file)
                try:
                    if IS_ANDROID:
                        if xbmcvfs.exists(dst_file):
                            xbmcvfs.delete(dst_file)
                    else:
                        if os.path.exists(dst_file):
                            os.remove(dst_file)
                    shutil.copy2(src_file, dst_file)
                except Exception as e:
                    error_msg = f"{dst_file} (原因: {str(e)[:50]})"
                    failed_files.append(error_msg)
                    xbmc.log(f"[Skin Update] 复制文件失败: {error_msg}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)

        return True, failed_files
    except Exception as e:
        error_msg = f"整体复制失败: {str(e)}"
        xbmc.log(f"[Skin Update] 整体复制操作失败: {error_msg}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return False, [error_msg]

def create_custom_temp_directory(base_dir=None):
    """创建自定义临时目录"""
    try:
        if base_dir is None:
            base_dir = CACHE_DIR
        
        temp_dir = os.path.join(base_dir, f"skin_update_temp_{int(time.time())}_{os.getpid()}")
        
        if IS_ANDROID:
            if not xbmcvfs.exists(temp_dir):
                xbmcvfs.mkdirs(temp_dir)
        else:
            os.makedirs(temp_dir, exist_ok=True)
        
        xbmc.log(f"[Skin Update] 创建自定义临时目录: {temp_dir}", xbmc.LOGINFO)
        return temp_dir
    except Exception as e:
        xbmc.log(f"[Skin Update] 创建自定义临时目录失败: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        return None

def remove_custom_temp_directory(temp_dir):
    """删除自定义临时目录 - 改进版本，支持递归删除"""
    try:
        if temp_dir and os.path.exists(temp_dir):
            if IS_ANDROID:
                try:
                    if os.path.exists(temp_dir) and os.path.isdir(temp_dir):
                        shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception as e:
                    xbmc.log(f"[Skin Update] shutil.rmtree删除目录失败: {temp_dir}, 错误: {str(e)}", xbmc.LOGWARNING)
                
                try:
                    xbmcvfs.rmdir(temp_dir, force=True)
                except Exception as e:
                    xbmc.log(f"[Skin Update] xbmcvfs.rmdir删除目录失败: {temp_dir}, 错误: {str(e)}", xbmc.LOGWARNING)
            else:
                shutil.rmtree(temp_dir, ignore_errors=True)
            xbmc.log(f"[Skin Update] 删除临时目录: {temp_dir}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Skin Update] 删除临时目录失败: {temp_dir}, 异常: {str(e)}, 详情: {traceback.format_exc()}", xbmc.LOGWARNING)

def perform_update(version, source_type):
    files_to_clean = []
    temp_dir = None
    try:
        xbmc.log(f"[Skin Update] 开始更新版本 {version} (初始源类型: {source_type})", xbmc.LOGINFO)
        
        download_info = get_download_info(version, source_type)
        if not download_info:
            xbmcgui.Dialog().ok("更新失败", "无法构造下载链接")
            return False
        
        # --- 优化开始：预清理逻辑 ---
        expected_filenames = [os.path.basename(url) for url in download_info['urls']]
        merged_filename = f"merged_{version}{DL_BASE_SUFFIX}"
        
        files_to_pre_clean = []
        for fname in expected_filenames:
            fpath = os.path.join(DOWNLOAD_DIR, fname)
            files_to_pre_clean.append(fpath)
        files_to_pre_clean.append(os.path.join(DOWNLOAD_DIR, merged_filename))
        
        xbmc.log(f"[Skin Update] 预清理旧文件: {files_to_pre_clean}", xbmc.LOGINFO)
        clean_up_files(files_to_pre_clean)
        # --- 优化结束 ---

        # 执行下载 (内部包含故障转移逻辑)
        xbmc.log(f"[Skin Update] 开始下载文件 (类型: {download_info['type']})", xbmc.LOGINFO)
        downloaded_files = download_all_parts(download_info, version, DOWNLOAD_DIR)
        files_to_clean.extend(downloaded_files)
        
        # 验证下载的文件
        if not downloaded_files:
            error_msg = "文件下载失败或为空"
            xbmc.log(f"[Skin Update] {error_msg}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("下载错误", error_msg)
            return False
        
        # 确定最终使用的源类型用于后续处理
        # 如果下载的是一个.zip文件，则是single/backup模式，否则是split/primary模式
        final_source_type = "backup" if (len(downloaded_files) == 1 and downloaded_files[0].endswith(".zip")) else "primary"
        
        merged_zip_path = os.path.join(DOWNLOAD_DIR, f"processed_{version}{DL_BASE_SUFFIX}")
        files_to_clean.append(merged_zip_path)
        
        # 处理文件（合并或直接验证）
        process_success, archive_dir = process_downloaded_files(downloaded_files, merged_zip_path, version, final_source_type)
        if archive_dir:
            files_to_clean.append(archive_dir)
        
        if not process_success or not archive_dir:
            xbmcgui.Dialog().ok("处理失败", "文件验证失败或不完整")
            return False
        
        # 替代tempfile.TemporaryDirectory()，使用自定义临时目录
        temp_dir = create_custom_temp_directory()
        if not temp_dir:
            xbmcgui.Dialog().ok("错误", "无法创建临时目录")
            return False

        try:
            with zipfile.ZipFile(merged_zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
                xbmc.log(f"[Skin Update] ZIP文件已解压到临时目录: {temp_dir}", xbmc.LOGINFO)
        except Exception as e:
            error_msg = f"解压失败: {str(e)}"
            xbmc.log(f"[Skin Update] {error_msg}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("解压失败", f"错误: {str(e)}")
            return False

        src_skin_dir = temp_dir
        if not os.path.exists(os.path.join(temp_dir, "addon.xml")):
            for root, dirs, files in os.walk(temp_dir):
                if "addon.xml" in files:
                    src_skin_dir = root
                    break

        success, failed_files = copy_override(src_skin_dir, SKIN_DIR)

        if not success:
            xbmcgui.Dialog().ok("更新失败", f"复制错误:\n{failed_files[0]}")
            return False
        if failed_files:
            fail_msg = "部分文件覆盖失败:\n" + "\n".join(failed_files[:3])
            if len(failed_files) > 3:
                fail_msg += f"\n... 共 {len(failed_files)} 个"
            xbmcgui.Dialog().ok("更新警告", f"{fail_msg}\n建议重启Kodi。")

        refresh_addon_database()
        xbmc.executebuiltin('ReloadSkin()')
        time.sleep(1)
        xbmc.executebuiltin('SetFocus(9000)')
        time.sleep(3)

        new_version = get_current_skin_version()
        if new_version == version:
            xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
            dialog_result = xbmcgui.Dialog().ok("操作成功", f"已成功更新到版本 {new_version}！")
            xbmc.executebuiltin('RunScript(special://skin/scripts/skinauto.py)')
            if dialog_result:
                xbmc.executebuiltin('RunScript(special://skin/scripts/updatelog.py)')
            xbmc.log(f"[Skin Update] 成功更新到版本 {new_version}", xbmc.LOGINFO)
            return True
        else:
            xbmcgui.Dialog().ok("更新未生效", f"当前版本: {new_version}\n建议手动更新或重启。")
            xbmc.log(f"[Skin Update] 更新未生效，当前版本: {new_version}, 目标版本: {version}", xbmc.LOGWARNING)
            return False
            
    except Exception as e:
        error_msg = f"更新过程中发生异常: {str(e)}"
        xbmc.log(f"[Skin Update] {error_msg}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("更新异常", f"发生错误: {str(e)}")
        return False
    finally:
        xbmc.log(f"[Skin Update] 开始清理临时文件: {files_to_clean}", xbmc.LOGINFO)
        clean_up_files(files_to_clean)
        if temp_dir:
            remove_custom_temp_directory(temp_dir)
        xbmc.log("[Skin Update] 临时文件清理完成", xbmc.LOGINFO)

def main():
    files_to_clean = []
    
    if len(sys.argv) <= 1:
        is_auto_check_mode = True
        is_manual_mode = False
    else:
        is_manual_mode = sys.argv[1].lower() == "manual"
        is_auto_check_mode = sys.argv[1].lower() == "start"
    
    xbmc.log(f"[Skin Update] 脚本启动，模式: {'手动' if is_manual_mode else '自动检查' if is_auto_check_mode else '未知'}", xbmc.LOGINFO)
    
    try:
        current_ver = get_current_skin_version()
        xbmc.log(f"[Skin Update] 当前皮肤版本: {current_ver}", xbmc.LOGINFO)
        
        remote_versions, source_type = get_remote_versions_with_retry()

        if not current_ver or not remote_versions:
            xbmc.log(f"[Skin Update] 版本检查失败 - 当前版本: {current_ver}, 远程版本: {remote_versions}", xbmc.LOGINFO)
            if is_manual_mode:
                show_manual_install_dialog()
            return

        latest_ver = get_latest_version(remote_versions)

        if is_auto_check_mode:
            comparison_result = compare_versions(current_ver, latest_ver)
            xbmc.log(f"[Skin Update] 版本比较结果: {comparison_result} ({current_ver} vs {latest_ver})", xbmc.LOGINFO)
            
            if comparison_result == 0:
                xbmc.log("[Skin Update] 当前已是最新版本，退出", xbmc.LOGINFO)
                return
            elif comparison_result < 0:
                xbmc.log("[Skin Update] 发现新版本，继续处理", xbmc.LOGINFO)
                pass
            else:
                xbmc.log("[Skin Update] 当前版本较新，退出", xbmc.LOGINFO)
                return

        if compare_versions(current_ver, latest_ver) == 0:
            options = [
                f"当前为最新版本 ({current_ver})，点击后重新安装",
                "选择切换版本",
                "手动ZIP包更新",
                "不更新"
            ]
        else:
            options = [
                f"当前: {current_ver} -> 最新 ({latest_ver})",
                "选择切换版本",
                "手动ZIP包更新",
                "不更新"
            ]
        
        title = "皮肤更新"
        dialog = xbmcgui.Dialog()
        ret = dialog.select(title, options)

        if ret == -1:
            xbmc.log("[Skin Update] 用户取消操作", xbmc.LOGINFO)
            return

        show_manual_dialog = is_manual_mode

        if ret == 0:
            xbmc.log("[Skin Update] 用户选择更新到最新版本", xbmc.LOGINFO)
            perform_update(latest_ver, source_type)
            show_manual_dialog = False

        elif ret == 1:
            version_ret = dialog.select("选择版本", remote_versions)
            if version_ret != -1:
                selected_version = remote_versions[version_ret]
                xbmc.log(f"[Skin Update] 用户选择特定版本: {selected_version}", xbmc.LOGINFO)
                perform_update(selected_version, source_type)
                show_manual_dialog = False

        elif ret == 2:
            xbmc.log("[Skin Update] 用户选择手动更新", xbmc.LOGINFO)
            show_manual_install_dialog()
            show_manual_dialog = False

        elif ret == 3:
            xbmc.log("[Skin Update] 用户选择不更新", xbmc.LOGINFO)
            xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
            show_manual_dialog = False

        if show_manual_dialog:
            show_manual_install_dialog()
    
    except Exception as e:
        error_msg = f"主程序执行异常: {str(e)}"
        xbmc.log(f"[Skin Update] {error_msg}, 详情: {traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("更新异常", f"发生错误: {str(e)}")
    
    finally:
        if IS_ANDROID:
            try:
                if os.path.exists(DEBUG_ARCHIVE_DIR) and os.path.isdir(DEBUG_ARCHIVE_DIR):
                    shutil.rmtree(DEBUG_ARCHIVE_DIR, ignore_errors=True)
            except Exception as e:
                xbmc.log(f"[Skin Update] 清理debug目录失败: {DEBUG_ARCHIVE_DIR}, 错误: {str(e)}", xbmc.LOGWARNING)
        else:
            if os.path.exists(DEBUG_ARCHIVE_DIR):
                shutil.rmtree(DEBUG_ARCHIVE_DIR, ignore_errors=True)
        
        xbmc.log(f"[Skin Update] 主程序结束，开始最终清理: {files_to_clean}", xbmc.LOGINFO)
        clean_up_files(files_to_clean)
        xbmc.log("[Skin Update] 最终清理完成", xbmc.LOGINFO)

def show_manual_install_dialog():
    dialog = xbmcgui.Dialog()
    if dialog.ok("手动更新", "请把皮肤ZIP包复制到 downloads 文件夹后点击确定。"):
        xbmc.executebuiltin('InstallFromZip')
        xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')

if __name__ == "__main__":
    main()