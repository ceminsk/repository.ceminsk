import os
import sys
import time
import sqlite3
import urllib.parse
import glob

try:
    import xbmc
    import xbmcvfs
except ImportError:
    pass
# ---- 日志脱敏（防止局域网/WebDAV 路径中的用户名密码明文写入日志）----
try:
    from logmask import sanitize_credentials
except Exception:  # 兜底：模块缺失时不影响脚本原有功能
    def sanitize_credentials(text):
        return text
def _masked_log(*args, **kwargs):
    """写日志前自动脱敏路径中的用户名密码。

    用 *args/**kwargs 转发，保证 level 等参数语义与 xbmc.log 完全一致
    （xbmc.log 的默认级别为 LOGDEBUG）。
    """
    try:
        if args:
            args = (sanitize_credentials(args[0]),) + args[1:]
        elif "msg" in kwargs:
            kwargs["msg"] = sanitize_credentials(kwargs["msg"])
    except Exception:
        pass
    xbmc.log(*args, **kwargs)


def _masked_print(*args, **kwargs):
    """print 同样会被 Kodi 转发到日志，输出前先脱敏。"""
    try:
        args = tuple(sanitize_credentials(a) for a in args)
    except Exception:
        pass
    print(*args, **kwargs)


def log(msg, level=xbmc.LOGINFO):
    """辅助日志函数"""
    try:
        _masked_log(sanitize_credentials(f"noprogress.py: {msg}"), level)
    except:
        _masked_print(f"noprogress.py: {msg}")

def handle_play():
    """处理 play 参数：清空变量，等待播放器信息并保存到 Skin 变量"""
    log("Starting 'play' sequence. Clearing Skin variables...")
    
    # 清空 Skin 变量
    xbmc.executebuiltin('Skin.SetString(noplayname,)')
    xbmc.executebuiltin('Skin.SetString(noplaypath,)')
    
    log("Waiting 1 second before checking player info...")
    time.sleep(1)
    
    title = ""
    folderpath = ""
    
    # 循环检查直到 Title 和 Folderpath 都非空
    while True:
        title = xbmc.getInfoLabel('Player.Title')
        folderpath = xbmc.getInfoLabel('Player.Folderpath')
        
        if title and folderpath:
            break
            
        log("Player info not fully loaded yet. Waiting 1 second...")
        time.sleep(1)
        
    log(f"Captured Title: '{title}', FolderPath: '{folderpath}'")
    
    # 设置 Skin 字符串
    xbmc.executebuiltin(f'Skin.SetString(noplayname,{title})')
    xbmc.executebuiltin(f'Skin.SetString(noplaypath,{folderpath})')
    
    log("Skin strings set successfully. Exiting 'play' sequence.")

def handle_stop():
    """处理 stop 参数：读取 Skin 变量并更新视频数据库"""
    log("Starting 'stop' sequence.")
    
    # 获取保存的 Skin 字符串
    name = xbmc.getInfoLabel('Skin.String(noplayname)')
    path = xbmc.getInfoLabel('Skin.String(noplaypath)')
    
    if not name or not path:
        log("Skin strings (noplayname/noplaypath) are empty. Exiting.", xbmc.LOGWARNING)
        return
        
    log(f"Retrieved Skin strings - Name: '{name}', Path: '{path}'")
    
    # 定位最新的 MyVideos14*.db 数据库文件
    try:
        db_dir = xbmcvfs.translatePath('special://userdata/Database/')
    except AttributeError:
        db_dir = xbmc.translatePath('special://userdata/Database/')
        
    db_files = glob.glob(os.path.join(db_dir, 'MyVideos14*.db'))
    if not db_files:
        log("No MyVideos14*.db found. Exiting.", xbmc.LOGERROR)
        return
        
    latest_db = max(db_files, key=os.path.getmtime)
    log(f"Using database: {latest_db}")
    
    # 步骤1前置：延迟2秒
    log("Waiting 2 seconds before database operations...")
    time.sleep(2)
    
    conn = None
    try:
        conn = sqlite3.connect(latest_db)
        cursor = conn.cursor()
        
        # 判断协议和文件类型
        is_dav = path.startswith('dav:')
        is_bdmv = name.lower() == 'index.bdmv'
        
        # 计算目标文件名和目标路径
        target_filename = urllib.parse.quote(name) if is_dav else name
        target_path = (path + 'BDMV/') if is_bdmv else path
        
        log(f"Target filename: '{target_filename}' | Target path: '{target_path}'")
        
        # ================= 步骤 1 =================
        log("Executing Step 1: Updating latest played record...")
        
        # 找到 lastPlayed 最新的一行
        cursor.execute("SELECT idFile, idPath FROM files ORDER BY lastPlayed DESC LIMIT 1")
        row = cursor.fetchone()
        
        if not row:
            log("No files found in database. Exiting.", xbmc.LOGWARNING)
            return
            
        idFile, old_idPath = row
        
        # 修改 strFilename
        cursor.execute("UPDATE files SET strFilename = ? WHERE idFile = ?", (target_filename, idFile))
        
        # 处理 path 关联 (使用计算后的 target_path)
        cursor.execute("SELECT idPath FROM path WHERE strPath = ? ORDER BY idPath ASC LIMIT 1", (target_path,))
        path_row = cursor.fetchone()
        
        if path_row:
            new_idPath = path_row[0]
            log(f"Found existing path record: idPath={new_idPath}. Updating files.idPath.")
            cursor.execute("UPDATE files SET idPath = ? WHERE idFile = ?", (new_idPath, idFile))
        else:
            log(f"Path not found in path table. Updating path.strPath for idPath={old_idPath}.")
            cursor.execute("UPDATE path SET strPath = ? WHERE idPath = ?", (target_path, old_idPath))
            
        conn.commit()
        log("Step 1 completed and committed.")
        
        # 步骤1完成后执行刷新容器指令
        log("Refreshing container to reflect Step 1 changes.")
        xbmc.executebuiltin('Container.Refresh')
        
        # ================= 步骤 2 =================
        log("Executing Step 2: Cleaning up duplicate records...")
        
        # 查找其他具有相同 strFilename 的行 (使用计算后的 target_filename)
        cursor.execute("SELECT idFile FROM files WHERE strFilename = ? AND idFile != ?", (target_filename, idFile))
        dup_rows = cursor.fetchall()
        
        if dup_rows:
            dup_ids = [r[0] for r in dup_rows]
            log(f"Found {len(dup_ids)} duplicate file records to delete.")
            
            placeholders = ','.join(['?'] * len(dup_ids))
            
            # 删除 bookmark 关联
            cursor.execute(f"DELETE FROM bookmark WHERE idFile IN ({placeholders})", dup_ids)
            # 删除 files 记录
            cursor.execute(f"DELETE FROM files WHERE idFile IN ({placeholders})", dup_ids)
            
            conn.commit()
            log("Step 2 completed and committed.")
        else:
            log("No duplicate file records found.")
            
    except Exception as e:
        if conn:
            conn.rollback()
        log(f"Database error: {str(e)}", xbmc.LOGERROR)
    finally:
        if conn:
            conn.close()
            
    log("'stop' sequence finished.")

def main():
    # 获取运行参数 (sys.argv[1] 为第一个参数)
    if len(sys.argv) < 2:
        log("No arguments provided. Usage: RunScript(..., play|stop)", xbmc.LOGERROR)
        return
        
    action = sys.argv[1].strip().lower()
    
    if action == 'play':
        handle_play()
    elif action == 'stop':
        handle_stop()
    else:
        log(f"Unknown argument: '{action}'. Expected 'play' or 'stop'.", xbmc.LOGERROR)

if __name__ == '__main__':
    main()