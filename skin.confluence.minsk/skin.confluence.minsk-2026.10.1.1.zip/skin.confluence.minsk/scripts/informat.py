import xbmc
import xbmcvfs
import re
import os
import sys

# 使用 xbmcvfs.translatePath 兼容 Kodi 19+
LOCK_FILE_PATH = os.path.join(xbmcvfs.translatePath('special://temp/'), 'informat_script.lock')

def is_already_running():
    """检查是否已有实例通过文件锁运行"""
    if os.path.exists(LOCK_FILE_PATH):
        try:
            with open(LOCK_FILE_PATH, 'r') as f:
                old_pid = int(f.read().strip())
            # 检查旧 PID 是否还在运行
            # os.kill(pid, 0) 不会发送信号，仅用于检查进程是否存在
            os.kill(old_pid, 0)
            return True
        except (OSError, ValueError, ProcessLookupError):
            # 如果进程不存在或文件格式错误，说明是残留锁文件，清理它
            try:
                os.remove(LOCK_FILE_PATH)
            except:
                pass
    return False

def create_lock():
    """创建锁文件并写入当前 PID"""
    try:
        with open(LOCK_FILE_PATH, 'w') as f:
            f.write(str(os.getpid()))
    except Exception as e:
        xbmc.log('[script.informat] Failed to create lock file: {}'.format(e), xbmc.LOGERROR)

def remove_lock():
    """删除锁文件"""
    try:
        if os.path.exists(LOCK_FILE_PATH):
            os.remove(LOCK_FILE_PATH)
    except:
        pass

def read_sys_file(filepath):
    try:
        with open(filepath, 'r') as f:
            return f.readline().strip()
    except Exception:
        return None

def main():
    # 1. 单实例检查
    if is_already_running():
        xbmc.log('[script.informat] Another instance is already running. Exiting.', xbmc.LOGINFO)
        return
    
    # 2. 创建锁
    create_lock()
    
    try:
        monitor = xbmc.Monitor()
        
        last_cpu = ""
        last_min = ""
        last_max = ""
        last_avg = ""
        last_aml = ""
        last_net = ""
        last_total_bytes = 0
        first_net_read = True
        
        # 初始化网络变量为 0.0
        xbmc.executebuiltin('Skin.SetString(netmbps,0.0)')
        
        try:
            videofps_raw = xbmc.getInfoLabel('Player.Process(videofps)')
            aa = int(round(float(videofps_raw))) if videofps_raw else 0
        except Exception as e:
            xbmc.log('[script.informat] Error reading videofps: {}'.format(e), xbmc.LOGERROR)
            aa = 0

        while True:
            # 退出条件：playerprocessinfo 和 videoosd 都不可见
            is_proc_info = xbmc.getCondVisibility('Window.IsVisible(playerprocessinfo)')
            is_video_osd = xbmc.getCondVisibility('Window.IsVisible(videoosd)')
            
            if not (is_proc_info or is_video_osd):
                break
                
            # --- Logic 1: CPU Usage ---
            try:
                cpu_raw = xbmc.getInfoLabel('System.CpuUsage')
                cores = re.findall(r'#\d+:\s*(\d+)(?:\.\d+)?%', cpu_raw)
                if cores:
                    curr_cpu = ' | '.join(cores)
                    if curr_cpu != last_cpu:
                        xbmc.executebuiltin('Skin.SetString(cpuperusage,{})'.format(curr_cpu))
                        last_cpu = curr_cpu
            except Exception as e:
                xbmc.log('[script.informat] Error in Logic 1: {}'.format(e), xbmc.LOGERROR)

            # --- Logic 2: Nits Data ---
            try:
                min_raw = xbmc.getInfoLabel('Window(Home).Property(sidedata.rpu.l1.min_nits)')
                if min_raw:
                    curr_min = "{:.4f}".format(float(min_raw))
                    if curr_min != last_min:
                        xbmc.executebuiltin('Skin.SetString(l1minnits,{})'.format(curr_min))
                        last_min = curr_min
                        
                max_raw = xbmc.getInfoLabel('Window(Home).Property(sidedata.rpu.l1.max_nits)')
                if max_raw:
                    curr_max = str(int(round(float(max_raw))))
                    if curr_max != last_max:
                        xbmc.executebuiltin('Skin.SetString(l1maxnits,{})'.format(curr_max))
                        last_max = curr_max
                        
                avg_raw = xbmc.getInfoLabel('Window(Home).Property(sidedata.rpu.l1.avg_nits)')
                if avg_raw:
                    curr_avg = str(int(round(float(avg_raw))))
                    if curr_avg != last_avg:
                        xbmc.executebuiltin('Skin.SetString(l1avgnits,{})'.format(curr_avg))
                        last_avg = curr_avg
            except Exception as e:
                xbmc.log('[script.informat] Error in Logic 2: {}'.format(e), xbmc.LOGERROR)

            # --- Logic 3: AML FPS ---
            try:
                fps_content = read_sys_file('/sys/class/video/fps_info')
                bb = 0
                if fps_content:
                    match = re.search(r'drop_fps:\s*(?:0x)?([0-9a-fA-F]+)', fps_content)
                    if match:
                        bb = int(match.group(1), 16)
                
                diff = aa - bb
                curr_aml = "{} | {} | {} fps".format(aa, bb, diff)
                if curr_aml != last_aml:
                    xbmc.executebuiltin('Skin.SetString(amlfps,{})'.format(curr_aml))
                    last_aml = curr_aml
            except Exception as e:
                xbmc.log('[script.informat] Error in Logic 3: {}'.format(e), xbmc.LOGERROR)

            # --- Logic 4: Network Traffic (MB/s) ---
            try:
                current_total_bytes = 0
                with open('/proc/net/dev', 'r') as f:
                    for line in f:
                        parts = line.split(':')
                        if len(parts) == 2:
                            iface = parts[0].strip()
                            if iface.startswith('eth') or iface.startswith('wlan'):
                                stats = parts[1].split()
                                if stats:
                                    current_total_bytes += int(stats[0])
                
                if first_net_read:
                    last_total_bytes = current_total_bytes
                    first_net_read = False
                else:
                    bytes_diff = current_total_bytes - last_total_bytes
                    last_total_bytes = current_total_bytes
                    
                    if bytes_diff < 0:
                        bytes_diff = 0
                        
                    mbps_val = bytes_diff / (1024.0 * 128.0)
                    curr_net_str = "{:.1f}".format(mbps_val)
                    
                    if curr_net_str != last_net:
                        xbmc.executebuiltin('Skin.SetString(netmbps,{})'.format(curr_net_str))
                        last_net = curr_net_str
            except Exception as e:
                xbmc.log('[script.informat] Error in Logic 4: {}'.format(e), xbmc.LOGERROR)

            if monitor.waitForAbort(1.0):
                break

    finally:
        # 3. 无论正常退出还是异常，都确保删除锁文件
        remove_lock()
        xbmc.log('[script.informat] Script finished and lock removed.', xbmc.LOGINFO)

if __name__ == '__main__':
    main()