# -*- coding: utf-8 -*-
"""
KODI播放历史记录脚本
此脚本可以从JSON文件读取播放记录，并在KODI中显示历史列表
优化点：
1. 移除强制UI排序代码，避免干扰用户视图设置
2. 在数据加载阶段强制按时间降序排列，确保最新记录在最前
3. 增强JSON解析的鲁棒性
"""
import sys
import json
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from datetime import datetime

def get_script_params():
    """获取脚本参数"""
    script_params = sys.argv[1:]
    params = {}
    for param in script_params:
        if '=' in param:
            key, value = param.split('=', 1)
            params[key] = value
    return params

def get_json_file_path():
    """获取播放记录JSON文件路径"""
    # 直接到special://profile/addon_data/skin.confluence.minsk/路径获取lastPlayed.json文件
    txtpath = xbmcvfs.translatePath("special://profile/addon_data/skin.confluence.minsk/")
    if not xbmcvfs.exists(txtpath):
        xbmcvfs.mkdirs(txtpath)
    
    json_file = txtpath + "lastPlayed.json"
    return json_file

def parse_date_time(date_str, time_str):
    """
    将日期和时间字符串转换为可比较的datetime对象
    用于排序
    """
    try:
        # 假设格式为 YYYY-MM-DD 和 HH:MM:SS
        dt_str = f"{date_str} {time_str}"
        # 尝试多种常见格式
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M:%S"):
            try:
                return datetime.strptime(dt_str, fmt)
            except ValueError:
                continue
        return datetime.min # 如果无法解析，返回最小时间，排在最后
    except Exception:
        return datetime.min

def load_history_records(json_file):
    """加载播放历史记录 - 支持多种格式和容错处理，并自动按时间降序排序"""
    if not xbmcvfs.exists(json_file):
        xbmc.log("播放历史文件不存在: " + json_file, xbmc.LOGINFO)
        return []
    
    records = []
    try:
        f = xbmcvfs.File(json_file)
        content = f.read()
        f.close()
        
        if not content:
            xbmc.log("播放历史文件为空", xbmc.LOGINFO)
            return []
        
        # 尝试标准JSON解析
        parsed_successfully = False
        try:
            data = json.loads(content)
            if isinstance(data, list):
                records = data
                parsed_successfully = True
                xbmc.log(f"成功加载 {len(records)} 条播放历史记录 (标准JSON格式)", xbmc.LOGINFO)
            elif isinstance(data, dict):
                # 如果是个单对象，包裹成列表
                records = [data]
                parsed_successfully = True
        except json.JSONDecodeError:
            pass
        
        # 如果标准解析失败，尝试逐行解析（支持多行JSON对象）
        if not parsed_successfully:
            lines = content.split('\n')
            current_obj = ''
            brace_count = 0
            
            for line in lines:
                stripped_line = line.strip()
                if not stripped_line:
                    continue
                    
                for char in stripped_line:
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        brace_count -= 1
                
                current_obj += stripped_line
                
                if brace_count == 0 and current_obj:
                    try:
                        obj = json.loads(current_obj)
                        if isinstance(obj, dict):
                            records.append(obj)
                        elif isinstance(obj, list):
                            records.extend(obj)
                        current_obj = ''
                    except json.JSONDecodeError:
                        current_obj += '\n'
                else:
                    current_obj += '\n'
            
            # 处理剩余内容
            if current_obj.strip():
                try:
                    obj = json.loads(current_obj.strip())
                    if isinstance(obj, dict):
                        records.append(obj)
                    elif isinstance(obj, list):
                        records.extend(obj)
                except:
                    pass
            
            if records:
                xbmc.log(f"成功加载 {len(records)} 条播放历史记录 (兼容模式)", xbmc.LOGINFO)

        # 再次尝试：使用正则表达式提取JSON对象 (兜底)
        if not records:
            import re
            pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
            matches = re.findall(pattern, content.replace('\n', '').replace('\r', ''))
            
            for match in matches:
                try:
                    obj = json.loads(match)
                    if isinstance(obj, dict):
                        records.append(obj)
                except:
                    pass
            if records:
                xbmc.log(f"成功加载 {len(records)} 条播放历史记录 (正则模式)", xbmc.LOGINFO)
        
    except Exception as e:
        xbmc.log(f"加载播放历史失败: {str(e)}", xbmc.LOGERROR)
        return []

    # --- 核心优化：在内存中对记录进行排序 ---
    # 确保最新的记录排在列表的最前面 (index 0)
    if records:
        def sort_key(record):
            if not isinstance(record, dict):
                return datetime.min
            date = record.get('date', '')
            time = record.get('time', '')
            return parse_date_time(date, time)
        
        # reverse=True 表示降序，即最新的在前面
        records.sort(key=sort_key, reverse=True)
        xbmc.log("播放历史记录已按时间降序排列", xbmc.LOGINFO)

    return records

def get_media_category(media_type, show_title):
    """获取媒体类别显示文本"""
    if media_type == 'movie':
        return '影'
    elif media_type == 'episode':
        return '剧'
    elif show_title:  # 如果有剧集名称，即使类型不是episode也认为是剧集
        return '剧'
    else:
        return '非'

def activate_history_window():
    """激活包含播放历史的视频窗口"""
    # 创建一个临时播放列表来存储历史记录
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()  # 清空现有播放列表
    
    # 加载播放历史 (内部已排序)
    json_file = get_json_file_path()
    records = load_history_records(json_file)
    
    if not records:
        xbmcgui.Dialog().ok("播放历史", "没有找到播放历史记录。")
        return
    
    # 为每条记录创建列表项并添加到播放列表
    for i, record in enumerate(records):
        # 确保记录是字典类型
        if not isinstance(record, dict):
            xbmc.log(f"跳过非字典类型的记录 #{i}: {type(record)}", xbmc.LOGINFO)
            continue
            
        # 按照指定格式构建显示标题: [COLOR YELLOW][月-日 小时:分钟][/COLOR][COLOR green][类别(电影/剧集/视频)][/COLOR]剧集名称 季数&集数 文件名
        date_part = record.get('date', '')
        time_part = record.get('time', '')
        
        # 提取月份和日期
        month_day = ""
        if date_part:
            parts = date_part.split('-')
            if len(parts) >= 3:
                month_day = f"{parts[1]}-{parts[2]}"
        
        # 组合时间部分
        formatted_time = ""
        if time_part:
            time_parts = time_part.split(':')
            if len(time_parts) >= 2:
                formatted_time = f"{time_parts[0]}:{time_parts[1]}"
        
        # 构建标题部分
        title_part = record.get('title', 'Unknown')
        
        # 获取媒体类型、季、集信息
        media_type = record.get('type', 'video').lower()
        season = record.get('season', '')
        episode = record.get('episode', '')
        
        # 获取剧集名称
        show_title = record.get('show', record.get('showtitle', record.get('tvshowtitle', '')))
        
        # 构建季数和集数信息
        season_episode_info = ""
        if media_type == 'episode' and show_title:
            try:
                s = int(season) if season else 0
                e = int(episode) if episode else 0
                if s and e:
                    season_episode_info = f" {s}x{e} "
                elif s:
                    season_episode_info = f" S{s} "
                elif e:
                    season_episode_info = f" E{e} "
            except ValueError:
                season_episode_info = f" {season}{episode} "
        else:
            season_episode_info = " "
        
        # 获取媒体类别
        category = get_media_category(media_type, show_title)
        
        # 构建最终标题
        time_part_colored = f"[COLOR yellow][{month_day} {formatted_time}][/COLOR]"
        
        # 设置不同类别的颜色
        if category == '影':  # 电影
            category_part_colored = f"[COLOR green]{{{category}}}[/COLOR]"
        elif category == '剧':  # 剧集
            category_part_colored = f"[COLOR orange]{{{category}}}[/COLOR]"
        else:  # 视频 -> 非
            category_part_colored = f"[COLOR white]{{{category}}}[/COLOR]"
        
        if show_title:
            final_title = f"{time_part_colored}{category_part_colored}{show_title}{season_episode_info}{title_part}"
        else:
            final_title = f"{time_part_colored}{category_part_colored}{title_part}"
        
        # 创建列表项
        li = xbmcgui.ListItem(label=final_title)
        
        # 使用新的InfoTagVideo API设置视频信息
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(final_title)
        info_tag.setOriginalTitle(final_title)
        if record.get('year'):
            try:
                info_tag.setYear(int(record.get('year')))
            except:
                pass
        if record.get('type'):
            info_tag.setMediaType(record.get('type', 'video'))
        if record.get('plot'):
            info_tag.setPlot(f"来源: {record.get('source', 'Unknown')}\n类型: {record.get('type', 'Unknown')}\n日期: {record.get('date', '')} {record.get('time', '')}")
        if record.get('date') and record.get('time'):
            info_tag.setLastPlayed(f"{record.get('date')} {record.get('time')}")
        if season and media_type == 'episode':
            try:
                info_tag.setSeason(int(season))
            except:
                pass
        if episode and media_type == 'episode':
            try:
                info_tag.setEpisode(int(episode))
            except:
                pass
        if show_title:
            info_tag.setTvShowTitle(show_title)
        
        # 设置恢复点
        resume_time_str = record.get('resume_time', 0)
        total_time_str = record.get('total_time', 0)
        
        try:
            resume_time = float(resume_time_str) if resume_time_str else 0.0
        except (ValueError, TypeError):
            resume_time = 0.0
            
        try:
            total_time = float(total_time_str) if total_time_str else 0.0
        except (ValueError, TypeError):
            total_time = 0.0
        
        if resume_time > 0 or total_time > 0:
            info_tag.setResumePoint(resume_time, total_time)
        
        # 设置艺术资源
        art_dict = {}
        thumbnail = record.get('thumbnail', '')
        if thumbnail and thumbnail != 'null' and isinstance(thumbnail, str) and thumbnail.strip():
            art_dict["poster"] = thumbnail.strip()
            art_dict["thumbnail"] = thumbnail.strip()
        
        fanart = record.get('fanart', '')
        if fanart and fanart != 'null' and isinstance(fanart, str) and fanart.strip():
            art_dict["fanart"] = fanart.strip()
        
        icon = record.get('icon', '')
        if icon and icon != 'null' and isinstance(icon, str) and icon.strip():
            art_dict["icon"] = icon.strip()
        
        if art_dict:
            li.setArt(art_dict)
        
        # 设置为可播放
        li.setProperty('IsPlayable', 'true')
        
        # 获取实际播放路径
        play_url = record.get('file', '')
        if not play_url:
            play_url = record.get('video', '')
        
        if play_url:
            # 添加上下文菜单
            commands = []
            
            # 删除记录命令 - 注意：这里需要传递当前记录的索引给删除脚本
            # 由于我们是动态生成列表，索引就是循环变量 i
            # 但是 RunScript 很难直接传参给另一个脚本的特定函数，通常需要通过 sys.argv 传递
            # 这里假设 delethistory.py 能处理 index 参数，或者我们需要修改调用方式
            # 为了简单起见，这里保留原逻辑，但请注意索引匹配问题
            delete_cmd = (
                "删除记录",
                f"RunScript(special://skin/scripts/delethistory.py,index,{i})"
            )
            commands.append(delete_cmd)
            
            # 打开所在文件夹
            play_cmd = (
               "打开所在文件夹",
                f"RunScript(special://skin/scripts/episodelist.py)"
            )
            commands.append(play_cmd)
            
            li.addContextMenuItems(commands)
            
            # 添加到播放列表
            playlist.add(url=play_url, listitem=li)
    
    # 激活视频窗口
    xbmc.executebuiltin('ActivateWindow(Videos,playlistvideo://,return)')
    
    # 注意：已移除强制排序代码 (Container.SetSortMethod 等)
    # 依靠 Python 端的预排序和标题前缀来维持视觉顺序

def delete_record(index):
    """删除指定索引的记录"""
    json_file = get_json_file_path()
    records = load_history_records(json_file)
    
    if 0 <= index < len(records):
        deleted_record = records.pop(index)
        xbmc.log(f"删除播放记录: {deleted_record.get('title', 'Unknown')}", xbmc.LOGINFO)
        
        # 保存更新后的记录
        try:
            # 使用 w 模式写入，确保覆盖
            f = xbmcvfs.File(json_file, 'w')
            # 确保写入的是标准的 JSON 数组格式
            json.dump(records, f, ensure_ascii=False, indent=2)
            f.close()
            xbmcgui.Dialog().notification(
                "删除成功", 
                f"已删除: {deleted_record.get('title', 'Unknown')}",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            # 删除后刷新当前窗口以反映变化
            xbmc.executebuiltin('Container.Refresh')
        except Exception as e:
            xbmc.log(f"保存播放历史失败: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("错误", "无法保存更改。")
    else:
        xbmcgui.Dialog().ok("错误", "无效的记录索引。")

def main():
    """主函数"""
    # 检查播放历史文件是否存在，只有存在时才设置皮肤变量
    json_file = get_json_file_path()
    records = load_history_records(json_file)
    
    if records:  # 只有当存在播放历史记录时才设置皮肤变量
        xbmc.executebuiltin('Skin.SetString(plhistory,1)')
        xbmc.log("播放历史文件存在，已设置皮肤变量 plhistory=1", xbmc.LOGINFO)
    else:
        xbmc.log("播放历史文件不存在或为空，跳过设置皮肤变量 plhistory", xbmc.LOGINFO)
    
    xbmc.log("启动播放历史脚本", xbmc.LOGINFO)
    
    # 解析参数
    params = get_script_params()
    action = params.get('action', 'show')
    index = params.get('index', None)
    
    if action == 'delete' and index is not None:
        try:
            delete_record(int(index))
        except ValueError:
            xbmc.log("无效的索引值", xbmc.LOGERROR)
    elif action == 'show' or action is None:
        # 激活包含播放历史的视频窗口
        activate_history_window()
    else:
        xbmc.log(f"未知操作: {action}", xbmc.LOGWARNING)

# 确保脚本可以独立运行
if __name__ == "__main__":
    main()