#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
import random
import re
import json
import shutil
import hashlib
import urllib.request
import xbmc
import xbmcvfs
import xml.etree.ElementTree as ET

def is_coreelec_system():
    """检测是否为 CoreELEC/LibreELEC 系统"""
    if os.path.exists("/etc/coreelec-release"):
        return True
    if os.path.exists("/etc/os-release"):
        try:
            with open("/etc/os-release", "r", encoding="utf-8") as f:
                content = f.read().lower()
                if "coreelec" in content or "libreelec" in content:
                    return True
        except Exception:
            pass
    if os.path.exists("/storage/.config") and os.path.isdir("/storage/.config"):
        return True
    return False

AUTOSTART_PATH = "/storage/.config/autostart.sh"

target_scripts = [
    "RunScript(special://skin/scripts/skinupdate.py)",
    "RunScript(special://skin/scripts/version.py)",
    "RunScript(special://skin/scripts/refreshratecon.py)"
]

TARGET_MOUNT_CMDS = [
    "mount --bind /storage/.resource/keyboard.xml /usr/share/kodi/system/keymaps/keyboard.xml",
    "mount --bind /storage/.resource/remote.xml /usr/share/kodi/system/keymaps/remote.xml"
]

# 注意：在内部脚本中触发重启通常不建议直接通过 RunScript 调用 rebootoff
# 除非该脚本内部实现了具体的重启逻辑。这里保留原逻辑，但改用 executebuiltin
REBOOT_SCRIPT_CMD = "RunScript(special://skin/scripts/rebootoff.py,reboot)"

def execute_kodi_builtin(command):
    """
    使用 xbmc.executebuiltin 执行命令。
    这是 Kodi 内部脚本执行动作的标准方式，比 subprocess 调用 kodi-send 更可靠。
    """
    try:
        xbmc.executebuiltin(command)
    except Exception as e:
        xbmc.log(f"[Skin Init] Error executing builtin: {command}, Error: {str(e)}", level=xbmc.LOGERROR)

def execute_kodi_jsonrpc(method, params=None):
    """
    封装 JSON-RPC 调用，用于需要返回值或特定控制的操作
    """
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params or {},
        "id": 1
    }
    try:
        response = xbmc.executeJSONRPC(json.dumps(request))
        return json.loads(response)
    except Exception as e:
        xbmc.log(f"[Skin Init] JSONRPC Error: {str(e)}", level=xbmc.LOGERROR)
        return {}

def clean_autostart():
    """清理并维护 autostart.sh 文件"""
    if not is_coreelec_system():
        return

    need_add_mount = False
    mount_cmds_exist = {cmd: False for cmd in TARGET_MOUNT_CMDS}

    autostart_dir = os.path.dirname(AUTOSTART_PATH)
    if not os.path.exists(autostart_dir):
        os.makedirs(autostart_dir, exist_ok=True)

    lines = []
    if os.path.exists(AUTOSTART_PATH):
        try:
            with open(AUTOSTART_PATH, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except Exception:
            lines = []
            
        for cmd in TARGET_MOUNT_CMDS:
            for line in lines:
                if cmd.strip() in line.strip():
                    mount_cmds_exist[cmd] = True
                    break
    else:
        need_add_mount = True

    temp_lines = []
    if lines:
        skip_next = False
        for line in lines:
            line_stripped = line.strip()
            # 检查是否是需要移除的目标脚本注释或执行行
            is_target_line = False
            for script in target_scripts:
                # 提取脚本文件名进行匹配，例如从 "RunScript(...skinupdate.py)" 提取 "skinupdate.py"
                match = re.search(r'special://skin/scripts/([^)]+\.py)', script)
                if match:
                    script_name = match.group(1)
                    if script_name in line_stripped:
                        is_target_line = True
                        break
            
            if is_target_line:
                continue # 跳过这些行
            
            # 简单的孤立注释清理逻辑（可选，保持原逻辑大致不变）
            temp_lines.append(line)

        final_lines = []
        # 移除末尾空行
        while temp_lines and temp_lines[-1].strip() == "":
            temp_lines.pop()
        final_lines = temp_lines
    else:
        final_lines = []

    for cmd in TARGET_MOUNT_CMDS:
        if not mount_cmds_exist[cmd]:
            need_add_mount = True
            # 确保命令前后有换行，避免拼接错误
            final_lines.append(f"\n{cmd}\n")

    try:
        with open(AUTOSTART_PATH, "w", encoding="utf-8") as f:
            f.writelines(final_lines)
    except Exception as e:
        xbmc.log(f"[Skin Init] Failed to write autostart.sh: {e}", level=xbmc.LOGERROR)

    if need_add_mount:
        # 使用 executebuiltin 替代 subprocess
        execute_kodi_builtin(REBOOT_SCRIPT_CMD)

def update_tmdb_helper_settings():
    """更新 TMDb Helper 插件设置"""
    try:
        settings_rel_path = "special://userdata/addon_data/plugin.video.themoviedb.helper/settings.xml"
        settings_path = xbmcvfs.translatePath(settings_rel_path)
        
        if not os.path.exists(settings_path):
            return
            
        tree = ET.parse(settings_path)
        root = tree.getroot()
        
        modified = False
        
        target_settings = {
            "startup_notifications": "false",
            "sync_notifications": "false",
            "connection_notifications": "false",
            "use_alternate_api_url": "true"
        }
        
        for setting in root.findall(".//setting"):
            sid = setting.get("id")
            if sid in target_settings:
                expected_val = target_settings[sid]
                current_val = setting.text.strip() if setting.text else ""
                if current_val != expected_val:
                    setting.text = expected_val
                    modified = True
                    
        if modified:
            tree.write(settings_path, encoding="utf-8", xml_declaration=True)
            
    except Exception as e:
        xbmc.log(f"[Skin Init] TMDb Helper settings error: {e}", level=xbmc.LOGDEBUG)

def handle_addon_by_state(addon_id):
    """处理插件状态：如果启用则禁用，如果已禁用则删除"""
    try:
        # 使用 JSON-RPC 检查状态更准确，但 getCondVisibility 也可以
        is_enabled = xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})') == 1
        
        if is_enabled:
            # 禁用插件
            execute_kodi_jsonrpc(
                "Addons.SetAddonEnabled", 
                {"addonid": addon_id, "enabled": False}
            )
        else:
            # 如果已禁用，尝试删除插件目录
            if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
                addon_path = xbmcvfs.translatePath(os.path.join("special://home/addons/", addon_id))
                if os.path.exists(addon_path):
                    shutil.rmtree(addon_path)
                    xbmc.log(f"[Skin Init] Removed addon directory: {addon_path}", level=xbmc.LOGINFO)
                    
    except Exception as e:
        xbmc.log(f"[Skin Init] Handle addon error: {e}", level=xbmc.LOGERROR)

def process_target_addons():
    targets = [
        "service.favourites.auto.cover",
        "service.pinyin.indexer"
    ]
    
    for addon_id in targets:
        handle_addon_by_state(addon_id)

def check_and_update_gui_peak_luminance():
    """检查并更新 GUI 峰值亮度"""
    try:
        result = execute_kodi_jsonrpc(
            "Settings.GetSettingValue", 
            {"setting": "videoscreen.guipeakluminance"}
        )
        
        if "result" in result and "value" in result["result"]:
            current_value = result["result"]["value"]
            
            if current_value == 100 or current_value == 100.0:
                execute_kodi_jsonrpc(
                    "Settings.SetSettingValue",
                    {"setting": "videoscreen.guipeakluminance", "value": 50}
                )
    except Exception as e:
        xbmc.log(f"[Skin Init] Luminance error: {e}", level=xbmc.LOGDEBUG)

def update_skin_refreshrate_string():
    """更新皮肤字符串 refreshrate"""
    try:
        result = execute_kodi_jsonrpc(
            "Settings.GetSettingValue", 
            {"setting": "videoplayer.adjustrefreshrate"}
        )
        
        if "result" in result and "value" in result["result"]:
            current_value = result["result"]["value"]
            
            if isinstance(current_value, str):
                try:
                    current_value = int(current_value)
                except ValueError:
                    return
            
            value_map = {
                0: "关闭",
                1: "始终",
                2: "自适应",
                3: "仅起播时"
            }
            
            if current_value in value_map:
                target_desc = value_map[current_value]
                # 使用 executebuiltin 设置 Skin String
                execute_kodi_builtin(f"Skin.SetString(refreshrate, {target_desc})")
    except Exception as e:
        xbmc.log(f"[Skin Init] Refreshrate string error: {e}", level=xbmc.LOGDEBUG)

def remove_migu_playlist():
    target_file = "/storage/downloads/咪咕直播.m3u"
    try:
        if os.path.exists(target_file):
            os.remove(target_file)
            xbmc.log("[Skin Init] Removed Migu playlist", level=xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Skin Init] Remove playlist error: {e}", level=xbmc.LOGDEBUG)

def clean_migu_from_instance_settings():
    """清理 IPTV Simple 配置中的咪咕路径"""
    try:
        settings_rel_path = "special://userdata/addon_data/pvr.iptvsimple/instance-settings-1.xml"
        settings_path = xbmcvfs.translatePath(settings_rel_path)
        
        if not os.path.exists(settings_path):
            return
            
        tree = ET.parse(settings_path)
        root = tree.getroot()
        
        modified = False
        
        for setting in root.findall(".//setting[@id='m3uPath']"):
            path_value = setting.text
            if path_value and "咪咕直播" in path_value:
                setting.text = ""
                modified = True
                
        if modified:
            tree.write(settings_path, encoding="utf-8", xml_declaration=True)
            
    except Exception as e:
        xbmc.log(f"[Skin Init] Clean Migu settings error: {e}", level=xbmc.LOGDEBUG)

def execute_skin_onload_logic():
    """
    执行从皮肤 XML onload 标签转换而来的逻辑
    """
    try:
        # 1. Skin.SetString(info_delay,0)
        execute_kodi_builtin("Skin.SetString(info_delay,0)")
        
        # 2. Library HasContent Checks
        has_movies = xbmc.getCondVisibility('Library.HasContent(Movies)')
        has_tvshows = xbmc.getCondVisibility('Library.HasContent(TVShows)')
        
        if has_movies:
            execute_kodi_builtin("Skin.SetString(movielib,1)")
        else:
            execute_kodi_builtin("Skin.SetString(movielib,0)")
            
        if has_tvshows:
            execute_kodi_builtin("Skin.SetString(tvshowlib,1)")
        else:
            execute_kodi_builtin("Skin.SetString(tvshowlib,0)")
            
        # 3. Conditional Script: avdvplus.py
        cond_avdv = (not xbmc.getCondVisibility('Skin.HasSetting(autozhcn)')) and \
                    (not xbmc.getCondVisibility('String.Contains(Skin.String(BuildDate),Skin.String(langversion))') or \
                     xbmc.getCondVisibility('String.IsEmpty(Skin.String(langversion))'))
        if cond_avdv:
            execute_kodi_builtin("RunScript(special://skin/scripts/avdvplus.py,update)")
            
        # 4. Unconditional Scripts
        execute_kodi_builtin("RunScript(special://skin/scripts/zysort.py)")
        
        # 5. AlarmClock
        execute_kodi_builtin("AlarmClock(skinauto,RunScript(special://skin/scripts/skinauto.py),00:20,silent)")
        
        execute_kodi_builtin("RunScript(special://skin/scripts/ethtool.py,start)")
        
        # 6. Conditional Script: localposter.py
        if xbmc.getCondVisibility('Skin.HasSetting(localposter)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/localposter.py,check)")
            
        # 7. Conditional Script: cd2path.py
        if not xbmc.getCondVisibility('Skin.HasSetting(checkcd2path)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/cd2path.py)")
            
        # 8. Conditional Script: favcheck.py
        cond_fav = (not xbmc.getCondVisibility('Skin.HasSetting(TextTitle)')) and \
                   (not xbmc.getCondVisibility('Skin.HasSetting(smallthumb)')) and \
                   (not xbmc.getCondVisibility('Skin.HasSetting(bigthumb)'))
        if cond_fav:
            execute_kodi_builtin("RunScript(special://skin/scripts/favcheck.py)")
            
        # 9. Conditional Script: tvshow_view.py
        cond_tvview = (not xbmc.getCondVisibility('Skin.HasSetting(filtenable)')) and \
                      (not xbmc.getCondVisibility('String.IsEqual(Skin.String(tvshow_view),2)'))
        if cond_tvview:
            execute_kodi_builtin("RunScript(special://skin/scripts/tvshow_view.py)")
            
        # 10. Conditional Script: colorperday.py
        if not xbmc.getCondVisibility('Skin.HasSetting(daycoloroff)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/colorperday.py)")
            
        # 12. Conditional Script: dvautoset.py
        if not xbmc.getCondVisibility('Skin.HasSetting(checkdvset)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/dvautoset.py,start)")
            
        execute_kodi_builtin("RunScript(special://skin/scripts/network.py)")
        
        # 13. Conditional Script: skinupdate.py
        if not xbmc.getCondVisibility('Skin.HasSetting(allowskinupdate)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/skinupdate.py,start)")
            
        execute_kodi_builtin("RunScript(special://skin/scripts/version.py)")
        
        # 14. TMDbHelper Settings
        execute_kodi_builtin("Skin.SetBool(TMDbHelper.Service)")
        execute_kodi_builtin("Skin.SetString(TMDbHelper.MonitorContainer,99950)")
        execute_kodi_builtin("Skin.SetBool(TMDbHelper.DisableArtwork)")
        execute_kodi_builtin("Skin.Reset(TMDbHelper.DirectCallAuto)")
        
        # 15. Window & Properties
        execute_kodi_builtin("ReplaceWindow($INFO[System.StartupWindow])")
        execute_kodi_builtin("SetProperty(ReloadDone,1)")
        execute_kodi_builtin("SetProperty(ReloadDone,1,Home)")
        
        # 16. Conditional Script: startbgm.py
        if not xbmc.getCondVisibility('Skin.HasSetting(bgmoff)'):
            execute_kodi_builtin("RunScript(special://skin/scripts/startbgm.py)")
            
        # 17. Conditional AlarmClock: cd2reload
        cond_cd2 = xbmc.getCondVisibility('Skin.HasSetting(cd2UseCustompath)') and \
                   (not xbmc.getCondVisibility('String.IsEmpty(Skin.String(cd2Custompath))'))
        if cond_cd2:
            execute_kodi_builtin("AlarmClock(cd2reload,ReloadSkin(),00:02,silent)")
            
        # 18. Conditional Scripts: handon.py & autodns.py
        if not xbmc.getCondVisibility('System.ShowExitButton'):
            if not xbmc.getCondVisibility('Skin.HasSetting(checkedid)'):
                execute_kodi_builtin("RunScript(special://skin/scripts/handon.py)")
            if not xbmc.getCondVisibility('Skin.HasSetting(checkdns)'):
                execute_kodi_builtin("RunScript(special://skin/scripts/autodns.py)")
        
    except Exception as e:
        xbmc.log(f"[Skin Init] Onload logic error: {e}", level=xbmc.LOGERROR)

if __name__ == "__main__":
    xbmc.log("[Skin Init] Script started", level=xbmc.LOGINFO)
    
    # 1. 始终执行目标插件状态处理逻辑 (不限系统)
    process_target_addons()
    
    # 2. 始终执行 TMDB Helper 设置更新
    update_tmdb_helper_settings()
    
    # 3. 检查并更新 GUI 峰值亮度设置 (不限系统)
    check_and_update_gui_peak_luminance()
    
    # 4. 检查并更新皮肤字符串 refreshrate (不限系统)
    update_skin_refreshrate_string()
    
    # 5. 清理 instance-settings-1.xml 中的咪咕直播路径
    clean_migu_from_instance_settings()
    
    # 6. 仅在 CoreELEC 系统上执行清理和挂载逻辑
    if is_coreelec_system():
        clean_autostart()
        # 7. 在 CoreELEC 系统上执行 DV 类型检测脚本
        execute_kodi_builtin("RunScript(special://skin/scripts/dvtype.py,detect)")
        # 8. 检查并删除咪咕直播 m3u 文件
        remove_migu_playlist() 
        
    # 9. 执行皮肤 onload 逻辑转换
    # 注意：已移除 check_and_run_skinauto() 调用
    execute_skin_onload_logic()
    
    xbmc.log("[Skin Init] Script finished", level=xbmc.LOGINFO)