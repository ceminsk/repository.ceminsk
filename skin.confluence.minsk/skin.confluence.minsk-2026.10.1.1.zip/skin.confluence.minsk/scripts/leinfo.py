import xbmc
import xbmcvfs
import json
import os
import sys
import threading  # 新增：用于多线程处理

# 定义日志前缀
LOG_PREFIX = "[leinfo.py]"

def log(msg, level=xbmc.LOGINFO):
    """简化的日志输出函数"""
    xbmc.log(f"{LOG_PREFIX} {msg}", level)

def execute_json_rpc(method, params=None):
    """执行 JSON-RPC 指令"""
    request = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params:
        request["params"] = params
    
    try:
        response = xbmc.executeJSONRPC(json.dumps(request))
        return json.loads(response)
    except Exception as e:
        log(f"JSON-RPC Error: {e}", xbmc.LOGERROR)
        return None

def check_first_run():
    """检查是否是第一次运行"""
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    marker_file = os.path.join(userdata_path, 'leinfo_first_run_done.flag')
    
    if xbmcvfs.exists(marker_file):
        return False
    return True

def create_first_run_marker():
    """创建运行标记"""
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    marker_file = os.path.join(userdata_path, 'leinfo_first_run_done.flag')
    try:
        f = xbmcvfs.File(marker_file, 'w')
        if f:
            f.write("done")
            f.close()
            return True
    except:
        pass
    return False

def set_dvbridge_setting(value=False):
    """设置 dvbridge.enhancedinfo，如果设置项不存在也不报错"""
    params = {"setting": "dvbridge.enhancedinfo", "value": value}
    result = execute_json_rpc("Settings.SetSettingValue", params)
    
    if result and ('result' in result or (result.get('error', {}).get('code') == 34)):
        return True
    return False

def get_dvbridge_setting():
    """读取 dvbridge.enhancedinfo"""
    params = {"setting": "dvbridge.enhancedinfo"}
    result = execute_json_rpc("Settings.GetSettingValue", params)
    
    if result:
        if 'error' in result and result['error'].get('code') == 34:
            return False # 不存在则默认为 False
        if 'result' in result:
            return result['result'].get('value')
    return None

def check_xml_file():
    """检查 XML 文件是否存在及内容"""
    target_file = "/usr/share/kodi/media/cb1/DialogPlayerProcessInfo.xml"
    search_string = "Skin.String(minskinfo)"
    
    if not xbmcvfs.exists(target_file):
        return False, False

    try:
        f = xbmcvfs.File(target_file, 'r')
        if f:
            content = f.read()
            f.close()
            return True, (search_string in content)
    except:
        pass
    return False, False

def execute_mount_command():
    """执行 mount --bind"""
    source = "/storage/.kodi/addons/skin.confluence.minsk/1080p/DialogPlayerProcessInfo-le.xml"
    target = "/usr/share/kodi/media/cb1/DialogPlayerProcessInfo.xml"
    cmd = f"mount --bind {source} {target}"
    
    try:
        ret = os.system(cmd)
        return ret == 0
    except:
        return False

def logic_2():
    """逻辑2：根据设置项设置 Skin.String"""
    val = get_dvbridge_setting()
    
    # 判断真假
    is_true = False
    if isinstance(val, bool): is_true = val
    elif isinstance(val, str): is_true = val.lower() == 'true'
    elif isinstance(val, int): is_true = bool(val)
        
    if is_true:
        # 情况1：值为 true
        log("Logic2: dvbridge=true -> SetString(minskinfo,0)")
        xbmc.executebuiltin("Skin.SetString(minskinfo,0)")
    else:
        # 情况2：值为 false
        log("Logic2: dvbridge=false -> Setting dvbridge=true & SetString(minskinfo,1)")
        set_dvbridge_setting(True)  # 先将其设置为 true
        xbmc.executebuiltin("Skin.SetString(minskinfo,1)")

def handle_start_param():
    """处理 start 参数"""
    log("Start: Checking first run...")
    if check_first_run():
        log("Start: First run detected. Setting dvbridge=false.")
        set_dvbridge_setting(False)
        create_first_run_marker()
    else:
        log("Start: Not first run.")

    log("Start: Checking XML file...")
    exists, contains = check_xml_file()
    
    if not exists:
        log("Start: File not found. Exit.")
        return
        
    if contains:
        log("Start: String found. Exit.")
        return
        
    log("Start: String not found. Mounting & Reloading...")
    if execute_mount_command():
        xbmc.executebuiltin("ReloadSkin()")
        log("Start: ReloadSkin called.")
    else:
        log("Start: Mount failed.")

# 新增：后台线程执行的函数
def delayed_hidelogo_logic():
    """在后台线程中执行 hidelogo 的延迟切换"""
    try:
        log("Thread: Set hidelogo to 0")
        xbmc.executebuiltin("Skin.SetString(hidelogo,0)")
        
        log("Thread: Waiting 4 seconds...")
        xbmc.sleep(4000)
        
        log("Thread: Set hidelogo to 1")
        xbmc.executebuiltin("Skin.SetString(hidelogo,1)")
    except Exception as e:
        log(f"Thread Error: {e}", xbmc.LOGERROR)

def handle_play_param():
    """处理 play 参数"""
    
    # --- 新增逻辑：启动后台线程 ---
    # 这样原有的逻辑可以立即继续执行，而 hidelogo 的逻辑在后台独立运行
    t = threading.Thread(target=delayed_hidelogo_logic)
    t.daemon = True  # 设置为守护线程，主程序退出时自动结束
    t.start()
    # --------------------------

    # 1. 读取 Skin.String(minskinfo) 的值
    minskinfo_val = xbmc.getInfoLabel('Skin.String(minskinfo)')
    log(f"Play: Skin.String(minskinfo)='{minskinfo_val}'")
    
    # 2. 如果值为 "1"，则设置 dvbridge.enhancedinfo 为 false
    if minskinfo_val == '1':
        log("Play: minskinfo is '1'. Setting dvbridge=false.")
        set_dvbridge_setting(False)
    else:
        log("Play: minskinfo is not '1'. Skipping dvbridge set.")
        
    # 3. 确认 XML 文件是否存在
    log("Play: Checking XML file...")
    exists, contains = check_xml_file()
    
    if not exists:
        log("Play: File not found. Exit.")
        return
        
    if not contains:
        log("Play: String not found. Mounting & Reloading...")
        if execute_mount_command():
            xbmc.executebuiltin("ReloadSkin()")
            log("Play: ReloadSkin called.")
        else:
            log("Play: Mount failed.")
    else:
        log("Play: String found. Skipping mount.")
            
    # 4. 执行逻辑2
    logic_2()

def handle_stop_param():
    """处理 stop 参数"""
    log("Stop: Setting dvbridge.enhancedinfo to false...")
    set_dvbridge_setting(False)
    
    log("Stop: Clearing Window(playerprocessinfo) properties...")
    xbmc.executebuiltin("ClearProperty(, playerprocessinfo)")
    
    log("Stop: Setting minskinfo to 0...")
    xbmc.executebuiltin("Skin.SetString(minskinfo,0)")
    
    log("Stop: Completed.")

def main():
    if len(sys.argv) > 1:
        param = sys.argv[1]
        if param == 'start':
            handle_start_param()
        elif param == 'play':
            handle_play_param()
        elif param == 'stop':
            handle_stop_param()

if __name__ == '__main__':
    main()