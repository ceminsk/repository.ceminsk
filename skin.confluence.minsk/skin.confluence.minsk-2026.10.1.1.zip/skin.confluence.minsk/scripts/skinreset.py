#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KODI皮肤重置脚本（修复translatePath兼容问题）
功能：设置指定皮肤字符串 + 删除跨平台的idkey文件
兼容：CoreELEC (Linux) / Windows 系统 + KODI 18/19/20+
"""
import xbmc
import xbmcvfs  # 新增：导入vfs模块处理路径（KODI 19+必需）
import os

# ======================== 第一步：执行Skin.SetString命令 ========================
# 设置authfail为1
xbmc.executebuiltin('Skin.SetString(authfail,1)')
# 清空以下皮肤字符串
xbmc.executebuiltin('Skin.SetString(skinauth,"")')
xbmc.executebuiltin('Skin.SetString(authdate,"")')
xbmc.executebuiltin('Skin.SetString(skinauthhide,"")')

# 日志记录：确认字符串设置完成
xbmc.log("已执行Skin.SetString命令：authfail=1，清空skinauth/authdate/skinauthhide", level=xbmc.LOGINFO)

# ======================== 第二步：跨平台删除idkey文件（修复路径兼容） ========================
# 1. 兼容KODI 18/19+的路径转换（自动适配版本）
try:
    # 优先使用KODI 19+的新API
    userdata_path = xbmcvfs.translatePath('special://userdata/')
except AttributeError:
    # 兼容KODI 18及以下的旧API
    userdata_path = xbmc.translatePath('special://userdata/')

# 2. 构建idkey文件的完整路径（自动处理系统路径分隔符）
idkey_file_path = os.path.join(
    userdata_path,
    'addon_data',
    'skin.confluence.minsk',
    'idkey'
)

# 3. 检查并删除文件（带异常处理，避免脚本崩溃）
# 兼容KODI 19+的文件存在性检查（xbmcvfs.exists）
if xbmcvfs.exists(idkey_file_path):
    try:
        # 先关闭可能的文件句柄，再删除
        xbmcvfs.delete(idkey_file_path)
        xbmc.log(f"成功删除文件：{idkey_file_path}", level=xbmc.LOGINFO)
    except Exception as e:
        # 记录删除失败的错误日志
        xbmc.log(f"删除文件失败：{idkey_file_path}，错误信息：{str(e)}", level=xbmc.LOGERROR)
else:
    # 文件不存在时仅记录信息，不报错
    xbmc.log(f"文件不存在，无需删除：{idkey_file_path}", level=xbmc.LOGINFO)

# 脚本执行完成日志
xbmc.log("皮肤重置脚本执行完毕", level=xbmc.LOGINFO)