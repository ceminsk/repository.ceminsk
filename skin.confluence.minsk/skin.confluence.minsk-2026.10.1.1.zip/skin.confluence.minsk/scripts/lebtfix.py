#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LibreELEC 通用蓝牙设备一键配对（Kodi 脚本 / 命令行 双用）

适用对象
--------
不绑定任何型号或 MAC，适用于 BlueZ 能管理的所有蓝牙 HID 设备：
蓝牙遥控器、蓝牙键盘、蓝牙鼠标、游戏手柄等（BLE HOGP 与经典蓝牙均可）。
也可以配对耳机/音箱，但这类设备不会生成输入节点，属正常现象。

局限（重要）
-----------
1. 「清除设备端旧配对」的按键因厂商而异，脚本无法代劳。若日志出现
   「认证失败（错误码 0x05）」，说明设备端仍保存旧密钥，必须在设备上
   清配对/复位（取电池、长按复位组合键、恢复出厂等，以说明书为准）后重试。
2. 使用免密配对代理，适用于「无需输入配对码」的设备。
   要求输入 6 位配对码的蓝牙键盘等需另配交互式代理。
3. 常驻代理会自动批准所有配对/授权请求，公共环境慎用。

Kodi 内行为
-----------
菜单共三项：「一键配对 / 重新配对」「查看蓝牙状态」「删除蓝牙配对」。
点「一键配对」-> 弹出确认窗口「配对开始后，请启动遥控器的配对模式！」
-> 确认后扫描并列出所有搜到的蓝牙设备 -> 用户选择 -> 自动安装授权代理
补丁 -> 先扫描发现设备再发起配对（首次失败自动清理主机缓存并重试一次）
-> 显示结果。进度条、状态页、结果框全程使用中文。
点「删除蓝牙配对」-> 列出所有已配对设备 -> 用户选择 -> 二次确认
-> 断开连接 + 移除配对 + 清理残留绑定缓存（删除前自动备份到 /tmp）
-> 显示结果，并提示需在设备端清除旧配对才能日后重新配对。

主选单常驻：任意一项执行完毕（或中途取消）后都会自动回到一级主选单，
直到用户按「返回 / ESC」退出；带参数调用（如 ,status / ,pair / ,remove /
,install）也会先执行该动作再回到主选单。仅 agent（systemd 内部调用）
与命令行模式保持单次执行后退出。

皮肤调用方式
------------
  RunScript(special://skin/scripts/btpair.py)              弹出三项菜单
  RunScript(special://skin/scripts/btpair.py,pair)         直接进配对流程
  RunScript(special://skin/scripts/btpair.py,status)       直接看状态
  RunScript(special://skin/scripts/btpair.py,remove)       直接进删除流程
  RunScript(script.libreelec.btfix)                        插件方式（需重启 Kodi 注册）

命令行（SSH）
-------------
  python3 btpair.py status              查看所有已知蓝牙设备状态
  python3 btpair.py scan                扫描并列出设备（只读）
  python3 btpair.py pair                扫描 -> 列出 -> 选择 -> 配对
  python3 btpair.py pair AA:BB:CC:DD:EE:FF   指定 MAC 直接配对（自动化用）
  python3 btpair.py remove              列出已配对设备 -> 选择 -> 删除
  python3 btpair.py remove AA:BB:CC:DD:EE:FF  指定 MAC 直接删除（unpair 同义）
  python3 btpair.py install / uninstall      维护补丁
  python3 btpair.py agent                    供 systemd 调用，勿手敲
"""

import os
import re
import sys
import time
import signal
import shutil
import subprocess

try:
    import xbmc
    import xbmcgui
    KODI = True
except ImportError:
    KODI = False

PYTHON = "/usr/bin/python3"
BASE = "/storage/.config/libreelec-bt-fix"
CANONICAL = BASE + "/btpair.py"
UNIT_DIR = "/storage/.config/system.d"
UNIT = UNIT_DIR + "/bluez-agent.service"
UNIT_NAME = "bluez-agent.service"
WANTS = UNIT_DIR + "/kodi.target.wants/" + UNIT_NAME
SCAN_LOG = "/tmp/btpair-scan.log"
PAIR_LOG = "/tmp/btpair-pair.log"
REMOVE_LOG = "/tmp/btpair-remove.log"
BT_CACHE_ROOT = "/storage/.cache/bluetooth"
SCAN_SEC = 12
PAIR_SEC = 16

REMOVE_CONFIRM = (
    "将删除该设备的蓝牙配对：\n\n"
    "  %s  [%s]\n\n"
    "· 会立即断开连接，并清除主机端保存的绑定密钥；\n"
    "· 删除后该设备按键立即失效，主机端无法撤销（仅 /tmp 有临时备份）；\n"
    "· 设备端通常仍保存旧配对，日后重新配对前必须先在设备上\n"
    "  清除配对 / 复位（取电池或厂商复位组合键），否则会出现\n"
    "  「认证失败（错误码 0x05）」。\n\n"
    "确定要删除吗？"
)

SELF = os.path.realpath(__file__)
ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
MAC_RE = re.compile(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")
DEV_RE = re.compile(
    r"(?:\[NEW\]\s+)?Device\s+((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\s*(.*)$"
)

START_HINT = "配对开始后，请启动遥控器的配对模式！"

GENERIC_RESET_HINT = (
    "【设备端仍保存旧配对密钥】\n"
    "日志显示「认证失败（错误码 0x05）」：主机端绑定已清空，\n"
    "但遥控器/设备端还留着旧密钥，双方互不相认，连上立刻被踢掉。\n\n"
    "请先在设备端清除旧配对 / 恢复出厂，常见方式：\n"
    "  - 取出电池 10 秒以上再装回；\n"
    "  - 长按厂商指定的复位组合键（指示灯连闪数次）；\n"
    "  - 华为 R22 示例：长按 OK + 频道+(CH+)，红灯连闪 4 次。\n"
    "然后重新让设备进入配对模式，再运行一次「一键配对」。"
)

CONN_FAILED_HINT = (
    "【设备连上后立即断开】\n"
    "主机已连接到设备，但配对尚未开始链路就被断开。常见原因：\n"
    "  - 设备已退出配对模式（配对窗口通常只有 30~60 秒）；\n"
    "  - 设备端仍残留旧配对，拒绝新的配对请求；\n"
    "  - 主机侧残留的设备缓存导致链路状态异常。\n\n"
    "脚本已自动清理主机缓存并重试一次。若仍失败，请重新在设备上\n"
    "执行复位（清除旧密钥），再进入配对模式后立即重试。"
)

UNIT_CONTENT = """[Unit]
Description=常驻蓝牙默认授权代理（通用配对补丁）
After=bluetooth.service kodi.service
StartLimitInterval=0

[Service]
Type=simple
ExecStart={python} {canonical} agent
Restart=always
RestartSec=10

[Install]
WantedBy=kodi.target
"""

# 配对会话中「先扫描、后配对」的扫描秒数。BLE HID 遥控器多数会在
# 扫描阶段自行发起配对（默认 Agent 自动批准），跳过扫描直接 pair
# 会得到「连接尝试失败：连上即断」。
PAIR_SCAN_SEC = 9


def _bin(name, default):
    for p in ("/usr/bin/" + name, "/bin/" + name, "/usr/sbin/" + name, "/sbin/" + name):
        if os.path.exists(p):
            return p
    return default


BT = _bin("bluetoothctl", "/usr/bin/bluetoothctl")
SYSC = _bin("systemctl", "/usr/bin/systemctl")
JOURNAL = _bin("journalctl", "/usr/bin/journalctl")


def sleep(sec):
    if KODI:
        xbmc.sleep(int(sec * 1000))
    else:
        time.sleep(sec)


def run(cmd, timeout=25):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, errors="replace")
        return (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return "ERR: %s\n" % exc


def first_line(text):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    return lines[0] if lines else ""


def read_file(path):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


# ---------------------------------------------------------------- 中文显示层
# 进度条、状态页、结果框一律显示中文；bluetoothctl 的原始英文只写进日志。

PROP_CN = {
    "Paired": "已配对",
    "Bonded": "已绑定",
    "Trusted": "已信任",
    "Connected": "已连接",
    "WakeAllowed": "允许唤醒",
    "Blocked": "已屏蔽",
    "LegacyPairing": "传统配对",
    "CablePairing": "有线配对",
}

STATE_CN = {
    "active": "运行中", "inactive": "未运行", "failed": "故障",
    "activating": "启动中", "deactivating": "停止中",
    "enabled": "已启用", "disabled": "未启用",
    "enabled-runtime": "已启用（临时）", "unknown": "未知", "": "未知",
}

CMD_LABELS = (
    (r"^agent\b", "正在注册免密配对代理…"),
    (r"^default-agent\b", "正在设为默认授权代理…"),
    (r"^disconnect\b", "正在断开设备连接…"),
    (r"^remove\b", "正在清除旧配对记录…"),
    (r"^scan on\b", "正在搜索蓝牙设备（请启动设备配对模式）…"),
    (r"^scan off\b", "正在停止搜索…"),
    (r"^devices\b", "正在读取设备列表…"),
    (r"^pair\b", "正在配对，请保持设备处于配对模式…"),
    (r"^trust\b", "正在设为信任设备…"),
    (r"^connect\b", "正在连接设备…"),
    (r"^info\b", "正在读取配对结果…"),
    (r"^quit\b", "正在完成…"),
)

PAIR_ERR_CN = (
    ("AlreadyExists", "设备已在搜索阶段自行完成配对，无需重复配对"),
    ("ConnectionAttemptFailed", "连接尝试失败：设备连上后立即断开"),
    ("AuthenticationFailed", "认证失败：设备端仍保存旧配对密钥"),
    ("AuthenticationCanceled", "设备取消了配对"),
    ("AuthenticationRejected", "设备拒绝了配对"),
    ("AuthenticationTimeout", "配对超时，设备可能已退出配对模式"),
    ("ConnectionRefused", "设备拒绝连接"),
    ("NoSuchDevice", "设备已不在可发现范围"),
    ("NotReady", "蓝牙适配器尚未就绪"),
    ("InProgress", "已有配对流程正在进行"),
    ("NotSupported", "设备不支持此配对方式"),
    ("Failed", "配对失败"),
)


def yn(value):
    v = str(value).strip().lower()
    return {"yes": "是", "no": "否", "true": "是", "false": "否"}.get(v, str(value))


def cn_state(value):
    return STATE_CN.get(str(value).strip().lower(), str(value))


def cmd_label(cmd):
    """进度条显示：pair -> 正在配对…（不暴露 bluetoothctl 英文命令）。"""
    for pat, label in CMD_LABELS:
        if re.match(pat, cmd.strip(), re.I):
            return label
    return "正在处理…"


def log_summary(txt, limit=12):
    """把 bluetoothctl 的英文原始输出翻译成中文要点，供结果框显示。"""
    t = ANSI_RE.sub("", txt).replace("\r", "\n")
    events = []

    def add(s):
        if s not in events:
            events.append(s)

    if re.search(r"Agent registered|Agent is already registered", t, re.I):
        add("免密配对代理已就绪")
    if re.search(r"Default agent request successful", t, re.I):
        add("已设为默认授权代理")
    if re.search(r"Discovery started", t, re.I):
        add("已开始搜索蓝牙设备")
    for mac, name in re.findall(
            r"\[NEW\] Device\s+([0-9A-Fa-f:]{17})\s*(.*)", t)[:6]:
        add("发现设备：%s  %s" % (name.strip() or "未命名设备", mac))
    if re.search(r"Discovery stopped", t, re.I):
        add("已停止搜索")
    if re.search(r"Attempting to pair with", t, re.I):
        add("已向设备发起配对请求")
    if "Pairing successful" in t:
        add("配对成功")
    # 具体错误优先；通用 Failed 只在没匹配到具体错误时补充，避免重复
    specific = False
    for key, cn in PAIR_ERR_CN:
        if key == "Failed":
            continue
        if re.search(r"Failed to pair:.*" + key + r"\b", t):
            add("配对结果：" + cn)
            specific = True
    if not specific and re.search(r"Failed to pair", t):
        add("配对结果：配对失败")
    if re.search(r"auth failed|Authentication Failed", t, re.I):
        add("认证失败：双方密钥不匹配（错误码 0x05）")
    if re.search(r"Connection successful", t, re.I):
        add("连接成功")
    if re.search(r"trust succeeded", t, re.I):
        add("已设为信任设备")
    if re.search(r"Device has been removed", t, re.I):
        add("旧配对记录已清除")
    if re.search(r"Device .* not available", t, re.I):
        add("设备已退出可发现状态")
    if re.search(r"\[CHG\] Device .* Connected: yes", t):
        add("连接已建立")
    if re.search(r"\[CHG\] Device .* Connected: no", t):
        add("连接已断开")
    if re.search(r"LE.Disconnected|disconnected with reason", t, re.I):
        add("链路被设备断开")
    if not events:
        add("（无可用过程信息，详见日志文件）")
    return events[-limit:]


def show_text(title, text):
    if KODI:
        xbmcgui.Dialog().textviewer(title, text)
    else:
        print("\n=== %s ===\n%s" % (title, text))


def yesno(title, text, yes="确定", no="取消", cli_default=True):
    if not KODI:
        print("%s\n%s" % (title, text))
        if cli_default:
            print("(命令行模式默认继续)")
            return True
        try:
            answer = input("请输入 yes 确认，其它任意输入取消：").strip().lower()
        except (EOFError, OSError):
            return False
        return answer in ("yes", "y")
    try:
        return xbmcgui.Dialog().yesno(title, text, yeslabel=yes, nolabel=no)
    except TypeError:
        return xbmcgui.Dialog().yesno(title, text)


# ---------------------------------------------------------------- 进度适配

class CliProgress:
    def __init__(self, title=""):
        self.last = None

    def update(self, pct, text):
        if text != self.last:
            print("[%3d%%] %s" % (pct, text), flush=True)
            self.last = text

    def canceled(self):
        return False

    def close(self):
        pass


class KodiProgress:
    def __init__(self, title="LibreELEC 蓝牙配对"):
        self.d = xbmcgui.DialogProgress()
        self.d.create(title, "准备中…")

    def update(self, pct, text):
        self.d.update(max(0, min(100, int(pct))), text)

    def canceled(self):
        return self.d.iscanceled()

    def close(self):
        self.d.close()


def make_progress(title=""):
    return KodiProgress(title) if KODI else CliProgress(title)


class Canceled(Exception):
    pass


# ---------------------------------------------------------------- 设备查询

def parse_devices(text):
    """从 bluetoothctl 输出中提取 (MAC, 名称)，兼容 [NEW] Device / Device 行和 ANSI 覆写。"""
    found = {}
    for raw in text.splitlines():
        for part in re.split(r"[\r\n]+", ANSI_RE.sub("", raw)):
            part = part.strip()
            if "[DEL]" in part or not part:
                continue
            m = DEV_RE.search(part)
            if not m:
                continue
            mac = m.group(1).upper()
            name = m.group(2).strip()
            if name.lower().startswith(("not ", "has been", "is ")):
                continue  # 忽略 "not available" / "has been removed" 等提示行
            found.setdefault(mac, name or "未命名设备")
    return [(m, n) for m, n in found.items()]


def known_devices():
    return parse_devices(run([BT, "devices"], 20))


def paired_devices():
    """列出已配对设备，兼容 BlueZ 5.87（devices Paired）与旧版（paired-devices）。"""
    result = {}
    # BlueZ 5.87 起 paired-devices 已移除，改用 devices <过滤器>
    for cmd in ([BT, "devices", "Paired"], [BT, "paired-devices"]):
        for mac, name in parse_devices(run(cmd, 20)):
            result.setdefault(mac, name)
    for mac, name in known_devices():
        if mac in result:
            continue
        p = props(mac)
        if p.get("Paired") == "yes" or p.get("Bonded") == "yes" or has_ltk(mac):
            result[mac] = name
    # BlueZ 已忘记、但磁盘上仍有绑定缓存的残留记录，也要让用户能清理
    try:
        for ad in os.listdir(BT_CACHE_ROOT):
            ad_path = os.path.join(BT_CACHE_ROOT, ad)
            if not os.path.isdir(ad_path):
                continue
            for entry in os.listdir(ad_path):
                mac = entry.upper()
                if MAC_RE.match(mac) and mac not in result:
                    result[mac] = "缓存残留记录"
    except OSError:
        pass
    return [(m, n) for m, n in result.items()]


def bluez_paired(mac):
    """BlueZ 当前是否仍认为该设备已配对（用 info 属性，不依赖版本相关命令）。"""
    p = props(mac)
    return p.get("Paired") == "yes" or p.get("Bonded") == "yes"


def props(mac):
    d = {}
    for line in run([BT, "info", mac], 20).splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) == 2 and parts[0].endswith(":"):
            d[parts[0][:-1]] = parts[1].strip()
    return d


def has_ltk(mac):
    root = BT_CACHE_ROOT
    try:
        for ad in os.listdir(root):
            p = os.path.join(root, ad, mac, "info")
            try:
                with open(p, "r", errors="replace") as f:
                    if "[LongTermKey]" in f.read():
                        return True
            except OSError:
                pass
    except OSError:
        pass
    return False


def hid_count():
    try:
        with open("/proc/bus/input/devices", "r", errors="replace") as f:
            return f.read().count("Bus=0005")
    except OSError:
        return 0


def kodi_agent_errors():
    try:
        with open("/storage/.kodi/temp/kodi.log", "r", errors="replace") as f:
            return f.read().count("request_authorization")
    except OSError:
        return 0


def service_state():
    return first_line(run([SYSC, "is-active", UNIT_NAME], 10)) or "unknown"


def device_label(mac, name):
    p = props(mac)
    if p.get("Paired") == "yes" and has_ltk(mac):
        tag = "[已配对 · 绑定完好]"
    elif p.get("Paired") == "yes":
        tag = "[已配对 · 无密钥]"
    elif p.get("Trusted") == "yes":
        tag = "[已信任 · 未配对]"
    else:
        tag = "[新设备]"
    return "%s   %s   %s" % (name, mac, tag)


def paired_label(mac, name):
    p = props(mac)
    if p.get("Connected") == "yes":
        state = "已连接"
    elif p.get("Paired") == "yes":
        state = "休眠/未连接"
    else:
        state = "残留配对记录"
    return "%s   %s   [%s · 绑定密钥%s]" % (
        name, mac, state, "已保存" if has_ltk(mac) else "未保存")


def status_text():
    devs = known_devices()
    lines = [
        "========== 蓝牙状态 ==========",
        "蓝牙输入设备数量：%d" % hid_count(),
        "Kodi 授权代理报错：%d 次" % kodi_agent_errors(),
        "常驻授权代理服务：%s" % cn_state(service_state()),
        "已知蓝牙设备数量：%d" % len(devs),
    ]
    if not devs:
        lines.append("（暂无已知设备，可在「一键配对」中搜索）")
    for mac, name in devs:
        p = props(mac)
        lines.append("")
        lines.append("· %s  [%s]" % (name, mac))
        for key in ("Paired", "Bonded", "Trusted", "Connected", "WakeAllowed"):
            if key in p:
                lines.append("    %s：%s" % (PROP_CN.get(key, key), yn(p[key])))
        lines.append("    绑定密钥：%s" % ("已保存" if has_ltk(mac) else "未保存"))
        if p.get("Connected") != "yes" and p.get("Paired") == "yes":
            lines.append("    （未连接通常是设备休眠，按任意键即可自动回连）")
    lines.append("==============================")
    return "\n".join(lines)


# ---------------------------------------------------------------- Agent 补丁

def install_agent():
    """把当前脚本复制为规范副本，并注册开机自启的 headless 默认 Agent。"""
    os.makedirs(BASE, exist_ok=True)
    os.makedirs(UNIT_DIR + "/kodi.target.wants", exist_ok=True)
    if os.path.realpath(SELF) != os.path.realpath(CANONICAL):
        shutil.copy2(SELF, CANONICAL)
    os.chmod(CANONICAL, 0o755)
    with open(UNIT, "w", encoding="utf-8") as f:
        f.write(UNIT_CONTENT.format(python=PYTHON, canonical=CANONICAL))
    if os.path.lexists(WANTS):
        os.remove(WANTS)
    os.symlink(UNIT, WANTS)
    run([SYSC, "daemon-reload"], 30)
    run([SYSC, "restart", UNIT_NAME], 40)
    sleep(2)
    return (
        "授权代理补丁已自动安装。\n"
        "服务状态：%s\n"
        "开机自启：%s\n"
        "脚本位置：%s\n"
        % (cn_state(service_state()),
           cn_state(first_line(run([SYSC, "is-enabled", UNIT_NAME], 10))),
           CANONICAL)
    )


def ensure_agent(force=False):
    """脚本运行时自动确保补丁在位；已正确配置时不打断现有连接。"""
    if not force:
        active = first_line(run([SYSC, "is-active", UNIT_NAME], 10))
        enabled = first_line(run([SYSC, "is-enabled", UNIT_NAME], 10))
        unit_txt = read_file(UNIT)
        if (active == "active" and enabled in ("enabled", "enabled-runtime")
                and CANONICAL in unit_txt and " agent" in unit_txt):
            return ""
    return install_agent()


def uninstall_agent():
    run([SYSC, "stop", UNIT_NAME], 20)
    run([SYSC, "disable", UNIT_NAME], 20)
    for p in (WANTS, UNIT):
        try:
            os.remove(p)
        except OSError:
            pass
    run([SYSC, "daemon-reload"], 30)
    return "常驻 Agent 补丁已卸载，系统还原。"


def agent_forever():
    """由 systemd 调用：常驻 headless 默认 Agent。"""
    os.makedirs(BASE, exist_ok=True)

    def _stop(_sig, _frame):
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    proc = subprocess.Popen(
        [BT, "--agent", "NoInputNoOutput"],
        stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, text=True, bufsize=1,
    )
    try:
        proc.stdin.write("agent NoInputNoOutput\n")
        proc.stdin.flush()
        proc.stdin.write("default-agent\n")
        proc.stdin.flush()
        while proc.poll() is None:
            sleep(30)  # 每 30 秒重申 default-agent，防止 Kodi 抢回
            if proc.poll() is None:
                proc.stdin.write("default-agent\n")
                proc.stdin.flush()
    except (SystemExit, KeyboardInterrupt, BrokenPipeError, OSError):
        pass
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            pass


def clear_gatt_cache(mac):
    """只清理该设备的 GATT 属性缓存，绝不触碰含绑定密钥的 info 文件。

    孤立的属性缓存（BlueZ 已忘记设备、文件却还在）会让新连接沿用陈旧的
    链路状态；清理它可避免「连上即断」。删除前复制到 /tmp 备份。
    """
    cleaned = []
    backup = "/tmp/btpair-gatt-" + time.strftime("%Y%m%d-%H%M%S")
    try:
        adapters = os.listdir(BT_CACHE_ROOT)
    except OSError:
        return "", cleaned
    for ad in adapters:
        src = os.path.join(BT_CACHE_ROOT, ad, "cache", mac)
        if not os.path.isfile(src):
            continue
        dst = os.path.join(backup, ad, "cache", mac)
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            os.remove(src)
            cleaned.append(os.path.relpath(src, BT_CACHE_ROOT))
        except OSError:
            pass
    return (backup if cleaned else ""), cleaned


# ---------------------------------------------------------------- 会话执行

def bt_session(commands, logpath, progress=None):
    """保持 bluetoothctl 会话存活，逐条发命令并等待；一次性管道会打断异步 pair。"""
    total = sum(w for _, w in commands) or 1
    elapsed = 0
    proc = None
    try:
        with open(logpath, "w", errors="replace") as f:
            proc = subprocess.Popen(
                [BT, "--timeout", "30"], stdin=subprocess.PIPE,
                stdout=f, stderr=subprocess.STDOUT, text=True, bufsize=1,
            )
            for cmd, wait in commands:
                if progress:
                    progress.update(min(99, int(elapsed * 100 / total)), cmd_label(cmd))
                proc.stdin.write(cmd + "\n")
                proc.stdin.flush()
                for _ in range(int(wait)):
                    if progress and progress.canceled():
                        raise Canceled()
                    sleep(1)
                elapsed += wait
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.terminate()
    except Canceled:
        if proc is not None:
            try:
                proc.stdin.write("quit\n")
                proc.stdin.flush()
            except Exception:
                pass
            proc.terminate()
        raise
    return read_file(logpath)


def scan_devices(progress=None):
    cmds = [
        ("scan on", SCAN_SEC),
        ("devices", 1),
        ("scan off", 1),
        ("quit", 0),
    ]
    txt = bt_session(cmds, SCAN_LOG, progress)
    return parse_devices(txt)


# ---------------------------------------------------------------- 配对

def do_pair(mac, name, force=False, progress=None, scan_sec=None):
    """先扫描发现设备、再发起配对；失败时清理主机缓存并自动重试一次。

    scan_sec 可由调用方缩短：从皮肤菜单进入时前面已经扫描过一次，
    缩短可避免占用遥控器有限的配对窗口。
    """
    paired = props(mac).get("Paired") == "yes"
    bonded = has_ltk(mac)
    if not force and paired and bonded:
        return True, (
            "%s 已配对且绑定密钥完好，无需重配。\n"
            "当前未连接通常是设备休眠，按任意键即可自动回连。\n"
            "（如需强制重配，请在菜单里选择该设备并确认。）\n\n%s"
            % (name, status_text())
        )

    agent_note = ensure_agent(force=False)
    need_remove = force or paired or bonded
    # 未配对时先清掉孤立的 GATT 属性缓存（绝不触碰含密钥的 info 文件）
    if not paired:
        clear_gatt_cache(mac)

    def session(after_restart=False):
        cmds = [
            ("agent NoInputNoOutput", 1),
            ("default-agent", 1),
        ]
        if need_remove and not after_restart:
            cmds += [
                ("disconnect " + mac, 1),
                ("remove " + mac, 2),
            ]
        # 关键：必须先扫描。BLE HID 设备常在扫描阶段自行发起配对，
        # 跳过扫描直接 pair 会得到「连接尝试失败：连上即断」。
        cmds += [
            ("scan on", scan_sec or PAIR_SCAN_SEC),
            ("devices", 1),
            ("scan off", 1),
            ("pair " + mac, PAIR_SEC),
            ("trust " + mac, 2),
            ("info " + mac, 1),
            ("quit", 0),
        ]
        return bt_session(cmds, PAIR_LOG, progress)

    txt = ""
    notes = []
    for attempt in range(2):
        if progress:
            progress.update(2, "第 %d 次配对准备…" % (attempt + 1))
        try:
            txt = session(after_restart=(attempt > 0))
        except Canceled:
            if progress:
                progress.update(100, "已取消")
            return False, "已取消。\n\n" + status_text()

        if (props(mac).get("Paired") == "yes" and has_ltk(mac)) \
                or "Pairing successful" in txt:
            break

        # 只有本次确实搜索到设备，重试才有意义；否则多半已退出配对模式
        discovered = bool(re.search(
            r"\[NEW\] Device\s+" + re.escape(mac) +
            r"|^\s*Device\s+" + re.escape(mac) +
            r"|\[CHG\] Device\s+" + re.escape(mac),
            txt, re.I | re.M))
        if not discovered or attempt == 1:
            if not discovered:
                notes.append("本次没有搜索到该设备，请确认设备已进入配对模式。")
            break
        notes.append("首次配对未成功，已清理主机缓存并重启蓝牙服务，正在重试。")
        if progress:
            progress.update(60, "首次未成功，正在清理缓存并重启蓝牙服务…")
        clear_gatt_cache(mac)
        run([SYSC, "restart", "bluetooth"], 40)
        sleep(4)
        run([SYSC, "restart", UNIT_NAME], 40)
        sleep(2)

    # connect 用独立进程执行，避免设备不存在时的交互提示卡住会话
    if props(mac).get("Paired") == "yes":
        run([BT, "connect", mac], 20)
        sleep(4)

    if props(mac).get("Paired") == "yes" and has_ltk(mac):
        note = "%s 配对成功，绑定密钥已写入主机。" % name
        if hid_count() == 0:
            note += "\n暂未生成输入设备，按一下设备任意键唤醒即可。"
        if "AlreadyExists" in txt:
            note += "\n（设备在搜索阶段自行完成了绑定，属正常现象。）"
        if notes:
            note += "\n" + "\n".join(notes)
        return True, note + "\n\n" + (agent_note + "\n" if agent_note else "") + status_text()

    cn = log_summary(txt)
    if re.search(r"auth failed|Authentication Failed", txt, re.I):
        reason = GENERIC_RESET_HINT
    elif re.search(r"ConnectionAttemptFailed|disconnected with reason|LE.Disconnected", txt, re.I):
        reason = CONN_FAILED_HINT
    elif re.search(r"Device .* not available|NoSuchDevice", txt, re.I):
        reason = "设备在配对过程中退出了可发现状态，请重新进入配对模式后立即重试。"
    else:
        reason = ("配对未成功。常见原因：配对窗口超时 / 电量不足 / 距离过远 /\n"
                  "设备不支持免密配对（需要输入配对码的设备不适用本脚本）。")
    head = "\n".join(notes) + "\n\n" if notes else ""
    return False, "%s%s\n\n本次过程记录：\n  %s\n\n详细日志：%s" % (
        head, reason, "\n  ".join(cn), PAIR_LOG)


# ---------------------------------------------------------------- 删除配对


def purge_bond_cache(mac):
    """备份并清理该 MAC 残留的 BlueZ 绑定/GATT 缓存（只针对单个设备目录）。"""
    root = BT_CACHE_ROOT
    backup = "/tmp/btpair-removed-" + time.strftime("%Y%m%d-%H%M%S")
    cleaned = []
    try:
        adapters = os.listdir(root)
    except OSError:
        return "", cleaned
    for ad in adapters:
        for path in (os.path.join(root, ad, mac),
                     os.path.join(root, ad, "cache", mac)):
            if not os.path.exists(path):
                continue
            dst = os.path.join(backup, os.path.relpath(path, root))
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                if os.path.isdir(path):
                    shutil.copytree(path, dst, dirs_exist_ok=True)
                    shutil.rmtree(path)
                else:
                    shutil.copy2(path, dst)
                    os.remove(path)
                cleaned.append(os.path.relpath(path, root))
            except Exception:
                pass
    return (backup if cleaned else ""), cleaned


def do_remove(mac, name, progress=None):
    """断开连接 -> 移除配对 -> 确认移除成功后清理绑定缓存 -> 复核结果。"""
    if not MAC_RE.match(mac):
        return False, "MAC 地址格式不正确：%s" % mac

    was_known = bluez_paired(mac) or has_ltk(mac)
    cmds = [
        ("disconnect " + mac, 2),
        ("remove " + mac, 3),
        ("devices", 1),
        ("quit", 0),
    ]
    try:
        txt = bt_session(cmds, REMOVE_LOG, progress)
    except Canceled:
        return False, "已取消，未删除任何配对。\n\n" + status_text()

    still = bluez_paired(mac)
    if still:
        # 断开连接是异步的，remove 可能返回「设备不可用」，重试一次
        txt += "\n[重试] " + run([BT, "disconnect", mac], 20)
        sleep(1)
        txt += "\n[重试] " + run([BT, "remove", mac], 20)
        sleep(1)
        still = bluez_paired(mac)

    # 只有 BlueZ 确认已移除配对，才清理密钥缓存；移除失败时保留原状，
    # 避免造成「设备端有旧 LTK、主机端却没有」的 auth failed 0x05 坏状态。
    backup, cleaned, ltk_left = "", [], has_ltk(mac)
    if not still:
        if progress:
            progress.update(90, "清理绑定缓存…")
        backup, cleaned = purge_bond_cache(mac)
        ltk_left = has_ltk(mac)

    ok = was_known and (not still) and (not ltk_left)
    if not was_known:
        verdict = "该设备原本不在已配对列表中，未执行有效删除。"
    elif ok:
        verdict = "已断开连接、移除配对，绑定密钥已清除。"
    else:
        verdict = "未能完全移除（为安全起见保留原有绑定，未清理密钥）。"
    lines = [
        "设备：%s  [%s]" % (name, mac),
        "结果：%s" % verdict,
        "",
        "已清理缓存：%s" % (", ".join(cleaned) if cleaned else "无"),
        "临时备份  ：%s" % (backup if backup else "无"),
        "蓝牙输入设备数量：%d" % hid_count(),
        "详细日志  ：%s" % REMOVE_LOG,
        "",
        "【重要】主机端删除后，设备（遥控器/键盘）里通常仍保存着旧配对。",
        "日后要重新配对，必须先在设备端清除配对 / 复位（取电池 10 秒以上，",
        "或长按厂商复位组合键），再进入配对模式；否则会出现认证失败（错误码 0x05）。",
    ]
    if not was_known:
        lines += ["", "如需删除其它设备，请重新运行并从列表中选择。"]
    elif not ok:
        lines += [
            "",
            "建议：重启蓝牙服务后重试一次，或在命令行执行：",
            "  bluetoothctl remove %s" % mac,
            "本次过程记录：",
        ]
        lines += ["  " + s for s in log_summary(txt, 6)]
    return ok, "\n".join(lines) + "\n\n" + status_text()


# ---------------------------------------------------------------- 交互流程

def cli_choose(devices, heading="搜索到 %d 个蓝牙设备：",
               label_func=device_label, default_first=True):
    print("\n" + heading % len(devices))
    for i, (mac, name) in enumerate(devices, 1):
        print("  %d) %s" % (i, label_func(mac, name)))
    hint = "请输入序号（直接回车选 1，输入 q 取消）：" if default_first else \
           "请输入要删除的序号（输入 q 或回车取消）："
    try:
        answer = input(hint).strip()
    except (EOFError, OSError):
        answer = ""
    if answer.lower() == "q":
        return None
    if not answer:
        return devices[0][0] if (devices and default_first) else None
    try:
        idx = int(answer)
        if 1 <= idx <= len(devices):
            return devices[idx - 1][0]
    except ValueError:
        pass
    print("无效序号，已取消。")
    return None


def pair_flow(mac_override=None):
    """Kodi：确认窗口 -> 扫描列表 -> 选择 -> 配对；CLI：可传 MAC 跳过选择。"""
    if not KODI and mac_override:
        pr = make_progress("正在配对")
        try:
            ok, msg = do_pair(mac_override, mac_override, force=False, progress=pr)
        finally:
            pr.close()
        show_text("配对结果" if ok else "配对未完成", msg)
        return

    if not yesno("一键配对", START_HINT, yes="开始配对", no="取消"):
        return

    for attempt in range(3):
        pr = make_progress("正在扫描蓝牙设备")
        try:
            pr.update(0, "请让蓝牙设备进入配对模式…")
            devices = scan_devices(pr)
        except Canceled:
            return
        finally:
            pr.close()

        if KODI:
            labels = [device_label(m, n) for m, n in devices]
            labels.append("重新扫描")
            idx = xbmcgui.Dialog().select("选择要配对的蓝牙设备", labels)
            if idx < 0 or idx > len(devices):
                return
            if idx == len(devices):
                continue
            mac, name = devices[idx]
        else:
            if not devices:
                print("未搜索到蓝牙设备。")
                if not yesno("重新扫描", "未搜索到设备，是否重新扫描？", yes="重新扫描", no="取消"):
                    return
                continue
            mac = cli_choose(devices)
            if not mac:
                return
            name = next((n for m, n in devices if m == mac), mac)

        p = props(mac)
        force = False
        if p.get("Paired") == "yes" and has_ltk(mac):
            force = yesno(
                "重新配对",
                "%s 已配对且绑定完好。\n\n强制重新配对会清除现有绑定，且必须先在设备端"
                "清除旧配对 / 复位，否则会出现认证失败（错误码 0x05）。\n是否仍要强制重新配对？"
                % name,
                yes="强制重配", no="取消",
            )
            if not force:
                show_text("蓝牙状态", status_text())
                return

        pr = make_progress("正在配对")
        try:
            ok, msg = do_pair(mac, name, force=force, progress=pr, scan_sec=5)
        except Canceled:
            return
        finally:
            pr.close()
        show_text("配对结果" if ok else "配对未完成", msg)
        return

    show_text("未搜索到设备", "连续 3 次未搜索到蓝牙设备。\n请确认设备已进入配对模式、电量充足、距离足够近后重试。")


def remove_flow(mac_override=None):
    """列出已配对设备 -> 选择 -> 二次确认 -> 断开并删除配对。"""
    devs = paired_devices()
    if not devs:
        show_text("删除蓝牙配对",
                  "当前没有已配对的蓝牙设备，无需删除。\n\n" + status_text())
        return

    # 命令行指定了 MAC 即视为明确目标，直接执行（便于自动化）
    if not KODI and mac_override:
        if mac_override not in [m for m, _ in devs]:
            show_text(
                "删除蓝牙配对",
                "未找到已配对设备 %s，未执行删除。\n\n当前已配对设备：\n%s\n\n%s"
                % (mac_override,
                   "\n".join("  · " + paired_label(m, n) for m, n in devs) or "  （无）",
                   status_text()),
            )
            return
        name = next((n for m, n in devs if m == mac_override), mac_override)
        ok, msg = do_remove(mac_override, name)
        show_text("删除结果" if ok else "删除未完成", msg)
        return

    if KODI:
        labels = [paired_label(m, n) for m, n in devs]
        labels.append("取消 / 返回")
        idx = xbmcgui.Dialog().select("选择要删除配对的蓝牙设备", labels)
        if idx < 0 or idx >= len(devs):
            return
        mac, name = devs[idx]
    else:
        mac = cli_choose(devs, heading="已配对 %d 个蓝牙设备：",
                         label_func=paired_label, default_first=False)
        if not mac:
            print("已取消，未删除任何配对。")
            return
        name = next((n for m, n in devs if m == mac), mac)

    if not yesno("删除蓝牙配对", REMOVE_CONFIRM % (name, mac),
                 yes="确认删除", no="取消", cli_default=False):
        if not KODI:
            print("已取消，未删除任何配对。")
        return

    pr = make_progress("正在删除蓝牙配对")
    try:
        ok, msg = do_remove(mac, name, progress=pr)
    except Canceled:
        return
    finally:
        pr.close()
    show_text("删除结果" if ok else "删除未完成", msg)


# ---------------------------------------------------------------- 入口

ACTIONS = ("status", "pair", "scan", "remove", "unpair",
           "install", "uninstall", "agent")


def parse_args(argv):
    action = None
    mac = None
    for arg in argv:
        if arg in ACTIONS and action is None:
            action = arg
        elif MAC_RE.match(arg):
            mac = arg.upper()
    return action, mac


MENU_LABELS = ("一键配对 / 重新配对", "查看蓝牙状态", "删除蓝牙配对")
MENU_ACTIONS = ("pair", "status", "remove")
MENU_TITLE = "蓝牙设备（按返回键退出）"


def dispatch(action, mac=None):
    """执行一个动作后返回；由调用方决定是否再次显示一级主选单。"""
    if action == "status":
        show_text("蓝牙状态", status_text())
    elif action in ("remove", "unpair"):
        remove_flow(mac)
    elif action == "scan":
        pr = make_progress("正在扫描蓝牙设备")
        try:
            devices = scan_devices(pr)
        except Canceled:
            return
        finally:
            pr.close()
        if devices:
            show_text("扫描结果", "\n".join(device_label(m, n) for m, n in devices))
        else:
            show_text("扫描结果", "未搜索到蓝牙设备，请确认设备已进入配对模式。")
    elif action == "pair":
        pair_flow(mac)


def menu_loop():
    """Kodi 一级主选单常驻：每项执行完或取消后回到这里，按返回键退出。"""
    while True:
        sleep(0.2)  # 关掉结果窗后短暂防抖，避免连按穿透到下一项
        sel = xbmcgui.Dialog().select(MENU_TITLE, list(MENU_LABELS))
        if sel < 0 or sel >= len(MENU_LABELS):
            return
        try:
            dispatch(MENU_ACTIONS[sel], None)
        except Exception as exc:
            # 单个动作出错也不让主选单消失，用户可返回后重试其它项
            show_text("操作未完成", "%s\n\n可返回主选单重试其它操作。" % exc)


def main(argv):
    action, mac = parse_args(argv)

    if action == "agent":
        agent_forever()
        return
    if action == "install":
        show_text("安装补丁", install_agent())
        if KODI:
            menu_loop()
        return
    if action == "uninstall":
        if not KODI or yesno("卸载补丁", "确定卸载常驻蓝牙 Agent 补丁？"):
            show_text("卸载补丁", uninstall_agent())
        if KODI:
            menu_loop()
        return

    # 脚本执行过程中自动安装/校正 Agent 补丁（已正确时静默跳过）
    ensure_agent(force=False)

    if KODI:
        # 带参数调用先执行指定动作一次，随后同样回到一级主选单
        if action is not None:
            try:
                dispatch(action, mac)
            except Exception as exc:
                show_text("操作未完成", "%s\n\n可返回主选单重试其它操作。" % exc)
        menu_loop()
        return

    # 命令行：单次执行后退出（无参数时默认显示状态）
    dispatch("status" if action is None else action, mac)


if __name__ == "__main__":
    main(sys.argv[1:])
