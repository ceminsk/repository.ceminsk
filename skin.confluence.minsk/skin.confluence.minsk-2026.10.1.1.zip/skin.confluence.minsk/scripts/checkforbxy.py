import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import urllib.request
from urllib.error import URLError
from urllib.parse import urljoin
import zipfile
import os
import re
import time
import threading
import sys
import random
import hashlib
import shutil

# --- 配置区域 ---
TARGET_MOVIE_SCRAPER_VERSION = "3.4.1"
TARGET_TV_SCRAPER_VERSION = "1.8.5"
# 仓库索引地址（用于动态解析最新版本号的zip 包）
REPO_INDEX_URL = "https://kodi8.com/repository.forbxy.ghproxy/"
# 兜底下载地址（当索引解析失败时使用）
REPO_DOWNLOAD_URL = "https://kodi8.com/repository.forbxy.ghproxy-1.3.0.zip"
# zip 文件名匹配规则：repository.forbxy.ghproxy-版本号.zip
REPO_ZIP_FILENAME_PATTERN = re.compile(
    r"^repository\.forbxy\.ghproxy-(\d+(?:\.\d+)*)\.zip$", re.IGNORECASE)
# 索引页面的抓取超时时间（秒）
REPO_INDEX_TIMEOUT = 15

USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')


def log_message(message):
    """记录日志信息"""
    xbmc.log(f"[checkforbxy.py] {message}", level=xbmc.LOGINFO)

def show_error_notification(message, time_ms=5000):
    """显示错误通知消息"""
    xbmc.executebuiltin(f'Notification("插件安装错误", "{message}", {time_ms})')

def show_notification(message, time_ms=5000):
    """显示通知消息"""
    xbmc.executebuiltin(f'Notification("插件安装", "{message}", {time_ms})')

def wait_for_yes_no_dialog_and_confirm():
    """等待yesnodialog窗口并确认"""
    max_wait_time = 30
    wait_interval = 1
    elapsed_time = 0
    
    while elapsed_time < max_wait_time:
        if xbmc.getCondVisibility("Window.IsVisible(yesnodialog)"):
            xbmc.executebuiltin('setfocus(11)')
            xbmc.sleep(500)
            xbmc.executebuiltin('Action(select)')
            break
        xbmc.sleep(wait_interval * 1000)
        elapsed_time += wait_interval

def wait_for_addon_enabled(addon_id, timeout=60):
    """等待插件启用"""
    max_wait_time = timeout
    wait_interval = 1
    elapsed_time = 0
    
    while elapsed_time < max_wait_time:
        if xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            return True
        xbmc.sleep(wait_interval * 1000)
        elapsed_time += wait_interval
    return False

def fetch_text(url, timeout=REPO_INDEX_TIMEOUT):
    """抓取网页文本内容"""
    req = urllib.request.Request(
        url,
        data=None,
        headers={'User-Agent': USER_AGENT}
    )
    response = urllib.request.urlopen(req, timeout=timeout)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    for encoding in ('utf-8', 'gbk', 'latin-1'):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode('utf-8', 'ignore')

def parse_repo_zip_versions(html):
    """
    从索引页面 HTML 中解析出所有形如
    repository.forbxy.ghproxy-版本号.zip 的文件名
    返回 {版本号元组: 文件名} 字典
    """
    found = {}
    if not html:
        return found

    # 优先按 <a href="..."> 提取链接（标准 nginx/Apache 目录索引格式）
    hrefs = re.findall(r'<a\s+[^>]*href\s*=\s*["\']([^"\']+)["\']', html, re.IGNORECASE)
    candidates = []
    for href in hrefs:
        # 只取链接中的文件名部分，忽略 ../ 等目录链接与查询参数
        name = href.split('?')[0].split('#')[0].rstrip('/').split('/')[-1]
        if name:
            candidates.append(name)

    # 兜底：直接在整页文本中搜索文件名（部分服务端会改变列表渲染方式）
    if not candidates:
        candidates = re.findall(r'repository\.forbxy\.ghproxy-[0-9.]+\.zip', html, re.IGNORECASE)

    for name in candidates:
        name = name.strip()
        match = REPO_ZIP_FILENAME_PATTERN.match(name)
        if not match:
            continue
        version_str = match.group(1)
        version_tuple = parse_version(version_str)
        if version_tuple == (0, 0, 0):
            continue
        # 同一版本号保留先出现的条目
        if version_tuple not in found:
            found[version_tuple] = name
    return found

def verify_zip_url(url, timeout=REPO_INDEX_TIMEOUT):
    """
    校验候选下载链接确实指向 zip 文件（而非错误页 / HTML 页面）。
    服务器不支持 HEAD 时返回 True（不做拦截），避免误杀。
    """
    try:
        req = urllib.request.Request(url, method='HEAD', headers={'User-Agent': USER_AGENT})
        response = urllib.request.urlopen(req, timeout=timeout)
        try:
            content_type = (response.headers.get('Content-Type') or '').lower()
        finally:
            try:
                response.close()
            except Exception:
                pass
        if content_type and ('text/html' in content_type or 'text/plain' in content_type):
            log_message(f"候选链接返回的不是压缩包 (Content-Type: {content_type})，已跳过: {url}")
            return False
        return True
    except Exception as e:
        # HEAD 请求不被支持或发生异常时，放行由后续下载流程做最终校验
        log_message(f"无法校验候选链接(HEAD 请求异常)，跳过校验: {str(e)}")
        return True

def get_latest_repo_download_url(index_url=REPO_INDEX_URL):
    """
    打开仓库索引地址，解析出版本号最高的 zip 包并返回其完整下载地址。
    解析失败时返回 None（由调用方决定使用兜底地址）。
    """
    try:
        log_message(f"正在打开仓库索引: {index_url}")
        html = fetch_text(index_url, timeout=REPO_INDEX_TIMEOUT)
        versions = parse_repo_zip_versions(html)
        if not versions:
            log_message("索引页面中未找到符合命名规则的 zip 文件")
            return None

        # 版本号由高到低逐个尝试，取第一个校验通过的链接
        for version_tuple in sorted(versions.keys(), reverse=True):
            filename = versions[version_tuple]
            version_str = ".".join(str(x) for x in version_tuple)
            download_url = urljoin(index_url, filename)
            if not verify_zip_url(download_url):
                continue
            log_message(f"找到可用仓库包: {filename} (版本 {version_str})")
            log_message(f"最新版本下载地址: {download_url}")
            return download_url

        log_message("未能确定最新版本下载地址")
        return None
    except Exception as e:
        log_message(f"解析仓库索引失败: {str(e)}")
        return None

def download_file(url, destination):
    """下载文件"""
    try:
        log_message(f"正在下载: {url}")
        req = urllib.request.Request(
            url,
            data=None,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        )
        response = urllib.request.urlopen(req)
        dest_dir = os.path.dirname(destination)
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        with open(destination, 'wb') as f:
            f.write(response.read())
        log_message("下载完成")
        return True
    except URLError as e:
        log_message(f"下载失败 (URLError): {str(e)}")
        show_error_notification(f"下载失败: {str(e)}")
        return False
    except Exception as e:
        log_message(f"下载失败: {str(e)}")
        show_error_notification(f"下载失败: {str(e)}")
        return False

def extract_zip(zip_path, extract_to):
    """解压ZIP文件"""
    try:
        log_message(f"正在解压: {zip_path}")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        log_message("解压完成")
        return True
    except Exception as e:
        log_message(f"解压失败: {str(e)}")
        show_error_notification(f"解压失败: {str(e)}")
        return False

def validate_repository_content(timeout_seconds=60):
    """验证插件库内容是否可用"""
    max_wait_time = timeout_seconds
    wait_interval = 1
    elapsed_time = 0
    
    while elapsed_time < max_wait_time:
        xbmc.sleep(wait_interval * 1000)
        xbmc.executebuiltin('Action(down)')
        xbmc.sleep(1000)
        current_label = xbmc.getInfoLabel('ListItem.Label')
        log_message(f"当前列表项: '{current_label}'")
        if current_label and current_label.strip():
            log_message(f"找到非空列表项: {current_label}")
            return True
        elapsed_time += wait_interval
    
    log_message("未找到非空列表项，验证失败")
    show_error_notification("插件库内容验证失败！")
    return False

def find_addon_in_browser_movies(target_label, timeout_seconds=60):
    """在电影刮削器浏览器中查找特定插件"""
    max_wait_time = timeout_seconds
    wait_interval = 1
    elapsed_time = 0
    
    while elapsed_time < max_wait_time:
        xbmc.sleep(wait_interval * 1000)
        xbmc.executebuiltin('Action(down)')
        xbmc.sleep(1000)
        current_label = xbmc.getInfoLabel('ListItem.Label')
        log_message(f"当前列表项: '{current_label}'")
        if current_label.lower() == target_label.lower():
            log_message(f"找到目标插件: {current_label}")
            return True
        elapsed_time += wait_interval
    
    log_message(f"未找到目标插件 '{target_label}'，超时退出")
    show_error_notification(f"未找到电影刮削器 '{target_label}'！")
    return False

def find_addon_in_browser_tv(target_label, timeout_seconds=60):
    """在剧集刮削器浏览器中查找特定插件"""
    max_wait_time = timeout_seconds
    wait_interval = 1
    elapsed_time = 0
    
    while elapsed_time < max_wait_time:
        xbmc.sleep(wait_interval * 1000)
        xbmc.executebuiltin('Action(down)')
        xbmc.sleep(1000)
        current_label = xbmc.getInfoLabel('ListItem.Label')
        log_message(f"当前列表项: '{current_label}'")
        if current_label.lower() == target_label.lower():
            log_message(f"找到目标插件: {current_label}")
            return True
        elapsed_time += wait_interval
    
    log_message(f"未找到目标插件 '{target_label}'，超时退出")
    show_error_notification(f"未找到剧集刮削器 '{target_label}'！")
    return False

def monitor_addon_status_with_change_detection(expected_status, timeout_seconds=120):
    """监测插件状态变化"""
    max_wait_time = timeout_seconds
    wait_interval = 2
    elapsed_time = 0
    last_status = ""
    last_change_time = time.time()
    
    while elapsed_time < max_wait_time:
        addon_status = xbmc.getInfoLabel('ListItem.Property(Addon.Status)')
        log_message(f"插件状态: {addon_status}")
        if addon_status != last_status:
            last_status = addon_status
            last_change_time = time.time()
            log_message(f"插件状态发生变化: {addon_status}")
        
        if expected_status.lower() in addon_status.lower() or addon_status.lower() == expected_status.lower():
            log_message(f"插件状态达到预期: {addon_status}")
            return True
        
        if time.time() - last_change_time > 60:
            log_message("插件状态长时间未变化，可能存在错误")
            show_error_notification("插件状态监控超时或失败！")
            return False
        
        xbmc.sleep(wait_interval * 1000)
        elapsed_time += wait_interval
    
    log_message("插件状态监控总超时")
    show_error_notification("插件状态监控超时！")
    return False

def copy_addon_files():
    """
    复制插件必需文件到插件目录 (Fallback方案)
    修复点：
    1. 使用 os.path.join 替代不存在的 xbmcvfs.join
    2. 确保路径经过 translatePath 转换
    3. 使用 shutil.copy2 提高兼容性
    """
    try:
        # 获取绝对路径
        home_addons = xbmcvfs.translatePath("special://home/addons/")
        addon_dir = os.path.join(home_addons, "repository.forbxy.ghproxy")
        
        # 确保目标目录存在
        if not os.path.exists(addon_dir):
            os.makedirs(addon_dir)
            log_message(f"创建目录: {addon_dir}")
        
        # 定义源文件 (假设在当前皮肤的 resources 目录下，这是常见的内置仓库做法)
        # 注意：如果皮肤不包含这些文件，此方法将失败。
        skin_resources = xbmcvfs.translatePath("special://skin/resources/")
        
        files_to_copy = [
            ("addon.xml", "addon.xml"),
            ("icon.jpg", "icon.jpg"),
            ("fanart.jpg", "fanart.jpg") # 可选
        ]
        
        copied_count = 0
        for src_name, dst_name in files_to_copy:
            src_path = os.path.join(skin_resources, src_name)
            dst_path = os.path.join(addon_dir, dst_name)
            
            if os.path.exists(src_path):
                try:
                    shutil.copy2(src_path, dst_path)
                    log_message(f"成功复制: {src_name} -> {dst_path}")
                    copied_count += 1
                except Exception as e:
                    log_message(f"复制文件 {src_name} 失败: {str(e)}")
            else:
                log_message(f"源文件不存在，跳过: {src_path}")

        if copied_count == 0:
            log_message("警告: 没有复制任何文件，请确认 special://skin/resources/ 下是否有 addon.xml 和 icon.jpg")
            return False
            
        return True
    except Exception as e:
        log_message(f"Error copying addon files: {str(e)}")
        import traceback
        log_message(traceback.format_exc())
        return False

def parse_version(version_str):
    """将版本字符串转换为元组以便比较，例如 '1.2.3' -> (1, 2, 3)"""
    try:
        return tuple(map(int, version_str.split('.')))
    except:
        return (0, 0, 0)

def force_reinstall_if_version_mismatch():
    """
    优化后的版本检查逻辑：
    1. 检查 TV 刮削器版本 >= 1.8.5
    2. 检查 Movie 刮削器版本 >= 3.4.1
    3. 如果任一不满足，删除对应的插件文件夹以及 repository.forbxy.ghproxy 文件夹
    4. 执行 UpdateLocalAddons
    """
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    need_clean_repo = False

    # 定义目标插件及其最低版本要求
    checks = [
        {
            "id": "metadata.tvshows.tmdb.cn.optimization",
            "min_ver": TARGET_TV_SCRAPER_VERSION,
            "name": "剧集刮削器"
        },
        {
            "id": "metadata.tmdb.cn.optimization",
            "min_ver": TARGET_MOVIE_SCRAPER_VERSION,
            "name": "电影刮削器"
        }
    ]

    for check in checks:
        addon_id = check["id"]
        min_ver_str = check["min_ver"]
        name = check["name"]
        
        try:
            current_ver_str = xbmc.getInfoLabel(f"System.AddonVersion({addon_id})")
            current_ver_tuple = parse_version(current_ver_str)
            min_ver_tuple = parse_version(min_ver_str)
            
            log_message(f"检查 {name}: 当前版本 {current_ver_str}, 最低要求 {min_ver_str}")
            
            if current_ver_tuple < min_ver_tuple:
                log_message(f"{name} 版本过低 ({current_ver_str} < {min_ver_str})，标记需要清理")
                need_clean_repo = True
                
                # 删除对应的插件文件夹
                folder_path = os.path.join(addons_path, addon_id)
                if os.path.exists(folder_path):
                    try:
                        shutil.rmtree(folder_path)
                        log_message(f"已删除文件夹: {folder_path}")
                    except Exception as e:
                        log_message(f"删除文件夹失败 {folder_path}: {e}")
            else:
                log_message(f"{name} 版本符合要求")
                
        except Exception as e:
            log_message(f"检查 {name} 版本出错: {e}")
            # 出错时保守处理，假设需要重装
            need_clean_repo = True

    # 如果有任何一个插件版本不符，则删除仓库插件以确保后续能重新从仓库安装最新/指定版本
    if need_clean_repo:
        repo_id = "repository.forbxy.ghproxy"
        repo_folder = os.path.join(addons_path, repo_id)
        
        log_message("检测到版本不匹配或检查异常，准备清理仓库插件...")
        
        if os.path.exists(repo_folder):
            try:
                shutil.rmtree(repo_folder)
                log_message(f"已删除仓库文件夹: {repo_folder}")
            except Exception as e:
                log_message(f"删除仓库文件夹失败: {e}")
        
        log_message("执行 UpdateLocalAddons 以刷新插件列表...")
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(3000) # 增加等待时间确保刷新完成
        log_message("本地插件列表已更新，清理完成")
    else:
        log_message("所有插件版本均符合要求，无需清理")

def stage1_logic(use_library_mode=False):
    """第一阶段逻辑：检查并配置repository.forbxy.ghproxy插件"""
    addon_id = "repository.forbxy.ghproxy"
    log_message("开始执行第1阶段逻辑")
    
    if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
        log_message(f"插件 {addon_id} 已存在")
        if xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            log_message(f"插件 {addon_id} 已启用，继续执行第2阶段逻辑")
            return stage2_logic(use_library_mode)
        else:
            log_message(f"插件 {addon_id} 未启用，执行启用操作")
            xbmc.executebuiltin(f'EnableAddon({addon_id})')
            wait_for_yes_no_dialog_and_confirm()
            if not wait_for_addon_enabled(addon_id, 60):
                show_error_notification(f"{addon_id} 启用超时！")
                return False
            xbmc.sleep(1000)
            xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.forbxy.ghproxy,return)')
            xbmc.sleep(1000)
            if not validate_repository_content(60):
                log_message("插件库内容验证失败，超时退出")
                xbmc.executebuiltin('Action(back)')
                return False
            xbmc.sleep(1000)
            xbmc.executebuiltin('Action(back)')
            xbmc.sleep(1000)
            log_message(f"插件 {addon_id} 启用完成，继续执行第2阶段逻辑")
            return stage2_logic(use_library_mode)
    else:
        log_message(f"插件 {addon_id} 不存在，执行安装逻辑")
        dialog_text = ("该功能需要安装或更新晓大佬的插件库和刮削插件\n点击\"是\"执行自动下载安装，请在内心感谢晓大佬的付出!\n点击\"否\"取消该功能，关闭窗口!")
        dialog_result = xbmcgui.Dialog().yesno("插件安装确认", dialog_text)
        if not dialog_result:
            log_message("用户选择取消，退出脚本")
            return False
        
        show_notification("正在安装晓大佬的插件库，请等待......")
        addons_folder = xbmcvfs.translatePath("special://home/addons/")
        temp_file = xbmcvfs.translatePath("special://temp/downloaded_repo.zip")
        
        # 动态解析仓库索引，取版本号最高的 zip 包；若解析失败则回退到固定的默认地址
        download_url = get_latest_repo_download_url(REPO_INDEX_URL)
        if not download_url:
            log_message("解析最新版本失败，回退使用默认下载地址")
            download_url = REPO_DOWNLOAD_URL
        
        def download_with_timeout():
            nonlocal success
            success = download_file(download_url, temp_file)
        
        success = False
        thread = threading.Thread(target=download_with_timeout)
        thread.daemon = True
        thread.start()
        thread.join(timeout=20)
        
        if thread.is_alive():
            log_message("下载超时，执行文件复制方案")
            if not copy_addon_files():
                show_error_notification("复制插件文件失败！")
                return False
        else:
            if not success:
                log_message("下载失败，执行文件复制方案")
                if not copy_addon_files():
                    show_error_notification("复制插件文件失败！")
                    return False
            else:
                if not os.path.exists(temp_file):
                    log_message("下载的文件不存在，执行文件复制方案")
                    if not copy_addon_files():
                        show_error_notification("复制插件文件失败！")
                        return False
                else:
                    try:
                        size = os.path.getsize(temp_file)
                        log_message(f"下载文件大小: {size} 字节")
                        if size == 0:
                            log_message("下载的文件为空，执行文件复制方案")
                            if not copy_addon_files():
                                show_error_notification("复制插件文件失败！")
                                return False
                        else:
                            if not extract_zip(temp_file, addons_folder):
                                log_message("解压失败，执行文件复制方案")
                                if not copy_addon_files():
                                    show_error_notification("复制插件文件失败！")
                                    return False
                    except Exception as e:
                        log_message(f"无法获取下载文件大小信息或处理异常: {e}，执行文件复制方案")
                        if not copy_addon_files():
                            show_error_notification("复制插件文件失败！")
                            return False
                if os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except:
                        pass
        
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin(f'EnableAddon({addon_id})')
        wait_for_yes_no_dialog_and_confirm()
        if not wait_for_addon_enabled(addon_id, 60):
            show_error_notification(f"{addon_id} 启用超时！")
            return False
        xbmc.sleep(1000)
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.forbxy.ghproxy,return)')
        xbmc.sleep(1000)
        if not validate_repository_content(60):
            log_message("插件库内容验证失败，超时退出")
            xbmc.executebuiltin('Action(back)')
            return False
        xbmc.sleep(1000)
        xbmc.executebuiltin('Action(back)')
        xbmc.sleep(1000)
        log_message(f"插件 {addon_id} 安装完成，继续执行第2阶段逻辑")
        return stage2_logic(use_library_mode)

def stage2_logic(use_library_mode=False):
    """第二阶段逻辑：检查并配置metadata.tmdb.cn.optimization插件"""
    addon_id = "metadata.tmdb.cn.optimization"
    log_message("开始执行第2阶段逻辑")
    
    if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
        log_message(f"插件 {addon_id} 已存在")
        if xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            log_message(f"插件 {addon_id} 已启用，继续执行第3阶段逻辑")
            return stage3_logic(use_library_mode)
        else:
            log_message(f"插件 {addon_id} 未启用，执行启用操作")
            xbmc.executebuiltin(f'EnableAddon({addon_id})')
            wait_for_yes_no_dialog_and_confirm()
            if not wait_for_addon_enabled(addon_id, 60):
                show_error_notification(f"{addon_id} 启用超时！")
                return False
            xbmc.sleep(1000)
            log_message(f"插件 {addon_id} 启用完成，继续执行第3阶段逻辑")
            return stage3_logic(use_library_mode)
    else:
        log_message(f"插件 {addon_id} 不存在，执行安装逻辑")
        show_notification("正在安装晓大佬的电影刮削器，请等待......")
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.forbxy.ghproxy/xbmc.metadata.scraper.movies,return)')
        xbmc.sleep(1000)
        if not find_addon_in_browser_movies("TMDB CN Optimization", 60):
            show_error_notification("未找到电影刮削器，安装失败！")
            log_message("未找到目标插件，超时退出")
            return False
        xbmc.sleep(1000)
        xbmc.executebuiltin('Action(select)')
        xbmc.sleep(500)
        xbmc.executebuiltin('setfocus(6)')
        xbmc.sleep(500)
        xbmc.executebuiltin('Action(select)')
        xbmc.sleep(2000)
        if monitor_addon_status_with_change_detection("启用", 120):
            xbmc.sleep(1000)
            xbmc.executebuiltin('Action(back)')
            xbmc.sleep(1000)
            return stage3_logic(use_library_mode)
        else:
            show_error_notification("电影刮削器状态监控超时或失败！")
            log_message("插件状态监控超时或失败")
            return False

def stage3_logic(use_library_mode=False):
    """第三阶段逻辑：检查并配置metadata.tvshows.tmdb.cn.optimization插件"""
    addon_id = "metadata.tvshows.tmdb.cn.optimization"
    log_message("开始执行第3阶段逻辑")
    run_param = "library" if use_library_mode else "manage"
    log_message(f"最终执行模式: {run_param}")
    
    if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
        log_message(f"插件 {addon_id} 已存在")
        if xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            log_message(f"插件 {addon_id} 已启用，运行管理脚本")
            xbmc.executebuiltin(f"RunScript(special://skin/scripts/autotmdb.py,{run_param})")
            return True
        else:
            log_message(f"插件 {addon_id} 未启用，执行启用操作")
            xbmc.executebuiltin(f'EnableAddon({addon_id})')
            wait_for_yes_no_dialog_and_confirm()
            if not wait_for_addon_enabled(addon_id, 60):
                show_error_notification(f"{addon_id} 启用超时！")
                return False
            xbmc.sleep(1000)
            log_message(f"插件 {addon_id} 启用完成，运行管理脚本")
            xbmc.executebuiltin(f"RunScript(special://skin/scripts/autotmdb.py,{run_param})")
            return True
    else:
        log_message(f"插件 {addon_id} 不存在，执行安装逻辑")
        show_notification("正在安装晓大佬的剧集刮削器，请等待......")
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.forbxy.ghproxy/xbmc.metadata.scraper.tvshows,return)')
        xbmc.sleep(1000)
        if not find_addon_in_browser_tv("TMDb TV CN Optimization", 60):
            show_error_notification("未找到剧集刮削器，安装失败！")
            log_message("未找到目标插件，超时退出")
            return False
        xbmc.sleep(1000)
        xbmc.executebuiltin('Action(select)')
        xbmc.sleep(500)
        xbmc.executebuiltin('setfocus(6)')
        xbmc.sleep(500)
        xbmc.executebuiltin('Action(select)')
        xbmc.sleep(2000)
        if monitor_addon_status_with_change_detection("启用", 120):
            xbmc.sleep(1000)
            xbmc.executebuiltin('Action(back)')
            xbmc.sleep(1000)
            xbmc.executebuiltin(f"RunScript(special://skin/scripts/autotmdb.py,{run_param})")
            return True
        else:
            show_error_notification("剧集刮削器状态监控超时或失败！")
            log_message("插件状态监控超时或失败")
            return False

def main():
    """主函数"""
    log_message("开始执行checkforbxy.py脚本")
    
    # 2. 执行优化后的版本校验与强制清理
    force_reinstall_if_version_mismatch()
    
    try:
        use_library_mode = False
        if len(sys.argv) > 1:
            args_str = " ".join(sys.argv[1:])
            if "library" in args_str:
                use_library_mode = True
                log_message("检测到 library 参数，将使用 library 模式运行最终脚本")
        
        # 执行第1阶段逻辑 (后续阶段会在内部链式调用)
        if stage1_logic(use_library_mode):
            log_message("脚本执行完成")
        else:
            log_message("脚本执行失败或用户取消")
    except Exception as e:
        log_message(f"脚本执行出错: {str(e)}")
        show_error_notification(f"脚本执行出错: {str(e)}")

if __name__ == "__main__":
    main()