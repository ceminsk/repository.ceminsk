import sys
import re
import subprocess
import xbmc
import xbmcgui

def get_hciconfig_output():
    """执行 hciconfig -a 并返回输出结果"""
    try:
        # 在Kodi本地脚本中，直接执行系统shell命令即可（替代所谓的“模拟ssh执行”）
        result = subprocess.run(['hciconfig', '-a'], capture_output=True, text=True, check=True)
        return result.stdout
    except Exception as e:
        xbmc.log(f"[selectbt.py] Error executing hciconfig: {str(e)}", xbmc.LOGERROR)
        return ""

def parse_adapters(output):
    """解析 hciconfig 输出，提取适配器信息"""
    adapter_blocks = re.split(r'(?=^hci\d+:)', output, flags=re.MULTILINE)
    adapter_blocks = [block.strip() for block in adapter_blocks if block.strip()]

    parsed_adapters = []
    for block in adapter_blocks:
        hci_match = re.match(r'(hci\d+):', block)
        if not hci_match:
            continue
        
        hci_id = hci_match.group(1)
        
        # 提取 Bus 字段
        bus_match = re.search(r'Bus:\s*(\S+)', block)
        bus = bus_match.group(1) if bus_match else "Unknown"
        
        # 判断是否包含 Name: 来确定是否可用
        has_name = 'Name: ' in block
        
        parsed_adapters.append({
            'hci_id': hci_id,
            'bus': bus,
            'has_name': has_name
        })
        
    return parsed_adapters

def handle_setup():
    """处理 setup 参数：交互式选择并设置/禁用蓝牙"""
    dialog = xbmcgui.Dialog()
    
    while True:
        hciconfig_output = get_hciconfig_output()
        if not hciconfig_output:
            dialog.ok("错误", "无法获取蓝牙适配器信息。")
            return

        parsed_adapters = parse_adapters(hciconfig_output)
        if not parsed_adapters:
            dialog.ok("提示", "未检测到任何蓝牙适配器。")
            return

        # 构建一级菜单选项
        options = []
        adapter_display_names = []
        for adapter in parsed_adapters:
            display_bus = "内置" if adapter['bus'].upper() == "UART" else adapter['bus']
            display_name = f"{adapter['hci_id']}-{display_bus}蓝牙适配器"
            adapter_display_names.append(display_name)
            
            # Kodi 标准颜色标签为 [COLOR xxx]，而非 [绿色]
            status = "[COLOR green]可用[/COLOR]" if adapter['has_name'] else "[COLOR red]已禁用[/COLOR]"
            options.append(f"{status}{display_name}")

        # 弹出一级选择窗口
        selected_index = dialog.select("选择蓝牙适配器 (按返回键退出)", options)
        if selected_index == -1:
            break

        selected_adapter = parsed_adapters[selected_index]
        display_name = adapter_display_names[selected_index]
        hci_id = selected_adapter['hci_id']
        bus = selected_adapter['bus']
        var_name = f"disable{bus}"

        if selected_adapter['has_name']:
            # 情况1：当前可用 -> 提供禁用选项
            sub_options = [
                "长期禁用(重启后仍然禁用)", 
                "临时禁用(重启后恢复可用)", 
                "返回上级菜单"
            ]
            sub_selected_index = dialog.select(f"操作: {display_name}", sub_options)
            
            if sub_selected_index == 0:
                subprocess.run(['hciconfig', hci_id, 'down'])
                xbmc.executebuiltin(f'Skin.SetString({var_name},1)')
                dialog.ok("提示", f"已将“{display_name}”长期禁用！")
            elif sub_selected_index == 1:
                subprocess.run(['hciconfig', hci_id, 'down'])
                xbmc.executebuiltin(f'Skin.SetString({var_name},)')
                dialog.ok("提示", f"已将“{display_name}”临时禁用！")
            # 如果是 2(返回) 或 -1(按返回键)，则不执行操作
                
        else:
            # 情况2：当前已禁用 -> 提供启用选项
            sub_options = [
                "恢复长期可用(重启后仍然可用)", 
                "临时可用(重启后恢复禁用)", 
                "返回上级菜单"
            ]
            sub_selected_index = dialog.select(f"操作: {display_name}", sub_options)
            
            if sub_selected_index == 0:
                subprocess.run(['hciconfig', hci_id, 'up'])
                xbmc.executebuiltin(f'Skin.SetString({var_name},)')
                dialog.ok("提示", f"已将“{display_name}”恢复长期可用！")
            elif sub_selected_index == 1:
                subprocess.run(['hciconfig', hci_id, 'up'])
                dialog.ok("提示", f"已将“{display_name}”恢复临时可用！")
            # 如果是 2(返回) 或 -1(按返回键)，则不执行操作

        # 无论执行了什么操作，或是选择返回，都延时700毫秒后重新刷新一级菜单
        xbmc.sleep(700)

def handle_start():
    """处理 start 参数：根据 Skin 变量自动启停对应蓝牙"""
    hciconfig_output = get_hciconfig_output()
    if not hciconfig_output:
        return

    parsed_adapters = parse_adapters(hciconfig_output)
    if not parsed_adapters:
        return

    for adapter in parsed_adapters:
        bus = adapter['bus']
        hci_id = adapter['hci_id']
        var_name = f"disable{bus}"
        
        # 获取 Skin 中设置的长期禁用标记
        val = xbmc.getInfoLabel(f'Skin.String({var_name})').strip()
        
        if val == '1':
            # 如果该总线被标记为长期禁用，则执行 down
            subprocess.run(['hciconfig', hci_id, 'down'])
            xbmc.log(f"[selectbt.py] Blocked {hci_id} ({bus}) due to Skin setting", xbmc.LOGINFO)
        else:
            # 否则执行 up
            subprocess.run(['hciconfig', hci_id, 'up'])
            xbmc.log(f"[selectbt.py] Unblocked {hci_id} ({bus})", xbmc.LOGINFO)

def main():
    if len(sys.argv) < 2:
        return

    action = sys.argv[1]
    
    if action == 'setup':
        handle_setup()
    elif action == 'start':
        handle_start()

if __name__ == '__main__':
    main()