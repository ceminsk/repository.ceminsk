#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CoreELEC/Kodi 专用R4更新脚本（增强版 - 优化内核版本提取与交互提示）
功能：
1. 更新数据库中的视频版本类型 (update模式)
2. [新增] 在update模式下，同步检查并安装匹配内核版本的中文语言包
3. 手动触发语言包匹配与更新 (manaul模式)
4. [优化] 内核版本提取时自动去除小版本号（如 X10.3 -> X10）
5. [优化] 手动模式下若未找到语言包，弹出明确提示
"""
import xbmc
import xbmcvfs
import xbmcgui
import sys
import os
import sqlite3
import zipfile
import shutil
import re

# 版本类型映射字典
VERSION_TYPE_MAPPING = {
    'standard edition': '标准版', 'extended edition': '加长版',
    'unrated version': '未分级版', 'uncut version': '未删减版',
    'remastered version': '重制版', 'theatrical cut': '剧场版',
    'director\'s cut': '导演剪辑版', 'special edition': '特别版',
    'limited edition': '限量版', 'complete edition': '完整版',
    'the final cut': '最终剪辑版', 'super duper cut': '超级剪辑版',
    'collector\'s edition': '收藏家版', 'ultimate collector\'s edition': '终极收藏家版',
    'criterion collection edition': '标准收藏版', 'fan edit': '粉丝剪辑版',
    'black and white edition': '黑白版', '10th anniversary edition': '10周年纪念版',
    '20th anniversary edition': '20周年纪念版', '25th anniversary edition': '25周年纪念版',
    '30th anniversary edition': '30周年纪念版', '40th anniversary edition': '40周年纪念版',
    '50th anniversary edition': '50周年纪念版'
}

def log(message, level=xbmc.LOGINFO):
    """日志函数"""
    prefix = "[R4.py] "
    timestamp = xbmc.getInfoLabel('System.Time(HH:MM:SS)')
    xbmc.log(f"{prefix}[{timestamp}] {message}", level)

def update_video_version_types(db_path):
    """更新数据库中的视频版本类型"""
    if not xbmcvfs.exists(db_path): 
        log(f"数据库文件不存在: {db_path}", xbmc.LOGERROR)
        return False
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM videoversiontype")
    updated = False
    for rid, name in cursor.fetchall():
        if name:
            lower_name = name.lower().strip()
            if lower_name in VERSION_TYPE_MAPPING:
                new_name = VERSION_TYPE_MAPPING[lower_name]
                if name != new_name:
                    cursor.execute("UPDATE videoversiontype SET name=? WHERE id=?", (new_name, rid))
                    updated = True
    if updated: 
        conn.commit()
    conn.close()
    return updated

def extract_kernel_version(build_date_str):
    """
    从BuildDate字符串中提取内核大版本
    格式示例: "avdvplus-X10.3-20260904" -> 提取 "X10.3" -> 处理为 "X10"
    返回: 处理后的内核大版本字符串, 如果提取失败返回 None
    """
    if not build_date_str:
        return None
    
    # 1. 初步提取：假设格式固定为 prefix-kernel-date，取中间部分
    parts = build_date_str.split('-')
    raw_kernel_ver = None
    if len(parts) >= 2:
        raw_kernel_ver = parts[1]
    else:
        return None 

    if not raw_kernel_ver:
        return None

    # 2. 优化逻辑：去除小数点及后面的数字，只保留大版本
    match = re.match(r'^([^.]+)', raw_kernel_ver)
    if match:
        major_ver = match.group(1)
        log(f"内核版本提取: '{raw_kernel_ver}' -> '{major_ver}'")
        return major_ver
    
    return raw_kernel_ver

def sync_language_package_by_kernel(kernel_version, is_manual=False):
    """
    核心逻辑：根据内核版本同步语言包
    参数:
        kernel_version: 目标内核版本
        is_manual: 是否为手动模式触发（用于决定是否弹窗提示未找到）
    返回:
        True: 成功匹配或已安装
        False: 未找到匹配的语言包
    """
    log(f"开始同步语言包，目标内核版本: '{kernel_version}'")
    
    po_path = xbmcvfs.translatePath("special://home/addons/resource.language.zh_cn/resources/strings.po")
    po_exists = xbmcvfs.exists(po_path)
    is_matched = False
    
    # 1. 检查现有 strings.po
    if po_exists:
        try:
            with open(po_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
            log(f"strings.po第一行: {first_line}")
            if kernel_version in first_line:
                is_matched = True
        except Exception as e:
            log(f"读取strings.po失败: {e}", xbmc.LOGERROR)
            is_matched = False
    else:
        log("strings.po 文件不存在，视为不匹配")

    # 2. 分支处理
    if is_matched:
        log("strings.po 已包含当前内核版本，无需更新文件。")
        xbmc.executebuiltin(f'Skin.SetString(langversion,{kernel_version})')
        return True

    # 如果不匹配，开始查找 Zip 包
    log("strings.po 不匹配，开始查找语言包 Zip...")
    
    lang_dir = xbmcvfs.translatePath("special://skin/language/")
    target_zip = None
    latest_time = 0
    
    if xbmcvfs.exists(lang_dir):
        try:
            files = os.listdir(lang_dir)
            for f in files:
                if f.startswith("strings-") and f.endswith(".zip"):
                    pkg_ver_identifier = f[8:-4] 
                    
                    if kernel_version in pkg_ver_identifier:
                        f_path = os.path.join(lang_dir, f)
                        try:
                            mtime = os.path.getmtime(f_path)
                            if mtime > latest_time:
                                latest_time = mtime
                                target_zip = f_path
                        except Exception as e:
                            log(f"获取文件时间失败 {f}: {e}")
        except Exception as e:
            log(f"遍历语言包目录失败: {e}", xbmc.LOGERROR)

    # 3. 处理未找到文件的情况
    if not target_zip:
        log("未找到匹配的语言包zip文件")
        xbmc.executebuiltin(f'Skin.SetString(langversion,{kernel_version})')
        
        # [优化] 如果是手动模式，弹出提示
        if is_manual:
            msg = f"未找到匹配内核版本 [{kernel_version}] 的语言包。"
            xbmcgui.Dialog().ok("提示", msg)
        
        return False

    # 4. 处理找到文件的情况：解压覆盖
    log(f"找到匹配的最新语言包: {target_zip}")
    
    try:
        po_dir = os.path.dirname(po_path)
        if not xbmcvfs.exists(po_dir):
            xbmcvfs.mkdirs(po_dir)

        with zipfile.ZipFile(target_zip, 'r') as z:
            found_po = False
            for name in z.namelist():
                if name.endswith('strings.po'):
                    with z.open(name) as src, open(po_path, 'wb') as dst:
                        shutil.copyfileobj(src, dst)
                    found_po = True
                    log(f"从zip中提取并覆盖: {name}")
                    break
            
            if not found_po:
                raise Exception("Zip文件中未找到strings.po")

        log("解压覆盖strings.po成功")
        xbmc.executebuiltin(f'Skin.SetString(langversion,{kernel_version})')
        
        # 弹出重启确认窗
        msg = "已按照内核版本进行了汉化，重启生效，是否现在重启？\n选择“是”立即重启，选择“否”关闭窗口。"
        if xbmcgui.Dialog().yesno("中文汉化提示", msg):
            reboot_script = xbmcvfs.translatePath("special://skin/scripts/rebootoff.py")
            xbmc.executebuiltin(f'RunScript({reboot_script},noask)')
            log("用户选择立即重启")
        else:
            log("用户选择暂不重启")
            
        return True
            
    except Exception as e:
        log(f"解压或设置过程发生异常: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("错误", f"汉化过程中发生错误: {str(e)}")
        return False

def manual_mode():
    """
    手动模式逻辑：
    1. 获取BuildDate并提取内核版本
    2. 检查strings.po第一行是否匹配
    3. 根据匹配结果和用户选择执行相应操作
    """
    log("进入手动模式 (manaul)")
    
    build_date = xbmc.getInfoLabel('Skin.String(BuildDate)')
    log(f"获取到的BuildDate: {build_date}")
    
    kernel_version = extract_kernel_version(build_date)
    if not kernel_version:
        log("无法提取内核版本", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("错误", "无法从BuildDate中提取内核版本")
        return

    log(f"提取的内核版本: {kernel_version}")

    po_path = xbmcvfs.translatePath("special://home/addons/resource.language.zh_cn/resources/strings.po")
    first_line = ""
    po_exists = xbmcvfs.exists(po_path)
    is_matched = False
    
    if po_exists:
        try:
            with open(po_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
            log(f"strings.po第一行内容: {first_line}")
            if kernel_version in first_line:
                is_matched = True
        except Exception as e:
            log(f"读取strings.po失败: {e}", xbmc.LOGERROR)
            po_exists = False 

    # 3. 分支处理
    if is_matched:
        log("strings.po已包含当前内核版本")
        msg = "当前中文包与内核匹配，是否强制安装中文包？\n选择“是”则强制安装中文包，选择“否”退出。"
        if xbmcgui.Dialog().yesno("中文汉化提示", msg):
            log("用户选择强制安装，开始查找语言包...")
            # 传递 is_manual=True 以便在未找到时提示
            sync_language_package_by_kernel(kernel_version, is_manual=True)
        else:
            log("用户选择不强制安装，退出脚本")
            xbmc.executebuiltin(f'Skin.SetString(langversion,{kernel_version})')
            return
    else:
        log("strings.po不包含当前内核版本，开始查找语言包...")
        # 传递 is_manual=True 以便在未找到时提示
        sync_language_package_by_kernel(kernel_version, is_manual=True)

def _resolve_userdata_db_dir():
    """获取 special://userdata/Database/ 的本地绝对路径"""
    try:
        return xbmcvfs.translatePath('special://userdata/Database/')
    except Exception:
        try:
            return xbmc.translatePath('special://userdata/Database/')
        except Exception:
            return ''

def is_no_core():
    """检测当前系统是否为 No / LibreELEC 核心"""
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def get_video_db_path():
    """获取视频数据库路径"""
    db_dir = _resolve_userdata_db_dir()
    prefix = 'MyVideos14' if is_no_core() else 'MyVideos13'
    latest = None
    try:
        if db_dir and os.path.isdir(db_dir):
            latest_path = None
            latest_mtime = -1
            for name in os.listdir(db_dir):
                if name.startswith(prefix) and name.endswith('.db'):
                    full_path = os.path.join(db_dir, name)
                    if not os.path.isfile(full_path):
                        continue
                    try:
                        mtime = os.path.getmtime(full_path)
                    except Exception:
                        continue
                    if mtime > latest_mtime:
                        latest_mtime = mtime
                        latest_path = full_path
            if latest_path:
                log(f"使用最新视频数据库：{latest_path}")
                return latest_path
    except Exception as e:
        log(f"查找视频数据库失败：{e}", xbmc.LOGWARNING)

    return xbmcvfs.translatePath("special://userdata/Database/MyVideos131.db")


def main():
    """主函数：脚本入口"""
    log("脚本启动")
    
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    
    has_manual = any("manaul" in arg for arg in args)
    has_update = any("update" in arg for arg in args)

    try:
        if has_manual:
            manual_mode()
        elif has_update:
            log("检测到update参数，开始更新流程")
            
            # 1. 执行数据库版本类型更新
            db_path = get_video_db_path()
            log("开始执行数据库版本类型更新...")
            update_video_version_types(db_path)
            log("数据库更新完成")
            
            # 2. 执行语言包同步逻辑 (自动模式，is_manual=False，静默处理未找到情况)
            log("开始执行语言包同步检查...")
            build_date = xbmc.getInfoLabel('Skin.String(BuildDate)')
            kernel_version = extract_kernel_version(build_date)
            
            if kernel_version:
                sync_language_package_by_kernel(kernel_version, is_manual=False)
            else:
                log("无法获取BuildDate或内核版本，跳过语言包同步", xbmc.LOGWARNING)
                
        else:
            log("未传入有效参数 (manaul 或 update)，脚本退出", xbmc.LOGWARNING)
            
    except Exception as e:
        log(f"脚本执行异常: {str(e)}", xbmc.LOGERROR)
        
    log("脚本结束")

if __name__ == "__main__":
    main()