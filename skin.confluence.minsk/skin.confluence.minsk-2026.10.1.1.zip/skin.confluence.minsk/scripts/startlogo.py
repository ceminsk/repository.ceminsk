#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
CoreELEC开机图片替换脚本
用于替换OEM启动画面图片
修复了路径转换API问题并增加了详细错误报告
"""

import xbmc
import xbmcgui
import xbmcvfs
import subprocess
import os
from PIL import Image

def get_xbmc_path(path):
    """
    统一获取Kodi路径的方法，兼容不同版本的API
    """
    try:
        # 尝试使用新的xbmcvfs API
        return xbmcvfs.translatePath(path)
    except AttributeError:
        try:
            # 如果新API不可用，回退到旧的xbmc API
            return xbmc.translatePath(path)
        except AttributeError:
            # 如果都不支持，则返回原始路径（虽然这可能导致错误）
            xbmc.log(f"无法转换路径: {path}，API不可用", xbmc.LOGERROR)
            return path

def run_script():
    # 弹出确认窗
    dialog = xbmcgui.Dialog()
    confirm_result = dialog.yesno(
        "开机图片替换工具",
        "点击\"是\"选择开机图片，要求为.png格式，分辨率为1920×1080"
    )
    
    if not confirm_result:
        # 用户点击了否，退出脚本
        xbmc.log("用户取消操作", xbmc.LOGINFO)
        return
    
    # 弹出图片文件选择窗口
    image_path = dialog.browseSingle(
        type=1,
        heading="选择新的开机图片 (PNG格式)",
        shares="files",
        mask=".png"
    )
    
    if not image_path:
        # 用户取消选择
        xbmc.log("用户取消文件选择", xbmc.LOGINFO)
        return
    
    xbmc.log(f"用户选择了图片: {image_path}", xbmc.LOGINFO)
    
    # 验证所选文件是否存在
    if not xbmcvfs.exists(image_path):
        error_msg = f"所选文件不存在！路径: {image_path}"
        xbmc.log(error_msg, xbmc.LOGERROR)
        dialog.ok("错误", error_msg)
        return
    
    # 验证文件扩展名
    if not image_path.lower().endswith('.png'):
        error_msg = f"请选择PNG格式的图片文件！当前文件: {image_path}"
        xbmc.log(error_msg, xbmc.LOGERROR)
        dialog.ok("错误", error_msg)
        return
    
    # 验证图片分辨率
    try:
        # 使用xbmcvfs读取文件到临时路径以供PIL处理
        temp_path = get_xbmc_path('special://temp/temp_image.png')
        xbmc.log(f"使用临时路径: {temp_path}", xbmc.LOGINFO)
        
        # 复制文件到临时位置以便PIL读取
        if not xbmcvfs.copy(image_path, temp_path):
            raise Exception(f"无法复制文件到临时位置: {temp_path}")
        
        # 使用PIL验证图片分辨率
        with Image.open(temp_path) as img:
            width, height = img.size
            xbmc.log(f"图片分辨率: {width}x{height}", xbmc.LOGINFO)
            
            if width != 1920 or height != 1080:
                error_msg = f"图片分辨率不符合要求！\n当前分辨率：{width}x{height}\n要求分辨率：1920x1080"
                xbmc.log(error_msg, xbmc.LOGERROR)
                
                # 清理临时文件
                if xbmcvfs.exists(temp_path):
                    xbmcvfs.delete(temp_path)
                
                dialog.ok("错误", error_msg)
                return
        
        # 清理临时文件
        if xbmcvfs.exists(temp_path):
            xbmcvfs.delete(temp_path)
            
    except Exception as e:
        error_msg = f"无法验证图片信息: {str(e)}"
        xbmc.log(error_msg, xbmc.LOGERROR)
        dialog.ok("错误", error_msg)
        return
    
    # 创建备份目录
    backup_dir = "/storage/backup/"
    if not xbmcvfs.exists(backup_dir):
        try:
            xbmcvfs.mkdir(backup_dir)
            xbmc.log(f"创建备份目录: {backup_dir}", xbmc.LOGINFO)
        except Exception as e:
            error_msg = f"无法创建备份目录: {backup_dir}\n错误详情: {str(e)}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            dialog.ok("错误", error_msg)
            return
    
    # 将/flash目录挂载为可读写
    try:
        xbmc.log("尝试挂载 /flash 目录为可读写", xbmc.LOGINFO)
        mount_cmd = ["mount", "-o", "remount,rw", "/flash"]
        result = subprocess.run(mount_cmd, capture_output=True, text=True, check=False)  # 不使用check=True以捕获所有情况
        
        # 检查挂载结果
        if result.returncode != 0:
            xbmc.log(f"挂载命令返回码: {result.returncode}, 错误: {result.stderr}", xbmc.LOGWARNING)
            # 不立即失败，继续尝试其他方法
        else:
            xbmc.log("/flash 目录挂载成功", xbmc.LOGINFO)
            
    except Exception as e:
        xbmc.log(f"挂载命令执行异常: {str(e)}", xbmc.LOGERROR)
        
        # 尝试不同的挂载方式
        try:
            # 检查当前挂载状态
            mount_status_result = subprocess.run(["cat", "/proc/mounts"], capture_output=True, text=True)
            if mount_status_result.returncode == 0 and "/flash" in mount_status_result.stdout:
                xbmc.log("发现 /flash 挂载点，尝试重新挂载", xbmc.LOGINFO)
                remount_result = subprocess.run(["mount", "-o", "remount,rw", "/flash"], capture_output=True, text=True)
                if remount_result.returncode != 0:
                    error_msg = f"无法挂载/flash目录为可读写\n挂载命令错误: {remount_result.stderr}"
                    xbmc.log(error_msg, xbmc.LOGERROR)
                    dialog.ok("错误", error_msg)
                    return
            else:
                error_msg = f"无法找到/flash挂载点\n挂载表内容: {mount_status_result.stdout if mount_status_result.returncode == 0 else '无法读取'}"
                xbmc.log(error_msg, xbmc.LOGERROR)
                dialog.ok("错误", error_msg)
                return
        except Exception as e2:
            error_msg = f"无法挂载/flash目录为可读写: {str(e2)}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            dialog.ok("错误", error_msg)
            return
    
    # 获取目标路径
    target_path = "/flash/oemsplash.png"
    xbmc.log(f"目标路径: {target_path}", xbmc.LOGINFO)
    
    # 复制原文件到备份目录（如果存在）
    if xbmcvfs.exists(target_path):
        try:
            # 生成备份文件名
            import time
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_filename = f"oemsplash_{timestamp}.png"
            backup_path = os.path.join(backup_dir, backup_filename)
            
            # 执行备份
            if xbmcvfs.copy(target_path, backup_path):
                success_msg = f"已备份原文件至: {backup_path}"
                xbmc.log(success_msg, xbmc.LOGINFO)
            else:
                warning_msg = "原文件备份失败，但仍将继续替换操作"
                xbmc.log(warning_msg, xbmc.LOGWARNING)
                dialog.ok("警告", warning_msg)
        except Exception as e:
            warning_msg = f"原文件备份失败: {str(e)}，但仍将继续替换操作"
            xbmc.log(warning_msg, xbmc.LOGWARNING)
            dialog.ok("警告", warning_msg)
    
    # 复制新文件到目标位置
    try:
        xbmc.log(f"开始复制文件: {image_path} -> {target_path}", xbmc.LOGINFO)
        
        # 使用xbmcvfs.copy进行文件复制
        copy_result = xbmcvfs.copy(image_path, target_path)
        if copy_result:
            # 验证复制是否成功
            if xbmcvfs.exists(target_path):
                # 修改文件权限（如果可能的话）
                try:
                    os.chmod(target_path, 0o644)  # 设置为 rw-r--r--
                    xbmc.log(f"成功设置文件权限: {target_path}", xbmc.LOGINFO)
                except Exception as perm_error:
                    xbmc.log(f"设置文件权限失败: {str(perm_error)}", xbmc.LOGWARNING)
                
                # 显示成功消息
                success_msg = "已成功替换开机图片！\n\n新图片路径: /flash/oemsplash.png"
                xbmc.log("开机图片替换成功", xbmc.LOGINFO)
                dialog.ok("成功", success_msg)
            else:
                error_msg = "文件复制完成后验证失败！目标文件不存在。"
                xbmc.log(error_msg, xbmc.LOGERROR)
                dialog.ok("错误", error_msg)
        else:
            error_msg = f"文件复制失败！\n源文件: {image_path}\n目标: {target_path}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            dialog.ok("错误", error_msg)
    except Exception as e:
        error_msg = f"复制过程中发生错误: {str(e)}"
        xbmc.log(error_msg, xbmc.LOGERROR)
        dialog.ok("错误", error_msg)

if __name__ == "__main__":
    xbmc.log("启动开机图片替换脚本", xbmc.LOGINFO)
    run_script()
    xbmc.log("开机图片替换脚本执行完毕", xbmc.LOGINFO)