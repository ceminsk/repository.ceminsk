import xbmc
import xbmcaddon
import xbmcvfs
import os
import sqlite3
import base64

def log(message):
    xbmc.log("Skin Logo Script: %s" % message, level=xbmc.LOGINFO)

def main():
    # 首先设置默认失败状态
    xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
    
    # 数据库文件路径
    if xbmc.getCondVisibility('System.Platform.Linux'):
        # CoreELEC 或 Linux 系统
        db_path = '/storage/.config/system.d/MyVideos.db'
    else:
        # Windows 系统
        db_path = 'C:\\Users\\Administrator\\storage\\config\\system.d\\MyVideos.db'
    
    # 检查数据库文件是否存在
    file_exists = False
    attempts = 0
    
    while not file_exists and attempts < 3:
        if xbmcvfs.exists(db_path):
            file_exists = True
        else:
            log("Database file not found, waiting 20 seconds... (attempt %d)" % (attempts + 1))
            xbmc.sleep(20000)
            attempts += 1
    
    if not file_exists:
        log("Database file does not exist after 3 attempts, exiting with failure")
        xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
        return
    
    # 获取用户数据目录 - 使用 xbmcvfs.translatePath 替代 xbmc.translatePath
    userdata_path = xbmcvfs.translatePath('special://userdata/addon_data/')
    skin_folder = 'skin.confluence.minsk/'
    idkey_path = os.path.join(userdata_path, skin_folder, 'idkey')
    
    # 确保路径在不同系统上都能正常工作
    idkey_path = idkey_path.replace('\\', '/')
    
    qq_number = None
    
    # 尝试从 idkey 文件读取 QQ 号
    try:
        if xbmcvfs.exists(idkey_path):
            with xbmcvfs.File(idkey_path) as f:
                content = f.read()
                lines = content.splitlines()
                if lines:
                    first_line = lines[0].strip()
                    # 提取数字串
                    import re
                    numbers = re.findall(r'\d+', first_line)
                    if numbers:
                        qq_number = numbers[0]
                        log("Read QQ number from idkey file: %s" % qq_number)
    except Exception as e:
        log("Failed to read from idkey file: %s" % str(e))
    
    # 如果从文件读取失败，尝试从皮肤字符串获取
    if not qq_number:
        skinauth = xbmc.getInfoLabel('Skin.String(skinauth)')
        if skinauth and skinauth.strip() != '':
            qq_number = skinauth.strip()
            log("Read QQ number from Skin.String(skinauth): %s" % qq_number)
    
    # 如果仍然没有 QQ 号，设置失败并退出
    if not qq_number:
        log("No QQ number found from idkey file or Skin.String(skinauth), exiting with failure")
        xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
        return
    
    # 将 QQ 号进行 base64 编码
    try:
        qq_encoded = base64.b64encode(qq_number.encode('utf-8')).decode('utf-8')
        log("Encoded QQ number: %s -> %s" % (qq_number, qq_encoded))
    except Exception as e:
        log("Failed to encode QQ number: %s" % str(e))
        xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
        return
    
    # 连接数据库并查询
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 查询 ce 表中 c2 字段匹配编码后 QQ 号的记录
        query = "SELECT c4 FROM ce WHERE c2 = ?"
        cursor.execute(query, (qq_encoded,))
        result = cursor.fetchone()
        
        if result is None:
            log("No matching record found in database for encoded QQ number: %s" % qq_encoded)
            xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
        else:
            c4_value = result[0]
            log("Found record, c4 value: %s" % str(c4_value))
            
            # 检查 c4 字段的值
            if str(c4_value) == '1':
                log("Authorization successful, setting skinlogofail to 0")
                xbmc.executebuiltin('Skin.SetString(skinlogofail,0)')
            else:
                log("Authorization failed (c4 is not 1), setting skinlogofail to 1")
                xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')
        
        conn.close()
    except Exception as e:
        log("Database operation failed: %s" % str(e))
        xbmc.executebuiltin('Skin.SetString(skinlogofail,1)')

if __name__ == '__main__':
    main()