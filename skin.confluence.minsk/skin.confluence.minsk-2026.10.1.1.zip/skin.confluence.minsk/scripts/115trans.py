import xbmc
import xbmcgui
import sqlite3
import os
import time

def _resolve_userdata_db_dir():
    """获取 special://userdata/Database/ 的本地绝对路径（兼容新旧Kodi版本）"""
    try:
        import xbmcvfs
        return xbmcvfs.translatePath('special://userdata/Database/')
    except Exception:
        try:
            return xbmc.translatePath('special://userdata/Database/')
        except Exception:
            return ''

def is_no_core():
    """
    检测当前系统是否为 No / LibreELEC 核心。
    方法：检查 /etc/os-release 文件内容是否包含 'no' 或 'libreelec'（均不区分大小写）。
    """
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def get_video_db_path():
    """
    获取视频数据库路径：
      - No/LibreELEC 核心：Database 目录下修改时间最新的 MyVideos14*.db
      - 普通核心：Database 目录下修改时间最新的 MyVideos13*.db
    未找到时回退到 MyVideos131.db。
    """
    db_dir = get_database_dir()
    prefix = 'MyVideos14' if is_no_core() else 'MyVideos13'
    latest = _find_latest_db(db_dir, prefix)
    if latest:
        return latest
    return os.path.join(db_dir, 'MyVideos131.db')


def get_texture_db_path():
    """
    获取图片数据库路径：
      - No/LibreELEC 核心：Textures14.db
      - 普通核心：Textures13.db
    """
    db_dir = get_database_dir()
    texture_name = 'Textures14.db' if is_no_core() else 'Textures13.db'
    return os.path.join(db_dir, texture_name)


def get_database_dir():
    """获取 special://userdata/Database/ 的本地绝对路径（兼容新旧Kodi版本）"""
    try:
        import xbmcvfs
        return xbmcvfs.translatePath('special://userdata/Database/')
    except Exception:
        try:
            return xbmc.translatePath('special://userdata/Database/')
        except Exception:
            return ''


def _find_latest_db(db_dir, prefix):
    """
    在数据库目录中查找修改时间最新的、以 prefix 开头的 .db 文件。
    未找到或出错时返回 None。
    """
    try:
        if not db_dir or not os.path.isdir(db_dir):
            return None
        latest_path = None
        latest_mtime = -1
        for name in os.listdir(db_dir):
            if name.startswith(prefix) and name.endswith('.db'):
                full_path = os.path.join(db_dir, name)
                if not os.path.isfile(full_path):
                    continue
                try:
                    mtime = os.path.getmtime(full_path)
                except Exception:
                    continue
                if mtime > latest_mtime:
                    latest_mtime = mtime
                    latest_path = full_path
        return latest_path
    except Exception:
        return None


def get_database_path():
    """获取KODI数据库路径（No/LibreELEC核心取最新 MyVideos14*.db，普通核心取最新 MyVideos13*.db）"""
    return get_video_db_path()


def replace_115open_to_115(db_path):
    """将115open替换为115"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 查询所有包含115open的路径（不区分大小写）
        cursor.execute("SELECT idPath, strPath FROM path WHERE LOWER(strPath) LIKE '%115open%';")
        records = cursor.fetchall()
        
        updated_count = 0
        for record in records:
            old_path = record[1]
            # 不区分大小写替换第一个匹配的115open为115
            new_path = replace_first_ignore_case(old_path, '115open', '115')
            
            if new_path != old_path:
                # 更新数据库记录
                cursor.execute("UPDATE path SET strPath = ? WHERE idPath = ?", (new_path, record[0]))
                updated_count += 1
        
        conn.commit()
        conn.close()
        xbmc.log(f"115open to 115 conversion completed. Updated {updated_count} records", xbmc.LOGINFO)
        return updated_count
    except Exception as e:
        xbmc.log(f"Error converting 115open to 115: {str(e)}", xbmc.LOGERROR)
        return -1

def replace_115_to_115open(db_path):
    """将115替换为115open"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 查询所有包含115但不包含115open的路径
        cursor.execute("SELECT idPath, strPath FROM path WHERE LOWER(strPath) LIKE '%115%' AND LOWER(strPath) NOT LIKE '%115open%';")
        records = cursor.fetchall()
        
        updated_count = 0
        for record in records:
            old_path = record[1]
            # 替换第一个115为115open
            new_path = old_path.replace('115', '115open', 1)
            
            if new_path != old_path:
                # 更新数据库记录
                cursor.execute("UPDATE path SET strPath = ? WHERE idPath = ?", (new_path, record[0]))
                updated_count += 1
        
        conn.commit()
        conn.close()
        xbmc.log(f"115 to 115open conversion completed. Updated {updated_count} records", xbmc.LOGINFO)
        return updated_count
    except Exception as e:
        xbmc.log(f"Error converting 115 to 115open: {str(e)}", xbmc.LOGERROR)
        return -1

def replace_first_ignore_case(text, old, new):
    """不区分大小写替换第一个匹配项"""
    import re
    # 使用正则表达式查找第一个匹配项（不区分大小写）
    pattern = re.compile(re.escape(old), re.IGNORECASE)
    match = pattern.search(text)
    if match:
        start = match.start()
        end = match.end()
        return text[:start] + new + text[end:]
    return text

def run_backup_script():
    """运行备份脚本"""
    try:
        xbmc.executebuiltin('RunScript(special://skin/scripts/backuplib.py)')
        return True
    except Exception as e:
        xbmc.log(f"Error running backup script: {str(e)}", xbmc.LOGERROR)
        return False

def main():
    # 创建选择对话框
    dialog = xbmcgui.Dialog()
    options = [
        "将媒体库115open新接口全部转为115老接口",
        "将媒体库115老接口全部转为115open新接口",
        "备份/恢复媒体库(只备份数据库,不含海报)"
    ]
    
    selected_option = dialog.select("请选择操作", options)
    
    if selected_option == -1:  # 用户取消选择
        return
    
    db_path = get_database_path()
    
    if not os.path.exists(db_path):
        dialog.ok("错误", f"数据库文件不存在:\n{db_path}")
        return
    
    if selected_option == 0:  # 115open转115
        result = replace_115open_to_115(db_path)
        if result >= 0:
            if result > 0:
                message = f"115open转115操作已完成\n共转换了 {result} 个路径"
                # 显示转换结果，用户点击确定后继续
                dialog.ok("转换完成", message)
                
                # 只有在实际转换发生时才执行后续操作
                # 重载皮肤
                xbmc.executebuiltin('ReloadSkin()')
                # 延时0.5秒
                time.sleep(0.5)
                # 设置焦点
                xbmc.executebuiltin('SetFocus(9000)')
            else:
                message = "115open转115操作已完成\n未发现需要转换的路径"
                dialog.ok("转换完成", message)
                # 未发生转换时不执行后续操作
        else:
            dialog.ok("错误", "115open转115操作失败，请查看日志")
    
    elif selected_option == 1:  # 115转115open
        result = replace_115_to_115open(db_path)
        if result >= 0:
            if result > 0:
                message = f"115转115open操作已完成\n共转换了 {result} 个路径"
                # 显示转换结果，用户点击确定后继续
                dialog.ok("转换完成", message)
                
                # 只有在实际转换发生时才执行后续操作
                # 重载皮肤
                xbmc.executebuiltin('ReloadSkin()')
                # 延时0.5秒
                time.sleep(0.5)
                # 设置焦点
                xbmc.executebuiltin('SetFocus(9000)')
            else:
                message = "115转115open操作已完成\n未发现需要转换的路径"
                dialog.ok("转换完成", message)
                # 未发生转换时不执行后续操作
        else:
            dialog.ok("错误", "115转115open操作失败，请查看日志")
    
    elif selected_option == 2:  # 备份/恢复媒体库
        run_backup_script()

if __name__ == "__main__":
    main()