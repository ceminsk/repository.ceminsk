import xbmc
import time
import re
import os

# 配置常量
GEN_XML_PATH = "/storage/.kodi/userdata/keymaps/gen.xml"
CHECK_INTERVAL = 1  # 秒

# 缩进配置 (可根据喜好调整)
INDENT_PPI = "  "      # 2 spaces
INDENT_KB = "    "     # 4 spaces
INDENT_KEY = "      "  # 6 spaces

def get_kernel_version():
    """获取系统内核版本字符串"""
    return xbmc.getInfoLabel("System.KernelVersion")

def wait_for_valid_kernel():
    """
    等待直到内核版本有效。
    无效条件：返回值为空、"busy" 或 "忙"
    """
    while True:
        kernel_ver = get_kernel_version()
        if kernel_ver:
            clean_ver = kernel_ver.strip().lower()
            if clean_ver not in ["busy", "忙", "忙碌"]:
                return kernel_ver
        xbmc.log("[LEDSelect] Kernel version is invalid or busy, waiting...", xbmc.LOGDEBUG)
        time.sleep(CHECK_INTERVAL)

def read_xml_file(filepath):
    """读取XML文件内容"""
    try:
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
    except Exception as e:
        xbmc.log("[LEDSelect] Error reading file {}: {}".format(filepath, str(e)), xbmc.LOGERROR)
    return None

def write_xml_file(filepath, content):
    """写入XML文件内容"""
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        xbmc.log("[LEDSelect] Error writing file {}: {}".format(filepath, str(e)), xbmc.LOGERROR)
        return False

def format_key_line(kid):
    """格式化单个 key 标签行"""
    return '{}<key id="{}">playerprocessinfo</key>'.format(INDENT_KEY, kid)

def process_gen_xml():
    """核心逻辑：处理 gen.xml 文件"""
    content = read_xml_file(GEN_XML_PATH)
    if not content:
        xbmc.log("[LEDSelect] gen.xml not found or empty. Exiting.", xbmc.LOGINFO)
        return

    # 定义正则模式
    # 匹配 <fullscreenvideo><keyboard>...</keyboard></fullscreenvideo> 块
    fs_kb_pattern = re.compile(r'(<fullscreenvideo>\s*<keyboard>)(.*?)(</keyboard>\s*</fullscreenvideo>)', re.DOTALL | re.IGNORECASE)
    # 匹配 playerprocessinfo 键 ID
    key_ppi_pattern = re.compile(r'<key\s+id="([^"]+)">playerprocessinfo</key>')
    # 匹配 <playerprocessinfo> 块
    ppi_pattern = re.compile(r'(<playerprocessinfo>)(.*?)(</playerprocessinfo>)', re.DOTALL | re.IGNORECASE)
    # 匹配 ppi 中的 keyboard 内部结构，用于精准定位插入点
    # Group 1: <playerprocessinfo>...<keyboard>
    # Group 2: Keyboard 内部内容
    # Group 3: </keyboard>...</playerprocessinfo>
    ppi_kb_inner_pattern = re.compile(r'(<playerprocessinfo>\s*<keyboard>)(.*?)(</keyboard>\s*</playerprocessinfo>)', re.DOTALL | re.IGNORECASE)
    # 匹配 back 键
    key_back_pattern = re.compile(r'<key\s+id="([^"]+)">back</key>')

    # 1. 从 fullscreenvideo 中提取所有的 playerprocessinfo 键 ID
    fs_match = fs_kb_pattern.search(content)
    source_ids = []
    if fs_match:
        source_ids = key_ppi_pattern.findall(fs_match.group(2))
    
    # 去重，保留首次出现的顺序
    unique_source_ids = list(dict.fromkeys(source_ids))

    if not unique_source_ids:
        xbmc.log("[LEDSelect] No 'playerprocessinfo' keys found in fullscreenvideo. Nothing to do.", xbmc.LOGDEBUG)
        return

    xbmc.log("[LEDSelect] Found source keys: {}".format(unique_source_ids), xbmc.LOGDEBUG)

    # 2. 检查 playerprocessinfo 块是否存在
    ppi_match = ppi_pattern.search(content)
    new_content = content
    needs_reload = False

    if not ppi_match:
        # --- 子情况 3.1: 不包含 <playerprocessinfo> 字段 ---
        xbmc.log("[LEDSelect] Sub-case 3.1: Creating new playerprocessinfo block.", xbmc.LOGINFO)
        
        # 构建格式化的键行
        formatted_keys = "\n".join([format_key_line(kid) for kid in unique_source_ids])
        
        # 按照美观格式构建新块
        new_block = """{0}<playerprocessinfo>
{1}<keyboard>
{2}
{1}</keyboard>
{0}</playerprocessinfo>""".format(INDENT_PPI, INDENT_KB, formatted_keys)
        
        if "</keymap>" in new_content:
            new_content = new_content.replace("</keymap>", "\n" + new_block + "\n</keymap>")
        else:
            new_content += "\n" + new_block + "\n</keymap>\n"
        
        needs_reload = True

    else:
        # --- 子情况 3.2 & 3.3: 包含 <playerprocessinfo> 字段 ---
        xbmc.log("[LEDSelect] Sub-case 3.2/3.3: Updating existing playerprocessinfo block.", xbmc.LOGINFO)
        
        ppi_content = ppi_match.group(0)
        
        # 获取已有的 key IDs
        existing_ids = key_ppi_pattern.findall(ppi_content)
        
        # 找出需要新增的 IDs
        ids_to_add = [kid for kid in unique_source_ids if kid not in existing_ids]
        
        if ids_to_add:
            xbmc.log("[LEDSelect] Adding missing keys: {}".format(ids_to_add), xbmc.LOGDEBUG)
            
            # 构建要插入的字符串，前面加换行符以确保不与上一行粘连
            insert_str = "\n" + "\n".join([format_key_line(kid) for kid in ids_to_add])
            
            # 使用更精细的正则找到 <keyboard> 和 </keyboard> 之间的内容
            kb_match = ppi_kb_inner_pattern.search(ppi_content)
            if kb_match:
                pre = kb_match.group(1) # <playerprocessinfo>...<keyboard>
                mid = kb_match.group(2) # 中间的内容
                post = kb_match.group(3) # </keyboard>...</playerprocessinfo>
                
                # 关键优化：清理 mid 末尾的空白，确保 insert_str 能正确换行
                clean_mid = mid.rstrip()
                
                # 如果原本为空，直接放入；否则追加
                if clean_mid:
                    combined_mid = clean_mid + insert_str
                else:
                    # 如果原本为空，去掉 insert_str 开头的换行，因为 pre 后面可能已经有换行了
                    # 但为了保险，我们统一处理：
                    combined_mid = insert_str.lstrip('\n')
                
                # 重新组装 PPI 块，确保 </keyboard> 前也有换行（如果 combined_mid 没以换行结尾）
                if not combined_mid.endswith('\n'):
                    combined_mid += '\n'
                    
                new_ppi_content = pre + combined_mid + post
                
                # 替换原内容
                new_content = new_content.replace(ppi_content, new_ppi_content)
                needs_reload = True
                
                # 更新 ppi_content 用于后续 back 键检查
                ppi_content = new_ppi_content

        # --- 处理 Back 键冲突 (子情况 3.2 和 3.3 共有逻辑) ---
        # 只有在刚刚添加了新键的情况下，才需要检查冲突
        if ids_to_add:
            # 在最新的 new_content 中重新定位 PPI 块
            current_ppi_match = ppi_pattern.search(new_content)
            if current_ppi_match:
                current_ppi_content = current_ppi_match.group(0)
                curr_kb_match = ppi_kb_inner_pattern.search(current_ppi_content)
                
                if curr_kb_match:
                    curr_pre = curr_kb_match.group(1)
                    curr_mid = curr_kb_match.group(2)
                    curr_post = curr_kb_match.group(3)
                    
                    # 查找所有的 back 键 ID
                    back_ids_in_ppi = key_back_pattern.findall(curr_mid)
                    
                    keys_removed = False
                    if back_ids_in_ppi:
                        new_mid_content = curr_mid
                        
                        for back_id in back_ids_in_ppi:
                            # 确认返回按键id与刚刚复制插入的按键id是否相同
                            if back_id in ids_to_add:
                                xbmc.log("[LEDSelect] Removing conflicting back key with id: {}".format(back_id), xbmc.LOGINFO)
                                # 匹配整行并删除，包括前后的空白和换行
                                # \s* 匹配行首缩进， \s*\n? 匹配行尾空白和换行
                                line_pattern = re.compile(r'\s*<key\s+id="{}">back</key>\s*\n?'.format(re.escape(back_id)))
                                new_mid_content = line_pattern.sub('', new_mid_content)
                                keys_removed = True
                    
                    if keys_removed:
                        # 清理可能产生的多余空行
                        new_mid_content = re.sub(r'\n\s*\n', '\n', new_mid_content).strip() + '\n'
                        
                        # 重新组装
                        final_ppi_content = curr_pre + new_mid_content + curr_post
                        new_content = new_content.replace(current_ppi_content, final_ppi_content)
                        needs_reload = True

    if needs_reload:
        if write_xml_file(GEN_XML_PATH, new_content):
            xbmc.log("[LEDSelect] File updated. Reloading keymaps.", xbmc.LOGINFO)
            xbmc.executebuiltin("Action(reloadkeymaps)")
        else:
            xbmc.log("[LEDSelect] Failed to write file.", xbmc.LOGERROR)
    else:
        xbmc.log("[LEDSelect] No changes needed.", xbmc.LOGDEBUG)

def main():
    xbmc.log("[LEDSelect] Script started.", xbmc.LOGINFO)
    
    # 1. 等待有效的内核版本
    kernel_ver = wait_for_valid_kernel()
    xbmc.log("[LEDSelect] Kernel Version: {}".format(kernel_ver), xbmc.LOGINFO)
    
    kernel_lower = kernel_ver.lower()
    
    # 2. 判断逻辑
    if "libreelec" not in kernel_lower:
        # 情况 1: 不包含 libreelec
        xbmc.log("[LEDSelect] Case 1: Not LibreELEC. Exiting.", xbmc.LOGINFO)
        return
        
    if "hades" in kernel_lower:
        # 情况 2: 包含 libreelec，且包含 hades
        xbmc.log("[LEDSelect] Case 2: LibreELEC and Hades detected. Exiting.", xbmc.LOGINFO)
        return
        
    # 情况 3: 包含 libreelec，且不包含 hades
    xbmc.log("[LEDSelect] Case 3: LibreELEC without Hades. Processing keymaps.", xbmc.LOGINFO)
    process_gen_xml()

if __name__ == "__main__":
    main()