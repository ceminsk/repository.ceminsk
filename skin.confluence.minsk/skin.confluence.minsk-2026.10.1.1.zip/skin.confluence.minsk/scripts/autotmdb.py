# -*- coding: utf-8 -*-
import xbmc
# ---- 日志脱敏（防止局域网/WebDAV 路径中的用户名密码明文写入日志）----
try:
    from logmask import sanitize_credentials
except Exception:  # 兜底：模块缺失时不影响脚本原有功能
    def sanitize_credentials(text):
        return text
def _masked_log(*args, **kwargs):
    """写日志前自动脱敏路径中的用户名密码。

    用 *args/**kwargs 转发，保证 level 等参数语义与 xbmc.log 完全一致
    （xbmc.log 的默认级别为 LOGDEBUG）。
    """
    try:
        if args:
            args = (sanitize_credentials(args[0]),) + args[1:]
        elif "msg" in kwargs:
            kwargs["msg"] = sanitize_credentials(kwargs["msg"])
    except Exception:
        pass
    xbmc.log(*args, **kwargs)


def _masked_print(*args, **kwargs):
    """print 同样会被 Kodi 转发到日志，输出前先脱敏。"""
    try:
        args = tuple(sanitize_credentials(a) for a in args)
    except Exception:
        pass
    print(*args, **kwargs)

import xbmcgui
import xbmcvfs
import sqlite3
import os
import sys
import re
import xml.etree.ElementTree as ET
import json
import time
from urllib.parse import unquote

_SELECTED_FOLDER_PATH = None
_SELECTED_FOLDER_NAME = None

def get_item_folder_path():
    global _SELECTED_FOLDER_PATH
    if _SELECTED_FOLDER_PATH:
        return _SELECTED_FOLDER_PATH
    return xbmc.getInfoLabel('ListItem.FolderPath')

def get_item_folder_name():
    global _SELECTED_FOLDER_NAME
    if _SELECTED_FOLDER_NAME:
        return _SELECTED_FOLDER_NAME
    path = get_item_folder_path()
    return os.path.basename(path.rstrip(os.sep)) if path else ""

def is_item_folder():
    global _SELECTED_FOLDER_PATH
    if _SELECTED_FOLDER_PATH:
        return True
    return xbmc.getCondVisibility('ListItem.IsFolder')

def normalize_path(path):
    if not path:
        return path
    sep = os.sep
    if sep == '\\':
        path = path.replace('/', '\\')
        while '\\\\' in path:
            path = path.replace('\\\\', '\\')
    else:
        path = path.replace('\\', '/')
    if not path.endswith(sep):
        path += sep
    return path

CREDENTIAL_SCHEMES = ('dav', 'smb')
RE_URL_AUTHORITY = re.compile(
    r'^(?P<scheme>[A-Za-z][A-Za-z0-9+.\-]*)://'
    r'(?:(?P<userinfo>[^@/?#]*)@)?'
    r'(?P<host>\[[^\]]+\]|[^/?#:\s]+)'
    r'(?::(?P<port>\d+))?'
)
RE_CREDENTIALS_MASK = re.compile(r'(://)[^/@\s]+@')
_passwords_entries_cache = None

def mask_credentials(text):
    if not text:
        return text
    return RE_CREDENTIALS_MASK.sub(r'\1***@', text)

def split_url_authority(url):
    if not url:
        return None
    matched = RE_URL_AUTHORITY.match(url)
    if not matched:
        return None
    scheme = matched.group('scheme').lower()
    authority = url[:matched.end()]
    host_key = '%s://%s' % (scheme, matched.group('host').lower())
    remainder = url[matched.end():]
    return scheme, authority, host_key, remainder

def load_password_entries(force_reload=False):
    global _passwords_entries_cache
    if _passwords_entries_cache is not None and not force_reload:
        return _passwords_entries_cache

    entries = []
    passwords_file = xbmcvfs.translatePath('special://userdata/passwords.xml')

    try:
        if not xbmcvfs.exists(passwords_file):
            pass
        else:
            with xbmcvfs.File(passwords_file, 'r') as f:
                content = f.read()
            if content:
                root = ET.fromstring(content)
                pending_from = None
                pending_version = None
                for node in root.iter():
                    tag = node.tag.lower() if isinstance(node.tag, str) else ''
                    if tag not in ('from', 'to'):
                        continue
                    text = (node.text or '').strip()
                    if not text:
                        continue
                    if tag == 'from':
                        pending_from = text
                        pending_version = node.get('pathversion')
                    elif pending_from:
                        entries.append({
                            'from': pending_from,
                            'to': text,
                            'version': pending_version
                        })
                        pending_from = None
                        pending_version = None
    except Exception as e:
        _masked_log("[SmartScan] Parse passwords.xml error: %s" % str(e), xbmc.LOGWARNING)
        entries = []

    _passwords_entries_cache = entries
    return entries

def build_db_path_with_credentials(path):
    if not path:
        return None

    parts = split_url_authority(path)
    if not parts:
        return None

    scheme, _authority, host_key, remainder = parts
    if scheme not in CREDENTIAL_SCHEMES:
        return None

    candidates = []
    for entry in load_password_entries():
        from_parts = split_url_authority(entry.get('from', ''))
        if not from_parts:
            continue
        if from_parts[0] != scheme or from_parts[2] != host_key:
            continue
        to_parts = split_url_authority(entry.get('to', ''))
        if not to_parts or to_parts[0] != scheme:
            continue
        from_norm = entry['from'].rstrip('/')
        exact_hit = 2 if path.startswith(from_norm) else 1
        is_v1 = 2 if str(entry.get('version') or '') == '1' else 1
        candidates.append((exact_hit, is_v1, len(from_norm), to_parts[1]))

    if not candidates:
        return None

    candidates.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
    new_path = candidates[0][3] + remainder

    if new_path == path:
        return None

    return new_path

def is_no_core():
    """
    检测当前系统是否为 No / LibreELEC 核心。
    方法：检查 /etc/os-release 文件内容是否包含 'no' 或 'libreelec'（均不区分大小写）。
    """
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def get_database_path():
    """获取视频数据库路径（No/LibreELEC核心取最新 MyVideos14*.db，普通核心取最新 MyVideos13*.db）"""
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    if not userdata_path.endswith(os.sep):
        userdata_path += os.sep

    possible_db_dirs = ['Database', 'database']
    db_dir = None

    for dirname in possible_db_dirs:
        candidate = os.path.join(userdata_path, dirname)
        if xbmcvfs.exists(candidate):
            db_dir = candidate
            break

    if not db_dir:
        db_dir = os.path.join(userdata_path, 'Database')

    no_core_detected = is_no_core()
    prefix = 'MyVideos14' if no_core_detected else 'MyVideos13'
    fallback = 'MyVideos149.db' if no_core_detected else 'MyVideos131.db'

    try:
        dirs_in_db, files_in_db = xbmcvfs.listdir(db_dir)
        db_files = []
        for f in files_in_db:
            if f.startswith(prefix) and f.endswith('.db'):
                full_path = os.path.join(db_dir, f)
                try:
                    stat_info = os.stat(full_path)
                    mtime = stat_info.st_mtime
                    db_files.append((full_path, mtime))
                except Exception as e:
                    continue

        if db_files:
            db_files.sort(key=lambda x: x[1], reverse=True)
            return db_files[0][0]
    except Exception as e:
        pass

    return os.path.join(db_dir, fallback)


def get_next_id_path(cursor):
    cursor.execute("SELECT MAX(idPath) FROM path")
    result = cursor.fetchone()
    if result[0] is not None:
        return result[0] + 1
    else:
        return 1

def upsert_path_row(cursor, folder_path, str_content, str_scraper, use_folder_names):
    cursor.execute("SELECT idPath FROM path WHERE strPath=?", (folder_path,))
    res = cursor.fetchone()
    if res:
        path_id = res[0]
        cursor.execute(
            "UPDATE path SET strContent=?, strScraper=?, scanRecursive=?, useFolderNames=? WHERE idPath=?",
            (str_content, str_scraper, 2147483647, use_folder_names, path_id)
        )
    else:
        path_id = get_next_id_path(cursor)
        cursor.execute(
            "INSERT INTO path (idPath, strPath, strContent, strScraper, scanRecursive, useFolderNames) VALUES (?,?,?,?,?,?)",
            (path_id, folder_path, str_content, str_scraper, 2147483647, use_folder_names)
        )

    cred_path = build_db_path_with_credentials(folder_path)
    if cred_path:
        cursor.execute("SELECT idPath FROM path WHERE strPath=?", (cred_path,))
        cred_res = cursor.fetchone()
        if cred_res:
            cursor.execute(
                "UPDATE path SET strContent=?, strScraper=?, scanRecursive=?, useFolderNames=? WHERE idPath=?",
                (str_content, str_scraper, 2147483647, use_folder_names, cred_res[0])
            )
        else:
            cred_id = get_next_id_path(cursor)
            cursor.execute(
                "INSERT INTO path (idPath, strPath, strContent, strScraper, scanRecursive, useFolderNames) VALUES (?,?,?,?,?,?)",
                (cred_id, cred_path, str_content, str_scraper, 2147483647, use_folder_names)
            )

    return path_id

def wait_for_progress_dialog():
    xbmc.sleep(2000)
    while xbmc.getCondVisibility('Window.IsVisible(extendedprogressdialog)'):
        xbmc.sleep(500)

SIZE_THRESHOLD = 20 * 1024 * 1024 * 1024

def check_use_folder_names(folder_path):
    try:
        files = xbmcvfs.listdir(folder_path)
        file_list = files[1]
        dir_list = files[0]
        
        for filename in file_list:
            full_file_path = os.path.join(folder_path, filename)
            if is_episode_filename(full_file_path):
                return True
                
        for dirname in dir_list:
            if is_season_foldername(dirname):
                return True
        return False
    except Exception as e:
        return False

def get_stack_videos_setting():
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    settings_file = os.path.join(userdata_path, 'guisettings.xml')
    if not xbmcvfs.exists(settings_file):
        return None
    try:
        with xbmcvfs.File(settings_file, 'r') as f:
            content = f.read()
        if not content:
            return None
        root = ET.fromstring(content)
        for setting in root.iter('setting'):
            if setting.get('id') == 'myvideos.stackvideos':
                return setting.text.strip().lower() if setting.text else None
    except Exception as e:
        pass
    return None

def execute_json_rpc(method, params):
    payload = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(payload))

RE_EP = re.compile(r'[eE][pP]?\s*\d+', re.IGNORECASE)
RE_CN_EP = re.compile(r'第\s*\d+\s*集', re.IGNORECASE)
RE_SEASON = re.compile(r'^season\s*\d+', re.IGNORECASE)
RE_S = re.compile(r'^[sS]\s*\d+', re.IGNORECASE)
RE_CN_SEASON = re.compile(r'^(\d+|[\u4e00-\u9fa5]+)\s*季', re.IGNORECASE)

def is_episode_filename(filepath):
    filename = os.path.basename(filepath)
    if not (RE_EP.search(filename) or RE_CN_EP.search(filename)):
        return False
    try:
        vf = xbmcvfs.File(filepath)
        file_size = vf.size()
        vf.close()
        if file_size > SIZE_THRESHOLD:
            return False
    except Exception as e:
        pass
    return True

def is_season_foldername(dirname):
    return bool(RE_SEASON.match(dirname) or RE_S.match(dirname) or RE_CN_SEASON.match(dirname))

def update_path_db_for_tvshow(folder_path, use_folder_names_val):
    db_path = get_database_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    folder_path = normalize_path(folder_path)
    upsert_path_row(cursor, folder_path, 'tvshows', 'metadata.tvshows.tmdb.cn.optimization', use_folder_names_val)
    conn.commit()
    conn.close()

def update_path_db_for_movie(folder_path):
    db_path = get_database_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    folder_path = normalize_path(folder_path)
    upsert_path_row(cursor, folder_path, 'movies', 'metadata.tmdb.cn.optimization', 0)
    conn.commit()
    conn.close()

def update_and_scan_tv(folder_path):
    folder_path = normalize_path(folder_path)
    db_path = get_database_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tvshow")
    tv_before = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM episode")
    ep_before = cursor.fetchone()[0]
    conn.close()

    use_folder = 1 if check_use_folder_names(folder_path) else 0
    update_path_db_for_tvshow(folder_path, use_folder)
    xbmc.executebuiltin(f'UpdateLibrary(video,{folder_path})')
    wait_for_progress_dialog()

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tvshow")
    tv_after = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM episode")
    ep_after = cursor.fetchone()[0]
    conn.close()
    return tv_after - tv_before, ep_after - ep_before

def update_and_scan_movie(folder_path):
    folder_path = normalize_path(folder_path)
    db_path = get_database_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM movie")
    movie_before = cursor.fetchone()[0]
    conn.close()

    update_path_db_for_movie(folder_path)
    xbmc.executebuiltin(f'UpdateLibrary(video,{folder_path})')
    wait_for_progress_dialog()

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM movie")
    movie_after = cursor.fetchone()[0]
    conn.close()
    return movie_after - movie_before

def build_subtree(path):
    path = normalize_path(path)
    node = {
        "path": path,
        "name": os.path.basename(path.rstrip(os.sep)),
        "has_episodes": False,
        "has_seasons": False,
        "children": []
    }
    try:
        dirs, files = xbmcvfs.listdir(path)
    except:
        return node
        
    for f in files:
        full_file_path = os.path.join(path, f)
        if is_episode_filename(full_file_path):
            node["has_episodes"] = True
            break
            
    for d in dirs:
        if is_season_foldername(d):
            node["has_seasons"] = True
            break
            
    for d in dirs:
        sub_path = os.path.join(path, d)
        child_node = build_subtree(sub_path)
        node["children"].append(child_node)
        
    return node

def process_smart_scanning():
    is_folder = is_item_folder()
    
    db_path = get_database_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tvshow")
    tv_initial = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM episode")
    ep_initial = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM movie")
    movie_initial = cursor.fetchone()[0]
    conn.close()

    if not is_folder:
        file_path = get_item_folder_path()
        if not is_episode_filename(file_path):
            process_movie_scanning()
        else:
            parent_dir = normalize_path(os.path.dirname(file_path))
            grandparent_dir = normalize_path(os.path.dirname(parent_dir.rstrip(os.sep)))
            parent_name = os.path.basename(parent_dir.rstrip(os.sep))
            
            if is_season_foldername(parent_name):
                target = grandparent_dir
            else:
                target = parent_dir
            
            added_tv, added_ep = update_and_scan_tv(target)
            xbmcgui.Dialog().ok("剧集扫描完成", f"新增剧集 {added_tv} 部，新增单集 {added_ep} 集")
            xbmc.sleep(5000)
            xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')
        return

    root_path = normalize_path(get_item_folder_path())
    root_name = os.path.basename(root_path.rstrip(os.sep))
    
    if is_season_foldername(root_name):
        parent_path = normalize_path(os.path.dirname(root_path.rstrip(os.sep)))
        db_path = get_database_path()
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            use_folder_names_val = 1 if check_use_folder_names(parent_path) else 0
            upsert_path_row(cursor, parent_path, 'tvshows', 'metadata.tvshows.tmdb.cn.optimization', use_folder_names_val)
            conn.commit()
            
            cursor.execute("SELECT COUNT(*) FROM tvshow")
            initial_tvshow_count = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM episode")
            initial_episode_count = cursor.fetchone()[0]
            
            xbmc.executebuiltin(f'UpdateLibrary(video,{parent_path})')
            wait_for_progress_dialog()
            
            cursor.execute("SELECT COUNT(*) FROM tvshow")
            final_tvshow_count = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM episode")
            final_episode_count = cursor.fetchone()[0]
            
            new_tvshows_count = final_tvshow_count - initial_tvshow_count
            new_episodes_count = final_episode_count - initial_episode_count
            
            conn.close()
            xbmcgui.Dialog().ok("扫描完成", f"本次扫描新增剧集{new_tvshows_count}部，新增单集{new_episodes_count}集！")
            xbmc.sleep(5000)
            xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')
            
        except Exception as e:
            _masked_log(f"DB Error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("错误", "数据库操作失败")
        return

    autotype_path = os.path.join(xbmcvfs.translatePath('special://userdata/addon_data/skin.confluence.minsk'), 'autotype.json')
    addon_data_dir = xbmcvfs.translatePath('special://userdata/addon_data/skin.confluence.minsk')
    if not xbmcvfs.exists(addon_data_dir):
        xbmcvfs.mkdirs(addon_data_dir)

    try:
        root_dirs, root_files = xbmcvfs.listdir(root_path)
        total_primary_items = len(root_dirs) + len(root_files)
    except:
        total_primary_items = 0

    progress = xbmcgui.DialogProgress()
    progress.create("智能分类处理", "正在自动分类处理文件...")
    
    full_tree = {
        "path": root_path,
        "name": root_name,
        "has_episodes": False,
        "has_seasons": False,
        "children": []
    }
    
    for f in root_files:
        full_file_path = os.path.join(root_path, f)
        if is_episode_filename(full_file_path):
            full_tree["has_episodes"] = True
            break
    for d in root_dirs:
        if is_season_foldername(d):
            full_tree["has_seasons"] = True
            break

    processed_count = 0
    all_primary_items = []
    for d in root_dirs:
        all_primary_items.append(('dir', d))
    for f in root_files:
        all_primary_items.append(('file', f))
        
    for item_type, item_name in all_primary_items:
        item_path = os.path.join(root_path, item_name)
        if item_type == 'dir':
            subtree = build_subtree(item_path)
            full_tree["children"].append(subtree)
        
        processed_count += 1
        pct = int(processed_count / total_primary_items * 100) if total_primary_items > 0 else 100
        status_msg = f"{item_name}\n[{processed_count}/{total_primary_items}]"
        progress.update(pct, status_msg)
        
    try:
        with open(autotype_path, 'w', encoding='utf-8') as f:
            json.dump(full_tree, f, ensure_ascii=False, indent=2)
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("错误", "无法生成目录树文件")
        return

    progress.close()

    try:
        with open(autotype_path, 'r', encoding='utf-8') as f:
            tree_data = json.load(f)
    except Exception as e:
        xbmcgui.Dialog().ok("错误", "无法读取目录树文件")
        return

    def process_tree_node_with_parent_context(node, parent_has_seasons):
        current_path = node["path"]
        has_seasons = node["has_seasons"]
        has_episodes = node["has_episodes"]
        
        if has_seasons:
            use_folder_names_val = 1 if check_use_folder_names(current_path) else 0
            update_path_db_for_tvshow(current_path, use_folder_names_val)
            return 
        
        if has_episodes:
            if parent_has_seasons:
                use_folder_names_val = 1 if check_use_folder_names(current_path) else 0
                update_path_db_for_tvshow(current_path, use_folder_names_val)
                return
            else:
                use_folder_names_val = 1 if check_use_folder_names(current_path) else 0
                update_path_db_for_tvshow(current_path, use_folder_names_val)
        
        for child in node.get("children", []):
            process_tree_node_with_parent_context(child, has_seasons)

    process_tree_node_with_parent_context(tree_data, False)

    if tree_data.get("has_episodes") or tree_data.get("has_seasons"):
        update_and_scan_tv(root_path)
    else:
        update_and_scan_movie(root_path)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tvshow")
    tv_final = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM episode")
    ep_final = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM movie")
    movie_final = cursor.fetchone()[0]
    conn.close()
    
    delta_tv = tv_final - tv_initial
    delta_ep = ep_final - ep_initial
    delta_movie = movie_final - movie_initial
    
    msg = f"本次扫描新增电影 {delta_movie} 部，新增剧集 {delta_tv} 部，新增单集 {delta_ep} 集！"
    xbmcgui.Dialog().ok("扫描完成", msg)
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')

def process_movie_scanning():
    is_folder = is_item_folder()
    if is_folder:
        folder_path = normalize_path(get_item_folder_path())
        db_path = get_database_path()
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            upsert_path_row(cursor, folder_path, 'movies', 'metadata.tmdb.cn.optimization', 0)
            conn.commit()
            cursor.execute("SELECT COUNT(*) FROM movie")
            initial_movie_count = cursor.fetchone()[0]
            xbmc.executebuiltin(f'UpdateLibrary(video,{folder_path})')
            wait_for_progress_dialog()
            cursor.execute("SELECT COUNT(*) FROM movie")
            final_movie_count = cursor.fetchone()[0]
            new_movies_count = final_movie_count - initial_movie_count
            xbmcgui.Dialog().ok("扫描完成", f"本次扫描新增电影{new_movies_count}部！")
            xbmc.sleep(5000)
            xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')
            conn.close()
        except Exception as e:
            _masked_log(f"DB Error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("错误", "数据库操作失败")
    else:
        file_path = get_item_folder_path()
        directory_path = normalize_path(os.path.dirname(file_path))
        db_path = get_database_path()
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT idPath, strContent, strScraper, useFolderNames FROM path WHERE strPath=?", (directory_path,))
            result = cursor.fetchone()
            if result:
                upsert_path_row(cursor, directory_path, 'movies', 'metadata.tmdb.cn.optimization', 0)
                conn.commit()
                
                # 在执行 Action(ContextMenu) 指令前统计行数
                cursor.execute("SELECT COUNT(*) FROM movie")
                movie_before = cursor.fetchone()[0]
                
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.executebuiltin('Skin.SetString(strmhide,1)')
                if xbmc.getCondVisibility('Skin.HasSetting(simpletmdb)'):
                    xbmc.sleep(300)
                    xbmc.executebuiltin('Action(ContextMenu)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('setfocus(6001)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(up)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(select)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Skin.SetString(strmhide,"")')
                else:
                    xbmc.sleep(300)
                    xbmc.executebuiltin('Action(ContextMenu)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('setfocus(6000)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(up)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(select)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Skin.SetString(strmhide,"")')
            else:
                upsert_path_row(cursor, directory_path, 'movies', 'metadata.tmdb.cn.optimization', 0)
                conn.commit()
                
                # 在执行 Action(ContextMenu) 指令前统计行数
                cursor.execute("SELECT COUNT(*) FROM movie")
                movie_before = cursor.fetchone()[0]
                
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.executebuiltin('Skin.SetString(strmhide,1)')
                if xbmc.getCondVisibility('Skin.HasSetting(simpletmdb)'):
                    xbmc.sleep(300)
                    xbmc.executebuiltin('Action(ContextMenu)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('setfocus(6000)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(up)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(up)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(select)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Skin.SetString(strmhide,"")')
                else:
                    xbmc.sleep(300)
                    xbmc.executebuiltin('Action(ContextMenu)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('setfocus(6000)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(up)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Action(select)')
                    xbmc.sleep(200)
                    xbmc.executebuiltin('Skin.SetString(strmhide,"")')
            
            # 监测数据库变化
            start_time = time.time()
            timeout = 180  # 3分钟
            
            while True:
                cursor.execute("SELECT COUNT(*) FROM movie")
                current_count = cursor.fetchone()[0]
                
                if current_count == movie_before + 1:
                    break
                elif current_count != movie_before:
                    break
                    
                if time.time() - start_time > timeout:
                    break
                    
                xbmc.sleep(1000)
                
            # 延迟5秒后执行指令并退出
            xbmc.sleep(5000)
            xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')
            conn.close()
            return
            
        except Exception as e:
            _masked_log(f"DB Error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("错误", "数据库操作失败")

def process_tvshow_scanning():
    is_folder = is_item_folder()
    if not is_folder:
        xbmcgui.Dialog().ok("提示", "不支持单集文件扫描海报，请返回上级目录执行该操作！")
        show_main_menu()
        return
    folder_path = normalize_path(get_item_folder_path())
    db_path = get_database_path()
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        use_folder_names_val = 1 if check_use_folder_names(folder_path) else 0
        upsert_path_row(cursor, folder_path, 'tvshows', 'metadata.tvshows.tmdb.cn.optimization', use_folder_names_val)
        conn.commit()
        cursor.execute("SELECT COUNT(*) FROM tvshow")
        initial_tvshow_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM episode")
        initial_episode_count = cursor.fetchone()[0]
        xbmc.executebuiltin(f'UpdateLibrary(video,{folder_path})')
        wait_for_progress_dialog()
        cursor.execute("SELECT COUNT(*) FROM tvshow")
        final_tvshow_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM episode")
        final_episode_count = cursor.fetchone()[0]
        new_tvshows_count = final_tvshow_count - initial_tvshow_count
        new_episodes_count = final_episode_count - initial_episode_count
        xbmcgui.Dialog().ok("扫描完成", f"本次扫描新增剧集{new_tvshows_count}部，新增单集{new_episodes_count}集！")
        xbmc.sleep(5000)
        xbmc.executebuiltin('RunScript(special://skin/scripts/chkposterurl.py)')
        conn.close()
    except Exception as e:
        _masked_log(f"DB Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("错误", "数据库操作失败")

def check_folder_scan_status():
    xbmc.executebuiltin('RunScript(special://skin/scripts/foldertmdb.py)')

def manage_poster_data():
    folder_path = get_item_folder_path()
    xbmc.executebuiltin(f'RunScript(special://skin/scripts/checkdellib.py,folder)')

def show_main_menu():
    is_folder = is_item_folder()
    dialog = xbmcgui.Dialog()
    if is_folder:
        options = [
            "智能识别类别扫描海报",
            "以电影类别扫描海报",
            "以剧集类别扫描海报",
            "规范化重命名文件/文件夹",
            "查看本文件夹扫描情况",
            "查看/删除已刮削海报数据"
        ]
    else:
        options = [
            "智能识别类别扫描海报",
            "以电影类别扫描海报",
            "以剧集类别扫描海报",
            "规范化重命名文件/文件夹"
        ]
    selected = dialog.select("请选择扫描类型", options)
    if selected == 0:
        process_smart_scanning()
    elif selected == 1:
        process_movie_scanning()
    elif selected == 2:
        process_tvshow_scanning()
    elif selected == 3:
        xbmc.executebuiltin('RunScript(special://skin/scripts/renametv.py)')
    elif selected == 4 and is_folder:
        check_folder_scan_status()
    elif selected == 5 and is_folder:
        manage_poster_data()
    else:
        return

def run_original_logic():
    show_main_menu()

def cleanup_and_exit():
    xbmc.executebuiltin('Skin.SetString(bdmvoff,"")')
    execute_json_rpc("Settings.SetSettingValue", {"setting": "myvideos.stackvideos", "value": False})

def main():
    global _SELECTED_FOLDER_PATH, _SELECTED_FOLDER_NAME
    
    if len(sys.argv) > 1 and sys.argv[1] == 'library':
        dialog = xbmcgui.Dialog()
        source_options = [
            "从挂载网盘中选择",
            "从局域网NAS/SMB/NFS/webdav路径选择"
        ]
        source_selected = dialog.select("请选择文件夹来源", source_options)
        
        if source_selected == -1:
            return
            
        selected_path = ""
        if source_selected == 0:
            selected_path = dialog.browse(0, "请选择要扫描的文件夹", 'files', '', False, False)
        elif source_selected == 1:
            selected_path = dialog.browse(0, "请选择要扫描的文件夹", '', '', False, False)
            
        if not selected_path:
            return
            
        _SELECTED_FOLDER_PATH = normalize_path(selected_path)
        _SELECTED_FOLDER_NAME = os.path.basename(_SELECTED_FOLDER_PATH.rstrip(os.sep))
        show_main_menu()
        
    elif len(sys.argv) > 1 and sys.argv[1] == 'manage':
        bdmvoff_val = xbmc.getInfoLabel('Skin.String(bdmvoff)')
        is_bdmvoff_1 = (bdmvoff_val == '1')
        stack_val = get_stack_videos_setting()
        is_stack_true = (stack_val == 'true')
        if is_bdmvoff_1:
            if is_stack_true:
                run_original_logic()
                cleanup_and_exit()
            else:
                execute_json_rpc("Settings.SetSettingValue", {"setting": "myvideos.stackvideos", "value": True})
                xbmc.sleep(300)
                xbmc.executebuiltin('Container.Refresh')
                run_original_logic()
                cleanup_and_exit()
        else:
            if is_stack_true:
                run_original_logic()
            else:
                xbmc.executebuiltin('Skin.SetString(bdmvoff,1)')
                execute_json_rpc("Settings.SetSettingValue", {"setting": "myvideos.stackvideos", "value": True})
                xbmc.sleep(300)
                xbmc.executebuiltin('Container.Refresh')
                run_original_logic()
                cleanup_and_exit()
    else:
        pass

if __name__ == "__main__":
    main()