#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import time
import xbmc
import xbmcgui
import xbmcvfs

class MemoryCleaner:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        
    def log(self, message):
        """输出日志到 Kodi 日志系统"""
        xbmc.log("[CleanMem] " + message, xbmc.LOGINFO)
        
    def run_command(self, command):
        """执行 shell 命令并返回输出"""
        try:
            # 使用 check_output 捕获输出，stderr 重定向到 stdout 以便查看错误
            result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
            return result.decode('utf-8').strip()
        except subprocess.CalledProcessError as e:
            self.log("命令执行失败: %s, 错误: %s" % (command, str(e.output)))
            return None
        except Exception as e:
            self.log("执行命令异常: %s, 错误: %s" % (command, str(e)))
            return None
            
    def get_memory_info(self):
        """获取当前内存使用情况"""
        mem_info = {}
        try:
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        # 提取数值部分 (kB)
                        value_str = parts[1].strip().split()[0]
                        try:
                            mem_info[key] = int(value_str)
                        except ValueError:
                            continue
        except Exception as e:
            self.log("读取内存信息失败: %s" % str(e))
            return None
        return mem_info
        
    def get_memory_usage_percent(self):
        """计算内存使用百分比"""
        mem_info = self.get_memory_info()
        if not mem_info or 'MemTotal' not in mem_info or 'MemAvailable' not in mem_info:
            return 0
            
        total = mem_info['MemTotal']
        available = mem_info['MemAvailable']
        if total == 0:
            return 0
        used = total - available
        return (used / float(total)) * 100
        
    def clean_caches(self, level=3):
        """清理内存缓存
        level: 1=只清理页缓存, 2=清理目录项和inode, 3=清理所有缓存
        """
        # 先同步数据到磁盘，确保脏页写入磁盘后再清理缓存
        self.log("开始同步文件系统...")
        self.run_command('sync')
        
        # 清理缓存
        self.log("清理内核页面缓存 (level=%d)..." % level)
        # 需要 root 权限才能写入此文件
        result = self.run_command('echo %d > /proc/sys/vm/drop_caches' % level)
        
        if result is not None:
            self.log("内核缓存清理指令已发送")
            return True
        else:
            self.log("内核缓存清理失败 (可能需要 Root 权限)")
            return False
            
    def clean_swap(self):
        """清理交换分区（如果启用）"""
        # 检查是否启用了 swap
        swap_info = self.run_command('swapon --show')
        if not swap_info or swap_info.strip() == "":
            self.log("未检测到活跃的交换分区，跳过 Swap 清理")
            return True
            
        self.log("检测到交换分区，开始清理...")
        # 关闭并重新启用 swap 以强制将数据移回 RAM
        result1 = self.run_command('swapoff -a')
        if result1 is not None:
            time.sleep(1)  # 等待一下再启用
            result2 = self.run_command('swapon -a')
            if result2 is not None:
                self.log("交换分区重置完成")
                return True
        self.log("交换分区清理失败")
        return False
        
    def compact_memory(self):
        """内存规整（可选）"""
        self.log("尝试进行内存规整...")
        result = self.run_command('echo 1 > /proc/sys/vm/compact_memory')
        if result is not None:
            self.log("内存规整指令已发送")
            return True
        else:
            self.log("内存规整失败（可能内核不支持或权限不足）")
            return False
            
    def check_kodi_internal_stats(self):
        """仅检查 Kodi 内部缓存状态，不进行清理"""
        self.log("检查 Kodi 内部存储状态...")
        
        try:
            # 获取数据库路径
            db_path = xbmc.getUserPath() + "Database/"
            texture_db = db_path + "Textures13.db"
            
            if xbmcvfs.exists(texture_db):
                file_stat = xbmcvfs.Stat(texture_db)
                if file_stat:
                    size_mb = file_stat.st_size / (1024 * 1024)
                    self.log("纹理数据库大小: %.2f MB (仅记录，未清理)" % size_mb)
                    
            # 检查缩略图目录存在性
            thumbnails_path = xbmc.getUserPath() + "Thumbnails/"
            if xbmcvfs.exists(thumbnails_path):
                self.log("缩略图目录存在 (仅记录，未清理)")
                
        except Exception as e:
            self.log("检查 Kodi 状态时出错: %s" % str(e))
            
        return True
        
    def show_progress(self, message):
        """显示进度对话框"""
        dialog = xbmcgui.DialogProgress()
        dialog.create("内存清理工具", message)
        dialog.update(0)
        return dialog
        
    def perform_cleanup(self, clean_swap=False, compact=False, show_dialog=True):
        """执行完整的清理流程"""
        self.log("=" * 50)
        self.log("开始执行内存清理 (不含缩略图清理)")
        
        # 获取清理前内存状态
        before_mem = self.get_memory_usage_percent()
        before_info = self.get_memory_info()
        
        before_avail_mb = 0
        if before_info:
            before_total = before_info['MemTotal'] / 1024  # 转换为 MB
            before_avail_mb = before_info['MemAvailable'] / 1024
            self.log("清理前 - 总内存: %d MB, 可用: %d MB, 使用率: %.1f%%" % 
                    (before_total, before_avail_mb, before_mem))
        
        progress = None
        if show_dialog:
            progress = self.show_progress("开始清理...")
            progress.update(10, "正在同步文件系统...")
        
        # 1. 同步文件系统
        self.run_command('sync')
        
        if show_dialog:
            progress.update(30, "正在清理系统内核缓存...")
        
        # 2. 清理内核缓存（使用 level 3 最彻底）
        self.clean_caches(3)
        time.sleep(1)  # 等待系统稳定
        
        if show_dialog:
            progress.update(60, "正在检查 Kodi 状态...")
        
        # 3. 检查 Kodi 相关状态 (只读，不清理)
        self.check_kodi_internal_stats()
        
        # 4. 清理交换分区（可选）
        if clean_swap:
            if show_dialog:
                progress.update(80, "正在清理交换分区...")
            self.clean_swap()
            
        # 5. 内存规整（可选）
        if compact:
            if show_dialog:
                progress.update(90, "正在整理内存碎片...")
            self.compact_memory()
            
        # 获取清理后内存状态
        time.sleep(2) # 给系统一点时间反映内存变化
        after_mem = self.get_memory_usage_percent()
        after_info = self.get_memory_info()
        
        after_avail_mb = 0
        freed_mb = 0
        if after_info:
            after_avail_mb = after_info['MemAvailable'] / 1024
            self.log("清理后 - 可用内存: %d MB, 使用率: %.1f%%" % 
                    (after_avail_mb, after_mem))
            
            if before_info:
                freed_mb = after_avail_mb - before_avail_mb
                self.log("释放内存估算: %.1f MB" % freed_mb)
        
        if show_dialog and progress:
            progress.update(100, "清理完成！")
            time.sleep(1)
            progress.close()
            
            # 显示结果对话框
            result_msg = "✅ 内存清理完成！\n\n"
            result_msg += "⚠️ 注意：未清理缩略图缓存\n\n"
            if before_info and after_info:
                result_msg += "📊 清理前可用: %d MB\n" % before_avail_mb
                result_msg += "📊 清理后可用: %d MB\n" % after_avail_mb
                
                if freed_mb > 0:
                    result_msg += "✨ 预计释放: %.1f MB" % freed_mb
                else:
                    result_msg += "ℹ️ 内存变化不大 (可能已被系统自动管理)"
            else:
                result_msg += "系统内核缓存已清理"
                
            self.dialog.ok("清理完成", result_msg)
            
        self.log("内存清理流程结束")
        self.log("=" * 50)
        return True
        
def main():
    """主函数"""
    cleaner = MemoryCleaner()
    
    # 解析命令行参数
    clean_swap = False
    compact = False
    silent = False
    
    for arg in sys.argv[1:]:
        if arg == '--swap':
            clean_swap = True
        elif arg == '--compact':
            compact = True
        elif arg == '--silent':
            silent = True
            
    # 执行清理
    # 注意：不再传递 clean_texture 参数，因为功能已移除
    cleaner.perform_cleanup(
        clean_swap=clean_swap, 
        compact=compact, 
        show_dialog=not silent
    )
    
    return 0

if __name__ == '__main__':
    main()