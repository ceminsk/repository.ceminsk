import sys
import xbmc
# ---- 日志脱敏（防止局域网/WebDAV 路径中的用户名密码明文写入日志）----
try:
    from logmask import sanitize_credentials
except Exception:  # 兜底：模块缺失时不影响脚本原有功能
    def sanitize_credentials(text):
        return text
def _masked_log(*args, **kwargs):
    """写日志前自动脱敏路径中的用户名密码。

    用 *args/**kwargs 转发，保证 level 等参数语义与 xbmc.log 完全一致
    （xbmc.log 的默认级别为 LOGDEBUG）。
    """
    try:
        if args:
            args = (sanitize_credentials(args[0]),) + args[1:]
        elif "msg" in kwargs:
            kwargs["msg"] = sanitize_credentials(kwargs["msg"])
    except Exception:
        pass
    xbmc.log(*args, **kwargs)


def _masked_print(*args, **kwargs):
    """print 同样会被 Kodi 转发到日志，输出前先脱敏。"""
    try:
        args = tuple(sanitize_credentials(a) for a in args)
    except Exception:
        pass
    print(*args, **kwargs)

import xbmcaddon
import xbmcgui
import sqlite3
from urllib.parse import unquote, urlparse
import binascii
import re
import time
import os

def log_msg(msg):
    """统一日志输出函数，写入 Kodi 日志"""
    _masked_log(sanitize_credentials(f"[CastPhoto Script] {msg}"), level=xbmc.LOGINFO)

def is_url_format(path_string):
    """
    检查字符串是否为URL格式
    """
    if not path_string:
        return False
    
    if path_string.startswith("/emby_addon_mode"):
        return True
    
    url_pattern = re.compile(
        r'^[a-zA-Z][a-zA-Z0-9+.-]*://',
        re.IGNORECASE
    )
    
    return bool(url_pattern.match(path_string))

def decode_nextgen_url(url: str, decode_percent: bool = False) -> str:
    """
    解码 NextGen URL，提取原始文件路径。
    """
    if not url:
        return url

    if not is_url_format(url):
        return url

    original_url = url

    def get_fallback():
        return deep_unquote(original_url) if decode_percent else original_url

    # 1. 清理预处理
    if url.startswith("/emby_addon_mode"):
        url = url.replace("/emby_addon_mode", "")
    elif '://' in url:
        try:
            p = urlparse(url)
            url = p.path
        except:
            pass

    if url.startswith("/http/"):
        url = url.replace("/http", "")
    elif url.startswith("/dynamic/"):
        url = url.replace("/dynamic", "")

    # 2. 识别类型
    parts = url.strip('/').split('/')
    if not parts: return get_fallback()
    filename = parts[-1]

    is_audio = "/audio/" in url or filename.startswith("a-") or filename.startswith("emby-themes-audio-")
    is_picture = "/picture/" in url
    is_video = not (is_audio or is_picture)
    
    raw_path = ""
    
    try:
        if is_audio:
            if filename.startswith("emby-themes-audio-"):
                filename = filename.replace("emby-themes-audio-", "a-")
            
            data_parts = filename.split('-')
            
            if len(data_parts) >= 4:
                hex_str = data_parts[3]
                try:
                    raw_path = bytes.fromhex(hex_str).decode('utf-8')
                except binascii.Error:
                    return get_fallback()
            else:
                return get_fallback()

        elif is_video:
            if len(parts) < 2:
                return get_fallback()

            data_str = None
            for part in reversed(parts):
                if part.count('-') >= 4 and not any(c.isalpha() and c.lower() not in ['a', 'b', 'c', 'd', 'e', 'f'] for c in part.replace('-', '')):
                    data_str = part
                    break

            if data_str is None:
                for part in reversed(parts):
                    if '-' in part and len(part) > 10:
                        data_parts = part.split("-")
                        if len(data_parts) >= 5:
                            if all(c in '0123456789abcdefABCDEF' for c in data_parts[4]):
                                data_str = part
                                break

            if data_str is None:
                if '-' in filename:
                    data_parts = filename.split("-")
                    if len(data_parts) >= 5:
                        if all(c in '0123456789abcdefABCDEF' for c in data_parts[4]):
                            data_str = filename

            if data_str is None:
                return get_fallback()

            if data_str.startswith("emby-themes-video-"):
                data_str = data_str.replace("emby-themes-video-", "v-")
            
            data_parts = data_str.split("-")
            
            if len(data_parts) < 5:
                return get_fallback()
                
            hex_metadata = data_parts[4]
            try:
                metadata_str = bytes.fromhex(hex_metadata).decode('utf-8')
            except binascii.Error:
                return get_fallback()
                
            media_sources = metadata_str.split("<>")
            found_paths = []
            
            for ms in media_sources:
                sections = ms.split("<<")
                if sections:
                    info_part = sections[0]
                    infos = info_part.split(":")
                    if len(infos) >= 4:
                        p = infos[3].replace("<;>", ":")
                        found_paths.append(p)
            
            if len(found_paths) >= 1:
                raw_path = found_paths[0]
            else:
                return get_fallback()

        else:
            return get_fallback()

    except Exception as e:
        log_msg(f"Error decoding URL: {e}")
        return get_fallback()

    if decode_percent:
        raw_path = deep_unquote(raw_path)
    
    return raw_path

def is_no_core():
    """
    检测当前系统是否为 No / LibreELEC 核心。
    方法：检查 /etc/os-release 文件内容是否包含 'no' 或 'libreelec'（均不区分大小写）。
    """
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def get_kodi_database_path():
    """获取Kodi数据库路径（No/LibreELEC核心取最新 MyVideos14*.db，普通核心取最新 MyVideos13*.db）"""
    try:
        import xbmcvfs
        translate_func = xbmcvfs.translatePath
    except AttributeError:
        try:
            translate_func = xbmc.translatePath
        except AttributeError:
            home_dir = xbmc.translatePath("special://home")
            if hasattr(home_dir, 'decode'): home_dir = home_dir.decode('utf-8')
            db_dir = os.path.join(home_dir, "userdata", "Database")
            prefix = 'MyVideos14' if is_no_core() else 'MyVideos13'
            latest = _find_latest_db(db_dir, prefix)
            return latest if latest else os.path.join(db_dir, "MyVideos131.db")

    db_dir = translate_func("special://userdata/Database/")
    prefix = 'MyVideos14' if is_no_core() else 'MyVideos13'
    latest = _find_latest_db(db_dir, prefix)
    return latest if latest else os.path.join(db_dir, "MyVideos131.db")


def _find_latest_db(db_dir, prefix):
    """在数据库目录中查找修改时间最新的、以 prefix 开头的 .db 文件，找不到返回 None"""
    try:
        if not db_dir or not os.path.isdir(db_dir):
            return None
        latest_path = None
        latest_mtime = -1
        for name in os.listdir(db_dir):
            if name.startswith(prefix) and name.endswith('.db'):
                full_path = os.path.join(db_dir, name)
                if not os.path.isfile(full_path):
                    continue
                try:
                    mtime = os.path.getmtime(full_path)
                except Exception:
                    continue
                if mtime > latest_mtime:
                    latest_mtime = mtime
                    latest_path = full_path
        return latest_path
    except Exception:
        return None


def deep_unquote(path_string):
    """
    深度 URL 解码，处理多重编码情况
    """
    if not path_string:
        return path_string
    
    current_string = path_string
    
    for _ in range(5):
        if '%' not in current_string:
            break
        
        decoded = unquote(current_string)
        if decoded == current_string:
            break
            
        current_string = decoded
        
    return current_string

def ensure_path_decoded(path_string):
    """兼容旧接口"""
    return deep_unquote(path_string)

def clean_bluray_path(path_string):
    """
    清理蓝光/UDF 虚拟路径前缀及 BDMV 路径后缀。
    """
    if not path_string:
        return path_string

    # 1. 清理前缀
    prefix_pattern = re.compile(r'(bluray://|udf://|bluray%3a%2f%2f|udf%3a%2f%2f)', re.IGNORECASE)
    match = prefix_pattern.search(path_string[:50])
    
    while match:
        path_string = path_string[:match.start()] + path_string[match.end():]
        match = prefix_pattern.search(path_string[:50])

    # 2. 清理 BDMV/PLAYLIST 后缀
    check_suffix = path_string[-50:] if len(path_string) >= 50 else path_string
    bdmv_match = re.search(r'/BDMV/PLAYLIST/.*$', check_suffix, re.IGNORECASE)
    
    if bdmv_match:
        offset = len(path_string) - len(check_suffix)
        start_idx = offset + bdmv_match.start()
        path_string = path_string[:start_idx]

    # 3. 处理结尾字符
    sep_pattern = r'(%2f|/)$'
    
    if re.search(r'\.iso' + sep_pattern, path_string, re.IGNORECASE):
        path_string = re.sub(sep_pattern, '', path_string, flags=re.IGNORECASE)
    elif re.search(sep_pattern, path_string, re.IGNORECASE):
        path_string = path_string + "BDMV/index.bdmv"

    return path_string

def get_url_param(url_string, param_name):
    """
    从查询字符串中提取指定参数的值（取最左侧一次出现）。
    未找到返回 ""。
    """
    if not url_string:
        return ""

    match = re.search(
        r'(?:^|[?&])' + re.escape(param_name) + r'=([^&]*)',
        url_string,
        re.IGNORECASE
    )
    if not match:
        return ""

    return match.group(1).strip()

def detect_pan_provider(raw_url_value):
    """
    根据 url 字段中的网盘地址特征判断网盘名称，忽略大小写。
    无法识别时返回 "未知网盘"。
    """
    if not raw_url_value:
        return "未知网盘"

    # 网盘地址本身通常被 URL 编码，先解码再匹配特征
    decoded = raw_url_value
    for _ in range(3):
        if '%' not in decoded:
            break
        new_decoded = unquote(decoded)
        if new_decoded == decoded:
            break
        decoded = new_decoded

    target = decoded.lower()

    # 顺序敏感：先匹配长/特征性强的域名，最后再匹配 "115" 这类短特征
    provider_rules = [
        (("aliyun", "alipan"), "阿里网盘"),
        (("quark",), "夸克网盘"),
        (("baidu",), "百度网盘"),
        (("xunlei",), "迅雷网盘"),
        (("123pan.com", "123864.com", "123865.com", "123278.com"), "123网盘"),
        (("139.com",), "移动网盘"),
        (("189.cn", "21cn.com"), "天翼网盘"),
        (("guangya",), "光鸭网盘"),
        (("uc.cn",), "UC网盘"),
        (("115", "anxia"), "115网盘"),
    ]

    for keywords, provider_name in provider_rules:
        for keyword in keywords:
            if keyword in target:
                return provider_name

    return "未知网盘"

def format_file_size(raw_size_value):
    """
    将字节单位的大小转换为 GB，保留两位小数。
    无效数据返回 "未知大小"。
    """
    if not raw_size_value:
        return "未知大小"

    size_text = raw_size_value.strip()

    # 仅接受纯数字（允许空格千分位），拒绝 1.5e3 / abc / 0x.. 等异常写法
    if not re.fullmatch(r'\d+(?:[ \u00a0,]\d{3})*', size_text):
        return "未知大小"

    try:
        size_bytes = int(size_text.replace(',', '').replace(' ', '').replace('\u00a0', ''))
    except (ValueError, TypeError):
        return "未知大小"

    if size_bytes <= 0:
        return "未知大小"

    size_gb = size_bytes / (1024 ** 3)
    return f"{size_gb:.2f}GB"

def extract_juku_short_path(path_string):
    """
    检测以 plugin://plugin.video.juku 开头的网盘播放路径，
    命中则提取网盘信息、file_name 与文件大小，
    简化为 "巨库源-网盘信息-file_name 文件大小"。
    未命中返回 None。
    """
    if not path_string:
        return None

    candidates = [path_string]

    # 兼容整条路径被整体 URL 编码一次的情况
    if '%' in path_string:
        once_decoded = unquote(path_string)
        if once_decoded != path_string:
            candidates.append(once_decoded)

    prefix = 'plugin://plugin.video.juku'

    for candidate in candidates:
        candidate = candidate.strip()
        if not candidate.lower().startswith(prefix):
            continue

        file_name = get_url_param(candidate, 'file_name')
        if not file_name:
            continue

        provider_name = detect_pan_provider(get_url_param(candidate, 'url'))
        file_size_text = format_file_size(get_url_param(candidate, 'file_size'))

        return f"巨库源-{provider_name}-{file_name} {file_size_text}"

    return None

def sanitize_url(url_string):
    """
    移除 URL 中的用户名和密码部分，防止敏感信息泄露。
    修复：只清除协议头和第一个斜杠之间的认证信息。
    """
    if not url_string:
        return url_string

    protocol_end_idx = url_string.find('://')
    if protocol_end_idx == -1:
        return url_string
    
    path_start_idx = url_string.find('/', protocol_end_idx + 3)
    search_end_idx = path_start_idx if path_start_idx != -1 else len(url_string)
    
    auth_section = url_string[protocol_end_idx + 3 : search_end_idx]
    at_idx_in_auth = auth_section.rfind('@')
    
    if at_idx_in_auth != -1:
        host_part = auth_section[at_idx_in_auth + 1:]
        new_url = url_string[:protocol_end_idx + 3] + host_part + url_string[search_end_idx:]
        return new_url
    
    return url_string

def main():
    if len(sys.argv) < 2:
        log_msg("Usage: script.py simple | play")
        return

    command = sys.argv[1]
    
    dbtype = ""
    dbid = ""
    is_play_mode = (command == "play")
    
    if is_play_mode:
        if xbmc.getCondVisibility("VideoPlayer.Content(movies)"):
            dbtype = "movie"
        elif xbmc.getCondVisibility("VideoPlayer.Content(episodes)"):
            dbtype = "episode"
        else:
            dbtype = "unknown"
            
        dbid = xbmc.getInfoLabel("VideoPlayer.DBID")
    elif command == "simple":
        dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
        dbid = xbmc.getInfoLabel("ListItem.DBID")
    else:
        log_msg("Usage: script.py simple | play")
        return

    original_url = ""
    db_query_successful = False
    
    if dbtype and dbtype != "unknown" and dbid:
        try:
            dbid_int = int(dbid)
        except ValueError:
            dbid_int = 0
            
        if dbid_int > 0:
            database_path = get_kodi_database_path()
            try:
                conn = sqlite3.connect(database_path)
                cursor = conn.cursor()
                
                query_map = {
                    "movie": "SELECT strPath, strFileName FROM movie_view WHERE idMovie = ?",
                    "episode": "SELECT strPath, strFileName FROM episode_view WHERE idEpisode = ?",
                    "tvshow": "SELECT strPath FROM tvshow_view WHERE idShow = ?",
                    "season": "SELECT strPath FROM season_view WHERE idSeason = ?"
                }
                
                if dbtype in query_map:
                    cursor.execute(query_map[dbtype], (dbid_int,))
                    results = cursor.fetchall()
                    
                    if results and len(results) == 1:
                        row = results[0]
                        if dbtype in ["movie", "episode"]:
                            combined_path = row[0] + row[1] if row[0] and row[1] else ""
                        else:
                            combined_path = row[0] if row[0] else ""
                            
                        if combined_path:
                            if is_url_format(combined_path):
                                original_url = decode_nextgen_url(combined_path, decode_percent=True)
                            else:
                                original_url = combined_path
                            db_query_successful = True
                    elif len(results) > 1:
                        log_msg(f"DB Query returned multiple rows for {dbtype}, using fallback.")

                conn.close()
            except Exception as e:
                log_msg(f"DB Error: {e}")

    if not db_query_successful:
        if is_play_mode:
            time.sleep(2)
            player_path = xbmc.getInfoLabel("Player.FilenameAndPath")
            if player_path:
                original_url = player_path
        else:
            fallback_path = xbmc.getInfoLabel("ListItem.FileNameAndPath")
            if fallback_path:
                original_url = fallback_path

    if original_url:
        # 0. plugin://plugin.video.juku 路径简化（在 URL 解码之前判断）
        juku_short_path = extract_juku_short_path(original_url)
        if juku_short_path:
            final_path = juku_short_path
            log_msg(f"Juku path simplified: {final_path}")
        else:
            # 1. 清理蓝光/UDF 路径
            final_path = clean_bluray_path(original_url)

        # 2. URL Decode
        final_path = ensure_path_decoded(final_path)

        # 3. Sanitize Credentials
        final_path = sanitize_url(final_path)
        
        # 4. Set Skin Variable
        xbmc.executebuiltin(f'Skin.SetString(shortpath,{final_path})')
        log_msg(f"Shortpath set: {final_path}")
    else:
        log_msg("Failed to extract valid path")

if __name__ == "__main__":
    main()