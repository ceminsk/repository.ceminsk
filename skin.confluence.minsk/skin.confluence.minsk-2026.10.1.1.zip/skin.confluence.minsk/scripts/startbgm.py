import xbmc
import xbmcgui
import sys

def main():
    # 获取命令行参数
    args = sys.argv
    
    if len(args) > 1 and args[1] == "warn":
        # 检查权限条件：!String.IsEqual(Skin.String(authfail),1) 和 String.IsEqual(Skin.String(skinlogofail),0) 同时为真
        auth_condition = not xbmc.getCondVisibility('String.IsEqual(Skin.String(authfail),1)')
        skin_logo_condition = xbmc.getCondVisibility('String.IsEqual(Skin.String(skinlogofail),0)')
        
        if auth_condition and skin_logo_condition:
            # 权限条件满足，直接退出脚本
            return
        else:
            # 权限条件不满足，清空自定义BGM设置
            xbmc.executebuiltin('Skin.SetString(custombgm,)')
            
            # 延时0.5秒
            xbmc.sleep(500)
            
            # 关闭文件浏览器对话框
            xbmc.executebuiltin('Dialog.Close(filebrowser)')
            
            # 弹出确认窗
            dialog = xbmcgui.Dialog()
            dialog.ok('警告', '您未获得自定义开机音效权限！')
            
            return
    
    # 设置开始音乐标志
    xbmc.executebuiltin('Skin.SetString(startmusic,1)')
    
    # 检查是否有自定义背景音乐设置
    has_custom_bgm_setting = xbmc.getCondVisibility('Skin.HasSetting(custombgmon)')
    
    if not has_custom_bgm_setting:
        # 情况1：custombgmon为"否"
        play_default_sound_and_wait_3s()
    else:
        # 情况2：custombgmon为"真"
        # 检查权限条件：!String.IsEqual(Skin.String(authfail),1) 和 String.IsEqual(Skin.String(skinlogofail),0) 同时为真
        auth_condition = not xbmc.getCondVisibility('String.IsEqual(Skin.String(authfail),1)')
        skin_logo_condition = xbmc.getCondVisibility('String.IsEqual(Skin.String(skinlogofail),0)')
        
        if auth_condition and skin_logo_condition:
            # 权限条件满足，检查自定义BGM路径
            custom_bgm_path = xbmc.getInfoLabel('Skin.String(custombgm)')
            
            if not custom_bgm_path or custom_bgm_path.strip() == '':
                # 自定义BGM路径为空
                play_default_sound_and_wait_3s()
            else:
                # 播放自定义BGM路径的音频
                xbmc.executebuiltin(f'PlayMedia({custom_bgm_path})')
                
                # 延时2秒
                xbmc.sleep(3000)
                
                # 监测播放状态直到媒体播放结束
                while xbmc.getCondVisibility('Player.HasMedia'):
                    xbmc.sleep(100)  # 等待100毫秒后再次检查
                
                # 播放结束后设置标志
                xbmc.executebuiltin('Skin.SetString(startmusic,0)')
        else:
            # 权限条件不满足，清空自定义BGM设置，播放默认音频
            xbmc.executebuiltin('Skin.SetString(custombgm,)')
            play_default_sound_and_wait_3s()

def play_default_sound_and_wait_3s():
    # 播放默认启动音效
    xbmc.executebuiltin('PlayMedia(special://skin/resources/start.mp3)')
    
    # 延时3秒
    xbmc.sleep(3000)
    
    # 监测播放状态直到媒体播放结束
    while xbmc.getCondVisibility('Player.HasMedia'):
        xbmc.sleep(100)  # 等待100毫秒后再次检查
    
    # 播放结束后设置标志
    xbmc.executebuiltin('Skin.SetString(startmusic,0)')

if __name__ == '__main__':
    main()