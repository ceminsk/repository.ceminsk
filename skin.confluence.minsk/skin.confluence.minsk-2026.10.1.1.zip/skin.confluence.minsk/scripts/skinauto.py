#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import datetime
import base64
import json
import time
import os
import sys
import platform
import sqlite3
import xml.etree.ElementTree as ET
import uuid
import re
import subprocess
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
import ssl

def get_access_credential():
    parts = ["NmVlYjAzZjc", "2ZDBhOWM4OTE", "1OTEzMzM5ZDk4NjQ5NmQ="]
    return base64.b64decode("".join(parts)).decode("utf-8")

GITEE_CONFIG = {
    "owner": "ce-fans",
    "repo": "Minsk-skinauth",
    "db_path_in_repo": "minsk-auth/MyVideos.db",
    "skinauth_path_in_repo": "minsk-auth/skinauth.txt",
    "authsort_path_in_repo": "minsk-auth/authsort.txt",
    "branch": "master"
}

RETRY_TIMES = 3
DB_RETRY_INTERVAL = 60
WRITE_RETRY_INTERVAL = 120
AUTH_SORT_RETRY_INTERVAL = 60
MAX_DEVICE_COUNT = 3
TIMEOUT = 30

def log(msg, level=xbmc.LOGINFO):
    if level in [xbmc.LOGWARNING, xbmc.LOGERROR]:
        level_name = {xbmc.LOGWARNING: "WARNING", xbmc.LOGERROR: "ERROR"}.get(level, "UNKNOWN")
        msg_fmt = f"[SKINAUTH][{level_name}] {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {msg}"
        try:
            xbmc.log(msg_fmt, level)
            print(msg_fmt)
        except Exception:
            print(f"Log failed: {msg_fmt}")

def is_android():
    try:
        if "Android" in platform.system(): return True
        if hasattr(platform, 'platform') and 'android' in platform.platform().lower(): return True
        if os.path.exists("/system/build.prop") or os.path.exists("/data/data/org.xbmc.kodi"): return True
    except Exception: pass
    return False

def is_coreelec():
    try:
        if os.path.exists("/storage/.config"): return True
        uname = platform.uname()
        if "coreelec" in uname.release.lower() or "coreelec" in uname.version.lower(): return True
    except Exception: pass
    return False

def get_db_path():
    if is_android():
        path = "/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/Database/MyVideos.db"
    elif is_coreelec():
        path = "/storage/.config/system.d/MyVideos.db"
    else:
        path = os.path.join(os.path.expanduser("~"), ".kodi", "userdata", "Database", "MyVideos.db")
    
    d = os.path.dirname(path)
    if not os.path.exists(d):
        try: os.makedirs(d)
        except Exception as e: log(f"Failed to create DB dir: {e}", xbmc.LOGERROR)
    return os.path.normpath(path)

def get_addon_data_path():
    try:
        try: import xbmcvfs; up = xbmcvfs.translatePath("special://userdata")
        except ImportError: up = xbmc.translatePath("special://userdata")
        if isinstance(up, bytes): up = up.decode("utf-8")
        path = os.path.join(up, "addon_data", "skin.confluence.minsk")
    except Exception:
        if is_android():
            path = "/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/skin.confluence.minsk"
        elif is_coreelec():
            path = "/storage/.kodi/userdata/addon_data/skin.confluence.minsk"
        else:
            path = os.path.join(os.environ.get("APPDATA", ""), "Kodi", "userdata", "addon_data", "skin.confluence.minsk")
    
    path = os.path.normpath(path)
    if not os.path.exists(path):
        try: os.makedirs(path)
        except Exception as e: log(f"Failed to create addon data dir: {e}", xbmc.LOGERROR)
    return path

def get_idkey_path():
    return os.path.normpath(os.path.join(get_addon_data_path(), "idkey"))

def get_settings_xml_path():
    return os.path.normpath(os.path.join(get_addon_data_path(), "settings.xml"))

def read_idkey():
    p = get_idkey_path()
    if not os.path.exists(p): return "", ""
    try:
        with open(p, "r", encoding="utf-8") as f: content = f.read().strip()
        if content:
            parts = content.split(",")
            if len(parts) == 2:
                qq, dt = parts[0].strip(), parts[1].strip()
                if qq.isdigit() and dt.isdigit() and len(dt) == 6: return qq, dt
    except Exception as e: log(f"Read idkey failed: {e}", xbmc.LOGERROR)
    return "", ""

def write_idkey(qq, dt):
    if not (qq.isdigit() and dt.isdigit() and len(dt) == 6): return False
    p = get_idkey_path()
    try:
        with open(p, "w", encoding="utf-8") as f: f.write(f"{qq},{dt}")
        with open(p, "r", encoding="utf-8") as f: 
            if f.read().strip() == f"{qq},{dt}": return True
    except Exception as e: log(f"Write idkey failed: {e}", xbmc.LOGERROR)
    return False

def read_settings_xml():
    p = get_settings_xml_path()
    if not os.path.exists(p): return "", ""
    try:
        tree = ET.parse(p)
        root = tree.getroot()
        s_elem = root.find(".//setting[@id='skinauth'][@type='string']")
        d_elem = root.find(".//setting[@id='authdate'][@type='string']")
        s = s_elem.text.strip() if s_elem is not None and s_elem.text else ""
        d = d_elem.text.strip() if d_elem is not None and d_elem.text else ""
        return s, d
    except Exception as e: log(f"Read settings.xml failed: {e}", xbmc.LOGERROR)
    return "", ""

def get_auth_credentials():
    qq, dt = read_idkey()
    if qq and dt: return qq, dt
    return read_settings_xml()

def get_device_id():
    ident = "UNKNOWN_ID"
    sys_name = platform.system()
    is_ce = is_coreelec()
    
    if is_ce or sys_name == "Linux":
        cpu_serial = None
        try:
            with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("Serial"):
                        parts = line.split(":")
                        if len(parts) > 1:
                            cpu_serial = parts[1].strip()
                            break
            if cpu_serial and cpu_serial != "0000000000000000":
                ident = cpu_serial
        except Exception: pass
        
        if not ident or ident == "UNKNOWN_ID":
            try:
                mac_int = uuid.getnode()
                if mac_int:
                    ident = ":".join(f"{(mac_int >> i) & 0xff:02x}" for i in range(0, 48, 8)).upper()
            except Exception: pass
            
    if not ident or ident == "UNKNOWN_ID" or (not is_ce and sys_name != "Linux"):
        p = os.path.join(get_addon_data_path(), ".device_unique_id")
        try:
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    sid = f.read().strip()
                    if sid: ident = sid
                    else: raise ValueError("Empty")
            else:
                new_id = str(uuid.uuid4())
                with open(p, "w", encoding="utf-8") as f: f.write(new_id)
                ident = new_id
        except Exception:
            ident = str(uuid.uuid4())

    return ident.replace(":", "").replace("-", "").upper()

def hide_qq(qq):
    if not qq or not qq.isdigit(): return ""
    l = len(qq)
    if l == 5: return f"{qq[0]}{'*' * 2}{qq[-2:]}"
    elif l > 5: return f"{qq[0]}{'*' * (l - 4)}{qq[-3:]}"
    return qq

def validate_date(dt):
    return bool(dt and dt.isdigit() and len(dt) == 6)

def http_request(url, headers=None, data=None, timeout=30):
    if headers is None: headers = {}
    if "User-Agent" not in headers:
        headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    
    req = Request(url, headers=headers, data=data.encode() if data else None)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    try:
        return urlopen(req, timeout=timeout, context=ctx)
    except HTTPError as e:
        # Re-raise HTTP errors so the caller can handle specific codes like 403
        raise
    except URLError as e:
        log(f"HTTP request failed: {e}", xbmc.LOGERROR)
        raise

def download_db_via_curl(local_path, token):
    """
    专门用于下载数据库文件的 Curl 包装器
    修复：正确处理二进制内容，避免 UTF-8 解码错误
    """
    api_url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['db_path_in_repo']}?ref={GITEE_CONFIG['branch']}&access_token={token}"
    temp_json_path = local_path + ".tmp.json"
    
    cmd = [
        "curl", "-s", "-L", 
        "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "-o", temp_json_path,
        api_url
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT+10)
        if result.returncode != 0:
            if os.path.exists(temp_json_path): os.remove(temp_json_path)
            return False
            
        if not os.path.exists(temp_json_path):
            return False
            
        with open(temp_json_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
            
        if os.path.exists(temp_json_path):
            os.remove(temp_json_path)
            
        if "content" not in json_data:
            return False
            
        content_b64 = json_data["content"].replace("\n", "")
        
        # 关键修复：base64 解码后得到的是 bytes，直接写入二进制文件，不要 decode('utf-8')
        db_content = base64.b64decode(content_b64)
        
        with open(local_path, "wb") as f:
            f.write(db_content)
            
        if os.path.exists(local_path) and os.path.getsize(local_path) > 1024:
            log("DB downloaded successfully via CURL", xbmc.LOGINFO)
            return True
        else:
            log("Decoded DB file is missing or too small", xbmc.LOGWARNING)
            return False
            
    except Exception as e:
        log(f"CURL DB download exception: {e}", xbmc.LOGERROR)
        if os.path.exists(temp_json_path): os.remove(temp_json_path)
        return False

def download_text_file_via_curl(repo_path, token):
    """
    使用 Curl 下载文本文件 (如 authsort.txt, skinauth.txt)
    返回: (success, content_string, sha)
    """
    api_url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{repo_path}?ref={GITEE_CONFIG['branch']}&access_token={token}"
    
    temp_json_path = os.path.join(get_addon_data_path(), f"curl_temp_txt_{int(time.time())}.json")
    
    cmd = [
        "curl", "-s", "-L", 
        "-A", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "-o", temp_json_path,
        api_url
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT+10)
        if result.returncode != 0:
            if os.path.exists(temp_json_path): os.remove(temp_json_path)
            return False, "", None
            
        if not os.path.exists(temp_json_path):
            return False, "", None
            
        with open(temp_json_path, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
            
        if os.path.exists(temp_json_path):
            os.remove(temp_json_path)
            
        if "message" in json_data and "content" not in json_data:
             log(f"Gitee API Error during CURL download: {json_data['message']}", xbmc.LOGERROR)
             return False, "", None

        if "content" not in json_data:
            return False, "", None
            
        sha = json_data.get("sha")
        content_b64 = json_data["content"].replace("\n", "")
        # 文本文件可以安全地 decode 为 utf-8
        content = base64.b64decode(content_b64).decode("utf-8")
        
        return True, content, sha
            
    except Exception as e:
        log(f"CURL text download exception: {e}", xbmc.LOGERROR)
        if os.path.exists(temp_json_path): os.remove(temp_json_path)
        return False, "", None

def download_db():
    local_path = get_db_path()
    token = get_access_credential()
    api_url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['db_path_in_repo']}?ref={GITEE_CONFIG['branch']}"
    success = False
    
    for i in range(1, RETRY_TIMES + 1):
        try:
            # 第一次尝试使用 Python urllib
            if i == 1:
                log(f"DB download attempt {i} (Python urllib)...")
                headers = {"Authorization": f"token {token}", "Accept": "application/json"}
                resp = http_request(api_url, headers=headers, timeout=TIMEOUT)
                data = json.loads(resp.read().decode('utf-8'))
                
                if "content" not in data: raise Exception("No content field")
                
                content = base64.b64decode(data["content"].replace("\n", ""))
                with open(local_path, "wb") as f: f.write(content)
                
                if os.path.exists(local_path) and os.path.getsize(local_path) > 1024:
                    success = True
                    log("DB downloaded successfully via Python", xbmc.LOGINFO)
                    break
                else:
                    raise Exception("File too small")
            else:
                # 后续尝试或 Python 失败后，改用 Curl
                raise Exception("Switching to CURL method")

        except HTTPError as e:
            if e.code == 403:
                log(f"HTTP 403 Forbidden detected. Switching to CURL for this attempt.", xbmc.LOGWARNING)
                if download_db_via_curl(local_path, token):
                    success = True
                    break
                else:
                    log("CURL fallback also failed.", xbmc.LOGERROR)
            else:
                log(f"DB download failed ({i}): HTTP Error {e.code}", xbmc.LOGERROR)
                if i < RETRY_TIMES: time.sleep(DB_RETRY_INTERVAL)
                
        except Exception as e:
            if "Switching to CURL" in str(e):
                 if download_db_via_curl(local_path, token):
                    success = True
                    break
                 else:
                    if i < RETRY_TIMES: 
                        log("CURL failed, waiting before retry...", xbmc.LOGWARNING)
                        time.sleep(DB_RETRY_INTERVAL)
            else:
                log(f"DB download failed ({i}): {e}", xbmc.LOGERROR)
                if i < RETRY_TIMES: time.sleep(DB_RETRY_INTERVAL)
            
    if not success: log("DB download failed after all retries", xbmc.LOGWARNING)
    return success

def query_db(qq_b64):
    db_path = get_db_path()
    if not os.path.exists(db_path): return []
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        cursor = conn.cursor()
        cursor.execute("SELECT c3 FROM ce WHERE c2 = ?", (qq_b64,))
        res = [row[0] for row in cursor.fetchall()]
        conn.close()
        return res
    except Exception as e:
        log(f"DB query failed: {e}", xbmc.LOGERROR)
        return []

def write_gitee_skinauth(qq, dt):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    dev_id = get_device_id()
    new_line = f"{qq} {dt} {now} {dev_id}"
    success = False
    token = get_access_credential()
    
    for i in range(1, RETRY_TIMES + 1):
        try:
            url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['skinauth_path_in_repo']}?ref={GITEE_CONFIG['branch']}"
            headers = {"Authorization": f"token {token}"}
            
            sha = None
            old_content = ""
            
            # 尝试 Python 获取旧内容
            use_curl_get = False
            try:
                resp = http_request(url, headers=headers, timeout=TIMEOUT)
                f_data = json.loads(resp.read().decode('utf-8'))
                sha = f_data.get("sha")
                old_content = base64.b64decode(f_data.get("content", "")).decode("utf-8")
            except Exception as e:
                log(f"Python GET skinauth failed, trying CURL: {e}", xbmc.LOGWARNING)
                use_curl_get = True
                
            if use_curl_get:
                curl_success, curl_content, curl_sha = download_text_file_via_curl(GITEE_CONFIG['skinauth_path_in_repo'], token)
                if curl_success:
                    sha = curl_sha
                    old_content = curl_content
                else:
                    log("CURL GET skinauth also failed", xbmc.LOGERROR)
                    if i < RETRY_TIMES:
                         time.sleep(WRITE_RETRY_INTERVAL)
                         continue
                    else:
                         break

            content = new_line if not old_content.strip() else f"{old_content}\n{new_line}"
            enc_content = base64.b64encode(content.encode("utf-8")).decode("utf-8")
            
            url_put = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['skinauth_path_in_repo']}"
            headers_put = {
                "Authorization": f"token {token}",
                "Content-Type": "application/json"
            }
            payload = {
                "branch": GITEE_CONFIG['branch'],
                "content": enc_content,
                "message": f"Add auth: {qq} {dt}",
                "sha": sha
            }
            
            # 尝试 Python PUT
            put_success = False
            try:
                req = Request(url_put, data=json.dumps(payload).encode('utf-8'), headers=headers_put, method='PUT')
                ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
                resp = urlopen(req, timeout=TIMEOUT, context=ctx)
                
                if resp.status in [200, 201]:
                    success = True
                    put_success = True
                else:
                    raise Exception(f"Status {resp.status}")
            except Exception as e:
                log(f"Python PUT skinauth failed, trying CURL: {e}", xbmc.LOGWARNING)
                
            if not put_success:
                curl_cmd = [
                    "curl", "-s", "-L", "-X", "PUT",
                    "-H", f"Authorization: token {token}",
                    "-H", "Content-Type: application/json",
                    "-d", json.dumps(payload),
                    url_put
                ]
                
                try:
                    result = subprocess.run(curl_cmd, capture_output=True, text=True, timeout=TIMEOUT+10)
                    if result.returncode == 0:
                        if "error" not in result.stdout.lower():
                             success = True
                        else:
                             log(f"CURL PUT returned error info: {result.stdout}", xbmc.LOGERROR)
                    else:
                         log(f"CURL PUT failed with code {result.returncode}: {result.stderr}", xbmc.LOGERROR)
                except Exception as e:
                     log(f"CURL PUT execution exception: {e}", xbmc.LOGERROR)

            if success:
                break
            else:
                if i < RETRY_TIMES: time.sleep(WRITE_RETRY_INTERVAL)
                
        except Exception as e:
            log(f"Write skinauth loop failed ({i}): {e}", xbmc.LOGERROR)
            if i < RETRY_TIMES: time.sleep(WRITE_RETRY_INTERVAL)
            
    if not success: log("Write skinauth failed after retries", xbmc.LOGWARNING)
    return success

def download_authsort():
    url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['authsort_path_in_repo']}?ref={GITEE_CONFIG['branch']}"
    content = ""
    sha = None
    success = False
    token = get_access_credential()
    
    for i in range(1, RETRY_TIMES + 1):
        try:
            headers = {"Authorization": f"token {token}", "Accept": "application/json"}
            resp = http_request(url, headers=headers, timeout=TIMEOUT)
            
            if resp.status == 404:
                success = True
                break
                
            f_data = json.loads(resp.read().decode('utf-8'))
            sha = f_data.get("sha")
            content = base64.b64decode(f_data.get("content", "").replace("\n", "")).decode("utf-8")
            success = True
            break
        except Exception as e:
            log(f"Download authsort Python failed ({i}), switching to CURL: {e}", xbmc.LOGWARNING)
            # 立即尝试 Curl 备份
            curl_success, curl_content, curl_sha = download_text_file_via_curl(GITEE_CONFIG['authsort_path_in_repo'], token)
            if curl_success:
                content = curl_content
                sha = curl_sha
                success = True
                break
            else:
                if i < RETRY_TIMES: 
                    log("CURL backup also failed, waiting...", xbmc.LOGERROR)
                    time.sleep(AUTH_SORT_RETRY_INTERVAL)
            
    if not success: log("Download authsort failed after all attempts", xbmc.LOGWARNING)
    return success, content, sha

def parse_authsort(content):
    lines = []
    if not content.strip(): return lines
    pattern = re.compile(r'^(\d+)\s+(\d{6})\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+(.*)$')
    
    for idx, line in enumerate(content.strip().split("\n"), 1):
        line = line.strip()
        if not line: continue
        m = pattern.match(line)
        if not m: continue
        
        qq, dt, tm, did = m.group(1), m.group(2), m.group(3), m.group(4).strip()
        if not qq.isdigit() or not validate_date(dt): continue
        
        lines.append({"qq": qq, "date": dt, "time": tm, "device_id": did})
    return lines

def dedup_by_device(lines):
    d_map = {}
    for l in lines:
        did = l["device_id"]
        try: t_obj = datetime.datetime.strptime(l["time"], "%Y-%m-%d %H:%M:%S")
        except: continue
        
        if did not in d_map or t_obj > d_map[did]["t_obj"]:
            d_map[did] = {"line": l, "t_obj": t_obj}
    return [v["line"] for v in d_map.values()]

def sort_by_qq(lines):
    return sorted(lines, key=lambda x: int(x["qq"]))

def find_qq_lines(lines, qq):
    qq_lines, other = [], []
    found = False
    for l in lines:
        if l["qq"] == qq:
            qq_lines.append(l)
            found = True
        else:
            other.append(l)
    return found, qq_lines, other

def write_gitee_authsort(content, sha=None):
    success = False
    token = get_access_credential()
    for i in range(1, RETRY_TIMES + 1):
        try:
            url = f"https://gitee.com/api/v5/repos/{GITEE_CONFIG['owner']}/{GITEE_CONFIG['repo']}/contents/{GITEE_CONFIG['authsort_path_in_repo']}"
            headers = {
                "Authorization": f"token {token}",
                "Content-Type": "application/json"
            }
            payload = {
                "branch": GITEE_CONFIG['branch'],
                "content": base64.b64encode(content.encode("utf-8")).decode("utf-8"),
                "message": f"Update authsort - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "sha": sha
            }
            
            put_success = False
            try:
                req = Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers, method='PUT')
                ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
                resp = urlopen(req, timeout=TIMEOUT, context=ctx)
                
                if resp.status in [200, 201]:
                    success = True
                    put_success = True
                else:
                    raise Exception(f"Status {resp.status}")
            except Exception as e:
                log(f"Python PUT authsort failed ({i}), switching to CURL: {e}", xbmc.LOGWARNING)
                
            if not put_success:
                curl_cmd = [
                    "curl", "-s", "-L", "-X", "PUT",
                    "-H", f"Authorization: token {token}",
                    "-H", "Content-Type: application/json",
                    "-d", json.dumps(payload),
                    url
                ]
                
                try:
                    result = subprocess.run(curl_cmd, capture_output=True, text=True, timeout=TIMEOUT+10)
                    if result.returncode == 0 and "error" not in result.stdout.lower():
                         success = True
                    else:
                         log(f"CURL PUT authsort failed: {result.stderr or result.stdout}", xbmc.LOGERROR)
                except Exception as e:
                     log(f"CURL PUT authsort exception: {e}", xbmc.LOGERROR)

            if success:
                break
            else:
                if i < RETRY_TIMES: time.sleep(WRITE_RETRY_INTERVAL)
                
        except Exception as e:
            log(f"Write authsort loop failed ({i}): {e}", xbmc.LOGERROR)
            if i < RETRY_TIMES: time.sleep(WRITE_RETRY_INTERVAL)
            
    if not success: log("Write authsort failed after all attempts", xbmc.LOGWARNING)
    return success

def handle_limit(qq, qq_lines, other_lines, sha, new_line=None, is_insert=False):
    dialog = xbmcgui.Dialog()
    curr_dev = get_device_id()
    interrupt = False
    
    while len(qq_lines) > MAX_DEVICE_COUNT:
        options = []
        line_map = {}
        for idx, l in enumerate(qq_lines):
            prefix = "[COLOR green]（本机）[/COLOR] " if l["device_id"] == curr_dev else ""
            options.append(f"{prefix}{l['time']} | {l['device_id']}")
            line_map[idx] = l
        
        sel = dialog.select("授权设备超限（最多3台），请选择要删除的设备", options)
        if sel == -1:
            interrupt = True
            break
        
        selected = line_map[sel]
        if selected["device_id"] == curr_dev:
            if dialog.yesno("确认删除", "您选择的是删除本机授权，是否确认？"):
                qq_lines = [l for l in qq_lines if l["device_id"] != curr_dev]
                clear_auth()
                dialog.ok("操作完成", "本机授权已删除，皮肤功能将受限！")
                interrupt = True
                break
            else: continue
        else:
            qq_lines = [l for l in qq_lines if l["device_id"] != selected["device_id"]]
    
    all_lines = other_lines + qq_lines
    if interrupt and new_line and is_insert:
        all_lines = [l for l in all_lines if not (l["device_id"] == new_line["device_id"] and l["time"] == new_line["time"])]
        
    all_lines = sort_by_qq(all_lines)
    content = "\n".join([f"{l['qq']} {l['date']} {l['time']} {l['device_id']}" for l in all_lines])
    write_gitee_authsort(content, sha)
    
    if interrupt:
        clear_auth()
        dialog.ok("授权中断", "您的授权操作已中断，皮肤功能将受限！")
        return False, True
        
    return write_gitee_authsort(content, sha), False

def process_authsort(qq, dt, is_direct=False):
    # 优化点1：authsort 下载失败不再导致授权失效，而是记录日志并跳过设备列表检查
    success, content, sha = download_authsort()
    if not success:
        log("Authsort download failed. Skipping device limit check. Authorization will proceed based on local DB validation.", xbmc.LOGWARNING)
        # 返回 (True, False) 表示：处理成功(指不阻断流程)，无中断
        return True, False
    
    parsed = parse_authsort(content)
    found, qq_lines, other = find_qq_lines(parsed, qq)
    qq_lines = dedup_by_device(qq_lines)
    
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    dev_id = get_device_id()
    new_line = {"qq": qq, "date": dt, "time": now, "device_id": dev_id}
    
    need_write = False
    is_insert = False
    
    if found:
        device_match = any(l["device_id"] == dev_id for l in qq_lines)
        if not device_match:
            qq_lines.append(new_line)
            is_insert = True
            need_write = True
        
        if need_write or len(qq_lines) > MAX_DEVICE_COUNT:
            qq_lines = dedup_by_device(qq_lines)
            ws, interrupt = handle_limit(qq, qq_lines, other, sha, new_line, is_insert)
            if interrupt: return ws, True
        else:
            ws = True
    else:
        qq_lines.append(new_line)
        all_lines = sort_by_qq(other + qq_lines)
        content = "\n".join([f"{l['qq']} {l['date']} {l['time']} {l['device_id']}" for l in all_lines])
        ws = write_gitee_authsort(content, sha)
        
    if not is_direct:
        xbmcgui.Dialog().ok("验证成功", "已找到您的购买记录，您的皮肤使用授权长期有效，感谢您的支持！祝您使用CoreELEC系统愉快！")
    return True, False

def input_qq():
    qq = xbmcgui.Dialog().input("输入联系方式(QQ号)", type=xbmcgui.INPUT_NUMERIC)
    return qq if qq and qq.isdigit() else ""

def input_date():
    while True:
        dt = xbmcgui.Dialog().input("请输入购买时间6位数字", type=xbmcgui.INPUT_NUMERIC)
        if not dt: return ""
        if dt.isdigit() and len(dt) == 6: return dt
        xbmcgui.Dialog().ok("格式错误", "您输入的格式有误，请输入6位数字，例如：2025年9月1日，请输入“250901”")

def verify(qq, dt=None, show_dialog=True):
    qq_b64 = base64.b64encode(qq.encode("utf-8")).decode("utf-8")
    c3_vals = query_db(qq_b64)
    
    if not c3_vals:
        xbmcgui.Dialog().ok("验证失败", "未找到您的购买记录！请重新输入！")
        return False, "", "", False
        
    if dt is None or not validate_date(dt):
        dt = input_date()
        if not dt: return False, "", "", False
        
    dt_b64 = base64.b64encode(dt.encode("utf-8")).decode("utf-8")
    
    for c3 in c3_vals:
        if dt_b64 == c3:
            set_auth_strings(qq, dt)
            ws, interrupt = process_authsort(qq, dt, is_direct=False)
            return (not interrupt), qq, dt, interrupt
            
    if download_db():
        c3_new = query_db(qq_b64)
        for c3 in c3_new:
            if dt_b64 == c3:
                set_auth_strings(qq, dt)
                ws, interrupt = process_authsort(qq, dt, is_direct=False)
                return (not interrupt), qq, dt, interrupt
                
    xbmcgui.Dialog().ok("验证失败", "未找到您的购买记录，请核实您购买皮肤时的QQ号和时间！")
    return False, "", "", False

def set_auth_strings(qq, dt):
    xbmc.executebuiltin(f'Skin.SetString(skinauth,{qq})')
    xbmc.executebuiltin(f'Skin.SetString(skinauthhide,{hide_qq(qq)})')
    xbmc.executebuiltin(f'Skin.SetString(authdate,{dt})')
    xbmc.executebuiltin(f'Skin.SetString(authfail,0)')
    write_idkey(qq, dt)

def clear_auth():
    xbmc.executebuiltin('Skin.SetString(skinauth,"")')
    xbmc.executebuiltin('Skin.SetString(authdate,"")')
    xbmc.executebuiltin('Skin.SetString(skinauthhide,"")')
    xbmc.executebuiltin('Skin.SetString(authfail,1)')
    p = get_idkey_path()
    if os.path.exists(p):
        os.remove(p)

def main_flow():
    download_db()
    if not os.path.exists(get_db_path()):
        xbmcgui.Dialog().ok("数据库错误", "本地无数据库文件且下载失败，无法进行授权验证！")
        clear_auth()
        return
        
    qq, dt = get_auth_credentials()
    auth_ok = False
    interrupt = False
    
    for _ in range(3):
        if interrupt: break
        if not qq or not qq.isdigit():
            qq_in = input_qq()
            if not qq_in: continue
            ok, q, d, int_flag = verify(qq_in)
            if ok:
                # 优化点2：skinauth 写入失败不影响主流程，忽略其返回值
                write_gitee_skinauth(q, d)
                auth_ok = True
                break
            else:
                qq = ""
                if int_flag: interrupt = True
        else:
            qq_b64 = base64.b64encode(qq.encode("utf-8")).decode("utf-8")
            c3_vals = query_db(qq_b64)
            if not c3_vals:
                xbmcgui.Dialog().ok("验证失败", "未找到您的购买记录！请重新输入！")
                qq = ""
                continue
                
            if dt and validate_date(dt):
                dt_b64 = base64.b64encode(dt.encode("utf-8")).decode("utf-8")
                match = any(c3 == dt_b64 for c3 in c3_vals)
                
                if not match and download_db():
                    c3_new = query_db(qq_b64)
                    match = any(c3 == dt_b64 for c3 in c3_new)
                    
                if match:
                    set_auth_strings(qq, dt)
                    ws, int_flag = process_authsort(qq, dt, is_direct=True)
                    if not int_flag:
                        auth_ok = True
                        break
                    else:
                        interrupt = True
                        break
                else:
                    xbmcgui.Dialog().ok("验证失败", "未找到您的购买记录，请核实您购买皮肤时的QQ号和时间！")
                    qq = ""
                    dt = ""
            else:
                dt_in = input_date()
                if not dt_in: continue
                ok, q, d, int_flag = verify(qq, dt_in)
                if ok:
                    # 优化点2：skinauth 写入失败不影响主流程
                    write_gitee_skinauth(q, d)
                    auth_ok = True
                    break
                else:
                    qq = ""
                    if int_flag: interrupt = True
                    
    if not auth_ok or interrupt:
        xbmcgui.Dialog().ok("授权无效", "您的皮肤使用授权无效，皮肤功能将受到限制，请核实您的授权来源！")
        clear_auth()

def manual_flow():
    download_db()
    if not os.path.exists(get_db_path()):
        xbmcgui.Dialog().ok("数据库错误", "本地无数据库文件且下载失败，无法进行手动授权验证！")
        clear_auth()
        return
        
    auth_ok = False
    interrupt = False
    
    for _ in range(3):
        if interrupt: break
        qq = input_qq()
        if not qq: continue
        
        qq_b64 = base64.b64encode(qq.encode("utf-8")).decode("utf-8")
        c3_vals = query_db(qq_b64)
        if not c3_vals:
            xbmcgui.Dialog().ok("验证失败", "未找到您的购买记录！请重新输入！")
            continue
            
        dt = ""
        while True:
            dt = xbmcgui.Dialog().input("请输入购买时间6位数字", type=xbmcgui.INPUT_NUMERIC)
            if not dt: break
            if dt.isdigit() and len(dt) == 6: break
            xbmcgui.Dialog().ok("格式错误", "您输入的格式有误，请输入6位数字，例如：2025年9月1日，请输入“250901”")
        if not dt: continue
        
        dt_b64 = base64.b64encode(dt.encode("utf-8")).decode("utf-8")
        match = any(c3 == dt_b64 for c3 in c3_vals)
        
        if not match and download_db():
            c3_new = query_db(qq_b64)
            match = any(c3 == dt_b64 for c3 in c3_new)
            
        if match:
            set_auth_strings(qq, dt)
            ws, int_flag = process_authsort(qq, dt, is_direct=False)
            if not int_flag:
                # 优化点2：skinauth 写入失败不影响主流程
                write_gitee_skinauth(qq, dt)
                auth_ok = True
                break
            else:
                interrupt = True
                break
                
    if not auth_ok or interrupt:
        xbmcgui.Dialog().ok("授权无效", "您的皮肤使用授权无效，皮肤功能将受到限制，请核实您的授权来源！")
        clear_auth()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1].lower() == "manual":
        manual_flow()
    else:
        main_flow()
    xbmc.executebuiltin("RunScript(special://skin/scripts/skinlogo.py)") 