# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import time
import zipfile
import logging
import shutil

# 配置日志记录器
logger = logging.getLogger("backupkey_script")
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# 全程使用 Python 原生物理路径
physical_userdata_dir = xbmcvfs.translatePath('special://userdata/')
physical_keymaps_dir = os.path.join(physical_userdata_dir, 'keymaps')
physical_backup_dir = os.path.join(physical_keymaps_dir, 'backup')

logger.info("脚本初始化完成")
logger.debug("物理 keymaps 路径: %s", physical_keymaps_dir)

def get_dialog():
    """获取 Kodi 的对话框实例"""
    return xbmcgui.Dialog()

def ensure_dir_exists(directory):
    """使用 Python 原生 os 模块确保文件夹存在"""
    if not os.path.exists(directory):
        logger.info("检测到文件夹不存在，正在创建: %s", directory)
        os.makedirs(directory)

def get_xml_files_in_keymaps():
    """使用 Python 原生 os 模块获取 .xml 文件"""
    if not os.path.exists(physical_keymaps_dir):
        logger.warning("物理路径文件夹不存在: %s", physical_keymaps_dir)
        return []
    
    try:
        all_files = os.listdir(physical_keymaps_dir)
        xml_files = [f for f in all_files if f.lower().endswith('.xml')]
        logger.debug("在 keymaps 文件夹中找到以下 xml 文件: %s", xml_files)
        return xml_files
    except Exception as e:
        logger.error("读取文件夹失败: %s", str(e))
        return []

def extract_timestamp_from_filename(filename):
    """从备份文件名中提取时间戳部分，支持新旧两种格式"""
    name_without_ext = filename[:-4]  # 移除 .zip 后缀
    
    # 新格式：遥控器备份_YYYYMMDD_HHMMSS.zip
    if name_without_ext.startswith("遥控器备份_"):
        return name_without_ext[5:]  # 移除 "遥控器备份_" 前缀
    
    # 旧格式：YYYYMMDD_HHMMSS.zip (保持兼容性)
    return name_without_ext

def get_backup_files():
    """获取备份文件夹中的所有备份文件，按时间排序"""
    if not os.path.exists(physical_backup_dir):
        logger.warning("物理路径文件夹不存在: %s", physical_backup_dir)
        return []
    
    try:
        all_files = os.listdir(physical_backup_dir)
        backup_zips = [f for f in all_files if f.lower().endswith('.zip')]
        # 按时间戳排序
        backup_zips.sort(key=lambda x: extract_timestamp_from_filename(x), reverse=True)
        logger.debug("在备份文件夹中找到以下备份文件: %s", backup_zips)
        return backup_zips
    except Exception as e:
        logger.error("读取备份文件夹失败: %s", str(e))
        return []

def backup_config():
    """第一个选项：备份当前遥控器配置文件（打包成 zip）"""
    logger.info("开始执行打包备份操作...")
    dialog = get_dialog()
    
    xml_files = get_xml_files_in_keymaps()
    if not xml_files:
        logger.warning("备份失败：keymaps 文件夹不存在或没有 .xml 文件")
        dialog.ok("备份失败", "遥控器配置文件不存在")
        return

    ensure_dir_exists(physical_backup_dir)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    zip_filename = "遥控器备份_{}.zip".format(timestamp)
    physical_zip_path = os.path.join(physical_backup_dir, zip_filename)
    
    logger.debug("生成备份压缩包文件名: %s", zip_filename)

    try:
        with zipfile.ZipFile(physical_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for xml_file in xml_files:
                physical_source_file = os.path.join(physical_keymaps_dir, xml_file)
                zipf.write(physical_source_file, arcname=xml_file)
                logger.info("已将文件打包进 zip: %s", xml_file)
        
        logger.info("打包备份成功！")
        dialog.ok("备份成功", "已完成当前遥控器配置文件备份！")
    except Exception as e:
        logger.error("打包备份失败: %s", str(e))
        dialog.ok("备份失败", "文件压缩过程中发生错误！")

def restore_config():
    """第二个选项：恢复遥控器配置文件（解压 zip）"""
    logger.info("开始执行恢复操作...")
    dialog = get_dialog()

    if not os.path.exists(physical_backup_dir):
        logger.error("恢复失败：备份文件夹不存在 -> %s", physical_backup_dir)
        dialog.ok("恢复失败", "未发现遥控器配置文件备份！")
        return
    
    backup_zips = get_backup_files()
    
    if not backup_zips:
        logger.warning("恢复失败：备份文件夹为空或没有 .zip 文件")
        dialog.ok("恢复失败", "未发现遥控器配置文件备份！")
        return

    selection_list = []
    for f in backup_zips:
        timestamp_part = extract_timestamp_from_filename(f)
        selection_list.append("{}备份".format(timestamp_part))

    logger.info("弹出恢复文件选择窗口，共找到 %d 个压缩包", len(backup_zips))
    index = dialog.select("请选择要恢复的备份文件", selection_list)
    
    if index != -1:
        selected_zip = backup_zips[index]
        physical_zip_path = os.path.join(physical_backup_dir, selected_zip)
        timestamp_part = extract_timestamp_from_filename(selected_zip)
        logger.info("用户选择了恢复压缩包: %s", selected_zip)

        try:
            # 1. 首先将 keymaps 文件夹下的所有 .xml 文件都删除
            logger.info("正在清空 keymaps 文件夹下的所有 .xml 文件...")
            current_xmls = get_xml_files_in_keymaps()
            for xml in current_xmls:
                physical_xml_path = os.path.join(physical_keymaps_dir, xml)
                os.remove(physical_xml_path)
                logger.info("已删除旧配置文件: %s", physical_xml_path)

            # 2. 将所选的 zip 文件解压缩至 keymaps 文件夹
            logger.info("正在解压备份文件到物理路径: %s", physical_keymaps_dir)
            with zipfile.ZipFile(physical_zip_path, 'r') as zipf:
                zipf.extractall(physical_keymaps_dir)
                extracted_files = zipf.namelist()
                logger.info("解压完成，释放的文件: %s", extracted_files)

            # 【核心优化】恢复成功后，执行 reloadkeymaps 指令强制 Kodi 重新加载按键映射
            logger.info("恢复文件完成，正在执行 reloadkeymaps 指令...")
            xbmc.executebuiltin('reloadkeymaps')
            
            logger.info("恢复成功并已重载按键映射！")
            dialog.ok("恢复成功", "已恢复“{}备份”遥控器配置文件备份！\n按键映射已自动重载生效。".format(timestamp_part))
        except Exception as e:
            logger.error("恢复失败: %s", str(e))
            dialog.ok("恢复失败", "文件解压或替换过程中发生错误！")

def delete_config():
    """第三个选项：删除遥控器配置备份文件"""
    logger.info("开始执行删除操作...")
    dialog = get_dialog()

    if not os.path.exists(physical_backup_dir):
        logger.error("删除失败：备份文件夹不存在 -> %s", physical_backup_dir)
        dialog.ok("删除失败", "未发现遥控器配置文件备份！")
        return

    backup_zips = get_backup_files()
    
    if not backup_zips:
        logger.warning("删除失败：备份文件夹为空或没有 .zip 文件")
        dialog.ok("删除失败", "未发现遥控器配置文件备份！")
        return

    delete_all_label = "[COLOR red]删除所有遥控器配置备份文件[/COLOR]"
    selection_list = [delete_all_label]
    
    for f in backup_zips:
        timestamp_part = extract_timestamp_from_filename(f)
        selection_list.append("{}备份".format(timestamp_part))

    logger.info("弹出删除文件选择窗口")
    index = dialog.select("请选择要删除的备份", selection_list)

    if index == 0:
        logger.info("用户选择了【删除所有备份压缩包】")
        confirm = dialog.yesno("确认删除", "该操作将删除所有之前的遥控器配置备份文件！\n选择“是”确认删除，选择“否”关闭窗口。")
        if confirm:
            logger.warning("用户确认删除所有备份压缩包！")
            success = True
            for f in backup_zips:
                file_path = os.path.join(physical_backup_dir, f)
                logger.info("正在删除压缩包: %s", file_path)
                try:
                    os.remove(file_path)
                except Exception as e:
                    logger.error("删除压缩包失败: %s", str(e))
                    success = False
            if success:
                logger.info("所有备份压缩包删除成功！")
                dialog.ok("删除成功", "已删除全部遥控器配置备份文件！")
                xbmc.executebuiltin("RunScript(special://skin/scripts/backupkey.py)")
            else:
                dialog.ok("删除失败", "部分文件删除失败！")
    
    elif index > 0:
        selected_zip = backup_zips[index - 1]
        file_path = os.path.join(physical_backup_dir, selected_zip)
        timestamp_part = extract_timestamp_from_filename(selected_zip)
        logger.info("用户选择了删除单个压缩包: %s", selected_zip)

        try:
            os.remove(file_path)
            logger.info("删除单个压缩包成功: %s", selected_zip)
            dialog.ok("删除成功", "已删除“{}备份”遥控器配置备份文件！".format(timestamp_part))
            xbmc.executebuiltin("RunScript(special://skin/scripts/backupkey.py)")
        except Exception as e:
            logger.error("删除单个压缩包失败: %s", str(e))
            dialog.ok("删除失败", "文件删除过程中发生错误！")

def export_import_config():
    """第四个选项：导入/导出遥控器配置备份文件"""
    logger.info("开始执行导入/导出操作...")
    dialog = get_dialog()

    # 检查备份文件夹是否存在且非空
    if not os.path.exists(physical_backup_dir):
        logger.warning("导入/导出失败：备份文件夹不存在")
        dialog.ok("导入/导出失败", "您还未进行遥控器配置文件备份！")
        return

    backup_zips = get_backup_files()

    if not backup_zips:
        logger.warning("导入/导出失败：备份文件夹为空")
        dialog.ok("导入/导出失败", "您还未进行遥控器配置文件备份！")
        return

    # 弹出选择窗口
    options = ["导出遥控器配置文件备份", "导入遥控器配置文件备份"]
    logger.info("弹出导入/导出选择窗口")
    index = dialog.select("导入/导出遥控器配置文件备份", options)

    if index == 0:
        # 导出遥控器配置文件备份
        default_export_path = "/storage/backup"
        if os.name == "nt":  # Windows系统
            default_export_path = "C:\\backup"
        
        # 弹出路径选择窗口
        export_path = dialog.browseSingle(3, "请选择导出路径", "", defaultt=default_export_path)
        if not export_path:
            logger.info("用户取消了导出路径选择")
            return
        
        logger.info("用户选择了导出路径: %s", export_path)
        
        # 创建导出路径（如果不存在）
        ensure_dir_exists(export_path)
        
        # 复制所有备份文件到导出路径
        success = True
        for zip_file in backup_zips:
            source_path = os.path.join(physical_backup_dir, zip_file)
            dest_path = os.path.join(export_path, zip_file)
            try:
                shutil.copy2(source_path, dest_path)
                logger.info("已复制备份文件: %s 到 %s", source_path, dest_path)
            except Exception as e:
                logger.error("复制备份文件失败: %s", str(e))
                success = False
        
        if success:
            logger.info("导出成功")
            dialog.ok("导出成功", "已导出全部遥控器配置备份文件！")
            xbmc.executebuiltin("RunScript(special://skin/scripts/backupkey.py)")
        else:
            dialog.ok("导出失败", "部分文件导出失败！")
    
    elif index == 1:
        # 导入遥控器配置文件备份
        default_import_path = "/storage/backup/"
        if os.name == "nt":  # Windows系统
            default_import_path = "C:\\backup"
        
        # 弹出ZIP文件选择窗口
        zip_file_path = dialog.browseSingle(1, "请选择要导入的ZIP备份文件", "files", ".zip", defaultt=default_import_path)
        if not zip_file_path:
            logger.info("用户取消了ZIP文件选择")
            return
        
        logger.info("用户选择了ZIP文件: %s", zip_file_path)
        
        # 获取文件名
        zip_filename = os.path.basename(zip_file_path)
        
        # 检查是否已经是"遥控器备份"格式，如果不是则重命名
        if not zip_filename.startswith("遥控器备份_") and zip_filename.endswith(".zip"):
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            zip_filename = "遥控器备份_{}_{}".format(timestamp, zip_filename)
        
        dest_path = os.path.join(physical_backup_dir, zip_filename)
        
        # 检查目标文件是否已存在
        if os.path.exists(dest_path):
            confirm = dialog.yesno("文件已存在", "目标文件已存在，是否覆盖？")
            if not confirm:
                logger.info("用户取消了覆盖操作")
                return
        
        # 复制文件到备份目录
        try:
            shutil.copy2(zip_file_path, dest_path)
            logger.info("已复制备份文件: %s 到 %s", zip_file_path, dest_path)
            dialog.ok("导入成功", "已导入选择的遥控器配置备份文件，如需恢复该备份，请再执行恢复遥控器配置文件操作！")
            xbmc.executebuiltin("RunScript(special://skin/scripts/backupkey.py)")
        except Exception as e:
            logger.error("导入备份文件失败: %s", str(e))
            dialog.ok("导入失败", "文件导入过程中发生错误！")

# 脚本主入口
def main():
    logger.info("========== 脚本启动 ==========")
    dialog = get_dialog()
    options = ["备份当前遥控器配置文件", "恢复遥控器配置文件", "删除遥控器配置备份文件", "导入/导出遥控器配置备份文件"]
    logger.info("弹出主菜单选择窗口")
    index = dialog.select("遥控器配置文件管理", options)

    if index == 0:
        backup_config()
    elif index == 1:
        restore_config()
    elif index == 2:
        delete_config()
    elif index == 3:
        export_import_config()
    else:
        logger.info("用户取消了选择，脚本退出")
    
    logger.info("========== 脚本结束 ==========")

if __name__ == '__main__':
    main()