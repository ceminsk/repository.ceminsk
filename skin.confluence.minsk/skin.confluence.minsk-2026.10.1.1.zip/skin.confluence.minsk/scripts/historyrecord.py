# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import json
import os
import sqlite3
import time
import re
import sys

def log(msg, level=xbmc.LOGDEBUG):
    """输出日志到 Kodi 日志文件"""
    xbmc.log(f"[HistoryRecordScript] {msg}", level)

def get_json_path():
    """获取 lastPlayed.json 的完整路径"""
    return xbmcvfs.translatePath('special://profile/addon_data/skin.confluence.minsk/lastPlayed.json')

def is_no_core():
    """
    检测当前系统是否为 No / LibreELEC 核心。
    方法：检查 /etc/os-release 文件内容是否包含 'no' 或 'libreelec'（均不区分大小写）。
    """
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def get_db_path():
    """获取视频数据库文件的完整路径（No/LibreELEC核心取最新 MyVideos14*.db，普通核心取最新 MyVideos13*.db）"""
    db_dir = xbmcvfs.translatePath('special://userdata/Database/')
    prefix = 'MyVideos14' if is_no_core() else 'MyVideos13'

    log(f"Searching for latest {prefix}*.db ...")
    try:
        files_with_time = []
        # 列出目录内容
        dirs, file_list = xbmcvfs.listdir(db_dir)

        for f in file_list:
            if f.startswith(prefix) and f.endswith('.db'):
                full_path = os.path.join(db_dir, f)
                try:
                    # 使用 os.path.getmtime 获取修改时间戳 (float)
                    mtime = os.path.getmtime(full_path)
                    files_with_time.append((full_path, mtime))
                except Exception as e:
                    log(f"Could not get mtime for {f}: {e}", xbmc.LOGDEBUG)
                    continue

        if files_with_time:
            # 按修改时间降序排序 (最新的在前)
            # key=lambda x: x[1] 确保比较的是浮点数时间戳
            files_with_time.sort(key=lambda x: x[1], reverse=True)
            latest_db = files_with_time[0][0]
            log(f"Selected latest DB: {latest_db}")
            return latest_db
        else:
            log(f"No {prefix}*.db found in database directory.", xbmc.LOGWARNING)
    except Exception as e:
        log(f"Error listing DB directory: {str(e)}", xbmc.LOGERROR)

    # Default behavior (Standard Core or fallback)
    default_db_name = "MyVideos131.db"
    default_path = os.path.join(db_dir, default_db_name)
    log(f"Using default DB path: {default_path}")
    return default_path


def load_json():
    """加载 JSON 文件，如果不存在则创建并返回空列表"""
    json_path = get_json_path()
    json_dir = os.path.dirname(json_path)
    
    if not xbmcvfs.exists(json_dir):
        xbmcvfs.mkdirs(json_dir)
        
    if xbmcvfs.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log(f"Error loading JSON: {e}", xbmc.LOGERROR)
    return []

def save_json(data):
    """保存数据到 JSON 文件"""
    json_path = get_json_path()
    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        log("JSON file saved successfully.")
    except Exception as e:
        log(f"Error saving JSON: {e}", xbmc.LOGERROR)

def clean_old_records(data, limit):
    """
    清理旧记录：根据 date 和 time 排序，删除最早的条目，直到数量小于 limit
    """
    if len(data) <= limit:
        return data

    # 定义排序键：组合 date 和 time 以便比较
    def get_sort_key(item):
        d = item.get('date', '')
        t = item.get('time', '')
        return f"{d} {t}"

    # 按时间降序排序（最新的在前面）
    data.sort(key=get_sort_key, reverse=True)
    
    # 逐条删除最早的条目，直到数量小于 limit
    while len(data) > limit:
        removed_item = data.pop()
        log(f"Removed old record: {removed_item.get('title')}")
        
    return data

def get_file_id_from_db(filename):
    """
    从数据库 files 表中根据文件名获取 idFile。
    如果有多个匹配项，选取 lastPlayed 最新的一行。
    """
    db_path = get_db_path()
    if not xbmcvfs.exists(db_path):
        log("Database file does not exist.", xbmc.LOGWARNING)
        return None

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        query = "SELECT idFile, lastPlayed FROM files WHERE strFilename = ?"
        cursor.execute(query, (filename,))
        rows = cursor.fetchall()
        
        if not rows:
            return None
            
        if len(rows) == 1:
            return rows[0][0]
        else:
            # 选取 lastPlayed 最靠后的那一行
            latest_time = ""
            target_idFile = None
            for row in rows:
                last_played = row[1] if row[1] else ""
                if last_played > latest_time:
                    latest_time = last_played
                    target_idFile = row[0]
            return target_idFile

    except Exception as e:
        log(f"Database Error in get_file_id: {e}", xbmc.LOGERROR)
    finally:
        if conn:
            conn.close()
    return None

def remove_title_prefix(title):
    """
    移除标题开头的所有 [COLOR ...]...[/COLOR] 标签前缀。
    使用循环替换，直到标题不再以 [COLOR 开头，确保清除所有连续的颜色标签。
    """
    if not title:
        return ""
        
    # 正则解释：
    # ^           : 匹配字符串开头
    # \[COLOR     : 匹配字面量 [COLOR
    # [^\]]*      : 匹配任意非 ] 字符 (即颜色属性，如 yellow, white, 0xFF0000 等)
    # \]          : 匹配字面量 ]
    # .*?         : 非贪婪匹配中间的内容
    # \[/COLOR\]  : 匹配字面量 [/COLOR]
    # \s*         : 匹配标签后可能存在的空白字符
    pattern = r'^\[COLOR[^\]]*\].*?\[/COLOR\]\s*'
    
    cleaned_title = title
    # 循环执行替换，以防有多个连续的颜色标签块
    while re.match(r'^\[COLOR', cleaned_title):
        cleaned_title = re.sub(pattern, '', cleaned_title)
        
    return cleaned_title.strip()

def handle_start():
    """处理带有 'start' 参数的逻辑"""
    log("Script started with 'start' parameter.")
    
    # 1. 读取/初始化 JSON
    data = load_json()
    
    # 2. 设置 historypath
    filename_and_path = xbmc.getInfoLabel('Player.Filenameandpath')
    if not filename_and_path:
        log("No file playing. Exiting.", xbmc.LOGWARNING)
        return
        
    xbmc.executebuiltin(f'Skin.SetString(historypath,{filename_and_path})')
    log(f"Set Skin.String(historypath) to: {filename_and_path}")

    # 3. 获取 historynum 并清理旧记录
    try:
        limit = int(xbmc.getInfoLabel('Skin.String(historynum)'))
    except (ValueError, TypeError):
        limit = 50
        
    log(f"History limit: {limit}, Current entries: {len(data)}")
    data = clean_old_records(data, limit)

    # 4. 第2步逻辑：判断内容类型并处理
    is_movie = xbmc.getCondVisibility('VideoPlayer.Content(Movies)')
    is_episode = xbmc.getCondVisibility('VideoPlayer.Content(Episodes)')
    
    filename = xbmc.getInfoLabel('Player.Filename')
    title = xbmc.getInfoLabel('Player.Title')
    current_date = time.strftime("%Y-%m-%d")
    current_time = time.strftime("%H:%M:%S")
    
    # 查找当前文件是否已存在于记录中
    target_index = -1
    for i, item in enumerate(data):
        if filename_and_path in item.get('file', ''):
            target_index = i
            break

    new_entry = None
    if target_index == -1:
        # 未找到，构建新条目
        if is_movie:
            new_entry = {
                "source": "电影库",
                "title": title,
                "file": filename_and_path,
                "video": filename_and_path,
                "id": int(xbmc.getInfoLabel('VideoPlayer.DBID') or 0),
                "type": "movie",
                "thumbnail": xbmc.getInfoLabel('Player.Art(poster)'),
                "fanart": xbmc.getInfoLabel('Player.Art(fanart)'),
                "show": " ",
                "season": 0,
                "episode": 0,
                "date": current_date,
                "time": current_time,
                "resume_time": " ",
                "total_time": " "
            }
        elif is_episode:
            tvshow_poster = xbmc.getInfoLabel('Player.Art(tvshow.poster)')
            poster = xbmc.getInfoLabel('Player.Art(poster)')
            new_entry = {
                "source": "剧集库",
                "title": title,
                "file": filename_and_path,
                "video": filename_and_path,
                "TvShowDBID": int(xbmc.getInfoLabel('VideoPlayer.TvShowDBID') or 0),
                "type": "episode",
                "thumbnail": tvshow_poster if tvshow_poster else poster,
                "icon": xbmc.getInfoLabel('Player.Icon'),
                "show": xbmc.getInfoLabel('VideoPlayer.TVShowTitle'),
                "season": int(xbmc.getInfoLabel('VideoPlayer.Season') or 0),
                "episode": int(xbmc.getInfoLabel('VideoPlayer.Episode') or 0),
                "date": current_date,
                "time": current_time,
                "resume_time": " ",
                "total_time": " "
            }
        else:
            # 情况3：普通文件，需要清洗标题
            cleaned_title = remove_title_prefix(title)
            new_entry = {
                "source": "文件",
                "title": cleaned_title,
                "file": filename_and_path,
                "video": filename_and_path,
                "id": 0,
                "type": "file",
                "thumbnail": xbmc.getInfoLabel('Player.Art(tvshow.poster)'),
                "fanart": xbmc.getInfoLabel('Player.Art(fanart)'),
                "show": xbmc.getInfoLabel('VideoPlayer.TVShowTitle'),
                "season": int(xbmc.getInfoLabel('VideoPlayer.Season') or 0),
                "episode": int(xbmc.getInfoLabel('VideoPlayer.Episode') or 0),
                "date": current_date,
                "time": current_time,
                "resume_time": " ",
                "total_time": " "
            }
        
        # 在开头添加新条目
        data.insert(0, new_entry)
        log(f"Added new record: {new_entry['title']}")
    else:
        # 找到了，更新已有条目的基础信息（保持时间最新）
        log(f"Updating existing record at index {target_index}")
        data[target_index]["date"] = current_date
        data[target_index]["time"] = current_time
        # 仅对非库内容（普通文件）进行标题清洗更新，库内容通常不需要清洗
        if not is_movie and not is_episode:
            data[target_index]["title"] = remove_title_prefix(title)
        else:
            data[target_index]["title"] = title

    # 保存 JSON
    save_json(data)

    # 5. 获取数据库 ID 并设置 historyid
    file_id = get_file_id_from_db(filename)
    if file_id:
        xbmc.executebuiltin(f'Skin.SetString(historyid,{file_id})')
        log(f"Set Skin.String(historyid) to: {file_id}")
    else:
        xbmc.executebuiltin('Skin.SetString(historyid,)')
        log("Could not find file ID in database. Cleared historyid.", xbmc.LOGWARNING)

    log("Script finished with 'start' parameter.")

def handle_exit():
    """处理带有 'exit' 参数的逻辑"""
    log("Script started with 'exit' parameter.")
    
    # 1. 立即获取 historypath
    history_path = xbmc.getInfoLabel('Skin.String(historypath)')
    if not history_path:
        log("Skin.String(historypath) is empty. Exiting.", xbmc.LOGWARNING)
        return

    # 2. 加载 JSON 并查找匹配条目
    data = load_json()
    target_index = -1
    for i, item in enumerate(data):
        if history_path in item.get('file', ''):
            target_index = i
            break
            
    if target_index == -1:
        log("No matching entry found in JSON for exit logic.", xbmc.LOGWARNING)
        return

    # 3. 延迟 2 秒 (2000毫秒)，等待 Kodi 写入数据库
    log("Waiting 2 seconds for database update...")
    xbmc.sleep(2000)

    # 4. 查询数据库获取最新播放的 idFile
    db_path = get_db_path()
    if not xbmcvfs.exists(db_path):
        log("Database file does not exist.", xbmc.LOGWARNING)
        return

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 在 files 表中找到 lastPlayed 时间最新的那一行
        query_files = "SELECT idFile FROM files WHERE lastPlayed IS NOT NULL AND lastPlayed != '' ORDER BY lastPlayed DESC LIMIT 1"
        cursor.execute(query_files)
        row_file = cursor.fetchone()
        
        if not row_file:
            log("No recent lastPlayed found in files table.", xbmc.LOGWARNING)
            return
            
        latest_idFile = row_file[0]
        log(f"Found latest idFile from files table: {latest_idFile}")

        # 5. 在 bookmark 表中查找对应的进度
        query_bookmark = "SELECT timeInSeconds, totalTimeInSeconds FROM bookmark WHERE idFile = ?"
        cursor.execute(query_bookmark, (latest_idFile,))
        row_bookmark = cursor.fetchone()
        
        # 6. 更新 JSON 数据
        if row_bookmark:
            time_in_seconds = row_bookmark[0] if row_bookmark[0] is not None else 0
            total_time_in_seconds = row_bookmark[1] if row_bookmark[1] is not None else 0
            
            data[target_index]["resume_time"] = str(time_in_seconds)
            data[target_index]["total_time"] = str(total_time_in_seconds)
            log(f"Updated progress - resume: {time_in_seconds}, total: {total_time_in_seconds}")
        else:
            # 如果没有 bookmark 记录，清空进度
            data[target_index]["resume_time"] = ""
            data[target_index]["total_time"] = ""
            log("No bookmark found. Cleared progress fields.")

        # 7. 保存更新后的 JSON
        save_json(data)
        
    except Exception as e:
        log(f"Database error in exit logic: {e}", xbmc.LOGERROR)
    finally:
        if conn:
            conn.close()

    log("Script finished with 'exit' parameter.")

def main():
    if len(sys.argv) < 2:
        log("Script called without arguments. Exiting.")
        return

    arg = sys.argv[1]
    if arg == 'start':
        handle_start()
    elif arg == 'exit':
        handle_exit()
    else:
        log(f"Unknown argument: {arg}. Exiting.")

if __name__ == '__main__':
    main()