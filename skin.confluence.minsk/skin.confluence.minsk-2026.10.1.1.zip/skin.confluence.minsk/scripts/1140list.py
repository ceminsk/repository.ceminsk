import xbmc
import xbmcgui
import re

class EpisodeNavigationMonitor:
    def __init__(self):
        self.window_id = 1140
        self.control_id = 6401
        
    def run(self):
        # Main loop - continuously monitor window visibility
        while True:
            # Check if window 1140 is visible
            if not xbmc.getCondVisibility(f"Window.IsVisible({self.window_id})"):
                break  # Exit script if window is not visible
                
            # Wait until control 6401 has focus
            if not xbmc.getCondVisibility(f"Control.HasFocus({self.control_id})"):
                xbmc.sleep(500)  # Wait half a second before checking again
                continue
            
            # Control has focus, now get VideoPlayer.Episode value
            video_episode_str = xbmc.getInfoLabel("VideoPlayer.Episode")
            
            try:
                video_episode = int(video_episode_str) if video_episode_str.isdigit() else 0
            except ValueError:
                video_episode = 0
            
            if video_episode >= 1:
                # ================= Case 1 =================
                # Case 1: Episode number is greater than or equal to 1
                xbmc.sleep(200)  # Delay 0.2 seconds
                target_position = video_episode - 1
                xbmc.executebuiltin(f"SetFocus({self.control_id},{target_position},absolute)")
                
                # Check if ListItem.Episode matches VideoPlayer.Episode
                while True:
                    list_item_episode_str = xbmc.getInfoLabel("ListItem.Episode")
                    
                    try:
                        list_item_episode = int(list_item_episode_str) if list_item_episode_str.isdigit() else 0
                    except ValueError:
                        list_item_episode = 0
                    
                    if list_item_episode == video_episode:
                        return  # Close script
                    
                    # Compare and navigate left/right based on episode numbers
                    if list_item_episode > video_episode:
                        xbmc.executebuiltin("Action(left)")
                    elif list_item_episode < video_episode:
                        xbmc.executebuiltin("Action(right)")
                    
                    xbmc.sleep(100)  # Brief pause before next check
            
            else:
                # ================= Case 2 =================
                # Case 2: Episode is empty or 0, use Player.Title instead
                player_title = xbmc.getInfoLabel("Player.Title")
                
                # Extract SaEb pattern and file extension from Player.Title
                saeb_match = re.search(r'S(\d+)E(\d+)', player_title)
                ext_match = re.search(r'\.([a-zA-Z0-9]+)$', player_title)
                
                if not saeb_match:
                    # If no SxE pattern found, exit the script
                    return
                
                # Extract season, episode numbers, and extension
                season_num = saeb_match.group(1)
                episode_num = int(saeb_match.group(2))
                target_ext = ext_match.group(1).lower() if ext_match else ""
                
                # Set focus to calculated position (b-1)
                target_position = episode_num - 1
                xbmc.executebuiltin(f"SetFocus({self.control_id},{target_position},absolute)")
                
                # Delay 1 second to ensure container is fully refreshed
                xbmc.sleep(1000)
                
                # Variable to store the navigation direction (determined only once)
                action_dir = None 
                
                # Continue comparing and navigating until match is found
                while True:
                    list_item_label = xbmc.getInfoLabel("ListItem.Label")
                    
                    # Extract ScEd pattern and extension from current ListItem.Label
                    sced_match = re.search(r'S(\d+)E(\d+)', list_item_label)
                    curr_ext_match = re.search(r'\.([a-zA-Z0-9]+)$', list_item_label)
                    
                    if sced_match:
                        list_season = sced_match.group(1)
                        list_episode = int(sced_match.group(2))
                        curr_ext = curr_ext_match.group(1).lower() if curr_ext_match else ""
                        
                        is_strm = (curr_ext == "strm")
                        
                        # Check if match based on Situation 2.1 or 2.2
                        is_match = False
                        if is_strm:
                            # Situation 2.1: Compare SxE only (extension must be strm)
                            if season_num == list_season and episode_num == list_episode:
                                is_match = True
                        else:
                            # Situation 2.2: Compare SxE AND extension
                            if season_num == list_season and episode_num == list_episode and target_ext == curr_ext:
                                is_match = True
                        
                        # If match found, close script
                        if is_match:
                            return  
                        
                        # Determine direction ONLY on the first iteration (compare b and d once)
                        if action_dir is None:
                            if episode_num < list_episode:
                                action_dir = "left"
                            else:
                                action_dir = "right"
                    
                    # Execute action based on the determined direction
                    if action_dir:
                        xbmc.executebuiltin(f"Action({action_dir})")
                    else:
                        # Fallback if current item has no valid SxE info, just move right
                        xbmc.executebuiltin("Action(right)")
                        
                    xbmc.sleep(100)  # Brief pause before next check


# Run the script
if __name__ == "__main__":
    monitor = EpisodeNavigationMonitor()
    monitor.run() 
