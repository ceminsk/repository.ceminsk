import xbmc
import time
import re
import os
import math
import subprocess

def get_os_release_content():
    """读取/etc/os-release文件的完整内容"""
    os_release_path = "/etc/os-release"
    if not os.path.exists(os_release_path):
        xbmc.log(f"{os_release_path} 文件不存在", xbmc.LOGWARNING)
        return None
    
    try:
        with open(os_release_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        xbmc.log(f"读取 {os_release_path} 失败: {e}", xbmc.LOGERROR)
        return None

def get_pretty_name_from_os_release():
    """从/etc/os-release文件中获取PRETTY_NAME的值"""
    xbmc.log("尝试从/etc/os-release获取PRETTY_NAME", xbmc.LOGINFO)
    content = get_os_release_content()
    if not content:
        return None
        
    for line in content.splitlines():
        match = re.match(r'^PRETTY_NAME="(.*)"', line.strip())
        if match:
            pretty_name = match.group(1)
            xbmc.log(f"成功获取PRETTY_NAME: {pretty_name}", xbmc.LOGINFO)
            return pretty_name
            
    xbmc.log("在 /etc/os-release 中未找到PRETTY_NAME字段", xbmc.LOGWARNING)
    return None

def extract_date_or_version(version_string):
    """从版本字符串中提取版本信息，优先保留完整版本号+日期"""
    if not version_string:
        return None

    # --- 1. LibreELEC 特殊处理 (保持原样) ---
    if re.search(r'libreelec', version_string, re.IGNORECASE):
        xbmc.log("检测到 LibreELEC 系统，尝试提取特定版本格式", xbmc.LOGINFO)
        
        le_date_pattern = re.compile(r'(R\d+\.\d+\.\d+)-(\d{8})')
        le_date_match = le_date_pattern.search(version_string)
        if le_date_match:
            return f"{le_date_match.group(1)}-{le_date_match.group(2)}"
            
        le_rc_pattern = re.compile(r'(R\d+\.\d+\.\d+-RC\d+)')
        le_rc_match = le_rc_pattern.search(version_string)
        if le_rc_match:
            return le_rc_match.group(1)

    # --- 2. 优先尝试提取完整的“字母+数字+小数”版本号 (如 X10.3, F10.1) ---
    complex_version_pattern = re.compile(r'([A-Za-z]+\d+(?:\.\d+)+)')
    complex_match = complex_version_pattern.search(version_string)
    
    found_complex_ver = None
    if complex_match:
        found_complex_ver = complex_match.group(1)
        xbmc.log(f"提取到完整复杂版本号: {found_complex_ver}", xbmc.LOGINFO)

    # 如果找到了复杂版本号，尝试寻找日期并拼接
    if found_complex_ver:
        date_pattern = re.compile(r'(\d{8})')
        date_match = date_pattern.search(version_string)
        if date_match:
            date_str = date_match.group(1)
            result = f"{found_complex_ver}-{date_str}"
            xbmc.log(f"提取到复杂版本号+日期: {result}", xbmc.LOGINFO)
            return result
        else:
            # 如果没有日期，只返回版本号
            xbmc.log(f"仅提取到复杂版本号: {found_complex_ver}", xbmc.LOGINFO)
            return found_complex_ver

    # --- 3. 尝试提取简单的“字母+数字”前缀 (如 R9, A11P, T2a) ---
    special_prefix_pattern = re.compile(r'([A-Z]+\d+[A-Za-z]*)')
    special_prefix_match = special_prefix_pattern.search(version_string)
    
    found_prefix = None
    
    if special_prefix_match:
        found_prefix = special_prefix_match.group(1)
        xbmc.log(f"提取到简单特殊前缀: {found_prefix}", xbmc.LOGINFO)
    else:
        # Fallback: 检查 os-release 内容中的 no/ng
        full_content = get_os_release_content()
        if full_content:
            lower_content = full_content.lower()
            if "no" in lower_content:
                found_prefix = "No"
            elif "ng" in lower_content:
                found_prefix = "Ng"
        
        if found_prefix:
            xbmc.log(f"提取到替代前缀: {found_prefix}", xbmc.LOGINFO)

    # 如果找到了简单前缀，尝试结合日期
    if found_prefix:
        date_pattern = re.compile(r'(\d{8})')
        date_match = date_pattern.search(version_string)
        if date_match:
            date_str = date_match.group(1)
            result = f"{found_prefix}-{date_str}"
            xbmc.log(f"提取到前缀+日期: {result}", xbmc.LOGINFO)
            return result
        else:
            xbmc.log(f"仅提取到前缀: {found_prefix}", xbmc.LOGINFO)
            return found_prefix

    # --- 4. 如果没有前缀，尝试单独提取日期 ---
    date_pattern = re.compile(r'(\d{8})')
    date_match = date_pattern.search(version_string)
    if date_match:
        date_str = date_match.group(1)
        date_mapping = {
            "20250222": "A11P",
            "20250302": "A14",
            "20251230": "R4",
            "20260110": "R5",
            "20260119": "R6",
            "20260208": "R7",
            "20260301": "R8",
            "20260323": "R9",
            "20260205": "T2a",
            "20260204": "T2",
            "20260121": "T1"
        }
        
        if date_str in date_mapping:
            result = f"{date_mapping[date_str]}-{date_str}"
        else:
            result = f"-{date_str}"
            
        xbmc.log(f"提取到的构建日期: {result}", xbmc.LOGINFO)
        return result

    # --- 5. 最后兜底：简单版本号 (如 21.3) ---
    version_pattern = re.compile(r'(\d+\.\d+)')
    version_match = version_pattern.search(version_string)
    if version_match:
        version_str = version_match.group(1)
        xbmc.log(f"提取到简单版本号: {version_str}", xbmc.LOGINFO)
        return version_str

    xbmc.log(f"无法从'{version_string}'中提取日期或版本号", xbmc.LOGWARNING)
    return None

def get_prefix_from_version_string(version_string):
    """根据版本字符串判断前缀"""
    if not version_string:
        return "未知"

    lower_version = version_string.lower()

    # 优先级: forbxy > avdvplus
    if "libreelec" in lower_version:
        return "LibreELEC-"
    elif "forbxy" in lower_version:
        return "forbxy-"
    elif "avdvplus" in lower_version:
        return "avdvplus-"
    elif "community" in lower_version:
        return "社区版-"
    elif "nightly" in lower_version:
        return "夜版-"
    elif "official" in lower_version:
        return "原版-"
    else:
        return "其他-"

def set_build_date_with_prefix():
    """根据版本字符串判断前缀，并设置构建日期/版本号"""
    version_string = get_pretty_name_from_os_release()
    xbmc.log(f"获取到的版本字符串: {version_string}", xbmc.LOGINFO)

    build_info = extract_date_or_version(version_string)
    xbmc.log(f"处理后的构建信息: {build_info}", xbmc.LOGINFO)

    if not build_info:
        final_build_date = "未知"
    else:
        prefix = get_prefix_from_version_string(version_string)
        final_build_date = f"{prefix}{build_info}"

    xbmc.log(f"设置Skin.SetString(BuildDate, {final_build_date})", xbmc.LOGINFO)
    xbmc.executebuiltin(f'Skin.SetString(BuildDate,{final_build_date})')

def set_version_from_file():
    """从version.txt读取版本号，如果不存在则根据条件创建"""
    from xbmcvfs import translatePath, exists
    import subprocess

    home_path = translatePath('special://home/userdata/')
    version_file = os.path.join(home_path, 'version.txt')

    if exists(version_file):
        try:
            with open(version_file, 'r', encoding='utf-8', errors='ignore') as f:
                version_content = f.readline().strip()
            xbmc.executebuiltin(f'Skin.SetString(version,{version_content})')
            return
        except Exception as e:
            xbmc.log(f"读取version.txt失败: {str(e)}", xbmc.LOGERROR)

    try:
        result = subprocess.check_output(['df', '-P', '/flash'],
                                         stderr=subprocess.STDOUT,
                                         universal_newlines=True)
        lines = result.strip().split('\n')
        if len(lines) >= 2:
            parts = lines[1].split()
            if len(parts) >= 2:
                size_kb = int(parts[1])
                size_mb = size_kb / 1024
                xbmc.log(f"/flash分区大小: {size_mb:.2f}MB", xbmc.LOGINFO)

                if size_mb > 800:
                    version_content = "Minsk-20251007"
                else:
                    if exists('/flash/KERNELcpm.img.md5') or exists('/flash/KERNELce.img.md5'):
                        version_content = "Minsk-20250926"
                    else:
                        version_content = "Minsk-早期版本"

                with open(version_file, 'w', encoding='utf-8') as f:
                    f.write(version_content)
                xbmc.log(f"创建version.txt，内容: {version_content}", xbmc.LOGINFO)
                xbmc.executebuiltin(f'Skin.SetString(version,{version_content})')
                return
    except Exception as e:
        xbmc.log(f"检查/flash分区大小失败: {str(e)}", xbmc.LOGERROR)

    xbmc.executebuiltin('Skin.SetString(version,Minsk-未知版本)')

def get_cpu_and_hardware_info():
    """从/proc/cpuinfo文件中提取CPU型号和硬件型号信息"""
    cpuinfo_path = ""
    if os.name == 'nt':
        cpuinfo_path = r"C:\proc\cpuinfo"
    else:
        cpuinfo_path = "/proc/cpuinfo"

    if not os.path.exists(cpuinfo_path):
        xbmc.log(f"{cpuinfo_path} 文件不存在", xbmc.LOGWARNING)
        xbmc.executebuiltin('Skin.SetString(cputype,)')
        xbmc.executebuiltin('Skin.SetString(hwtype,)')
        return

    cpu_model = None
    hardware_model = None
    raw_model_str = None

    try:
        with open(cpuinfo_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.splitlines()
        
        # 1. 获取原始 CPU 字符串
        for line in lines:
            line_stripped = line.strip()
            if line_stripped.startswith('model name'):
                match = re.match(r'^model name\s*:\s*(.+)', line_stripped)
                if match:
                    raw_model_str = match.group(1).strip()
                    break
            if not raw_model_str and re.match(r'^soc\s*:', line_stripped, re.IGNORECASE):
                match = re.match(r'^soc\s*:\s*(.+)', line_stripped, re.IGNORECASE)
                if match:
                    raw_model_str = match.group(1).strip()
                    break

        # 2. 清洗 CPU 型号
        if raw_model_str:
            xbmc.log(f"原始CPU字符串: {raw_model_str}", xbmc.LOGINFO)
            
            vendor = ""
            model_part = ""
            
            lower_raw = raw_model_str.lower()
            
            if "intel" in lower_raw:
                vendor = "Intel"
            elif "amd" in lower_raw:
                vendor = "AMD"
            
            intel_pattern = re.compile(r'(?:Core\s+)?(i\d-[A-Za-z0-9]+|Ultra\s+\d+\s*[A-Za-z0-9]+|N\d{3,4}[A-Za-z]*|(?:Pentium|Celeron)\s*[A-Za-z0-9]+)', re.IGNORECASE)
            amd_pattern = re.compile(r'(Ryzen\s+(?:AI\s+)?\d+\s*[A-Za-z0-9\s]*(?:HX|HS|U|G|X|PRO|GE|XT)?|Athlon\s*[A-Za-z0-9]+)', re.IGNORECASE)
            
            matched = False
            
            if vendor == "Intel":
                m = intel_pattern.search(raw_model_str)
                if m:
                    model_part = m.group(1).strip()
                    model_part = re.sub(r'\s+', ' ', model_part)
                    matched = True
            elif vendor == "AMD":
                m = amd_pattern.search(raw_model_str)
                if m:
                    model_part = m.group(1).strip()
                    model_part = re.sub(r'\s+', ' ', model_part)
                    matched = True
            
            if not matched:
                cleaned = raw_model_str
                cleaned = re.sub(r'\(R\)|\(TM\)', '', cleaned)
                cleaned = re.sub(r'\s*@\s*.*$', '', cleaned)
                cleaned = re.sub(r'\bGen\b\s*\d+\s*', '', cleaned)
                cleaned = re.sub(r'\bCPU\b', '', cleaned, flags=re.IGNORECASE)
                cleaned = cleaned.strip()
                if cleaned and len(cleaned) > 3:
                    model_part = cleaned
                    matched = True

            if matched:
                if vendor:
                    if model_part.lower().startswith(vendor.lower()):
                        cpu_model = model_part
                    else:
                        cpu_model = f"{vendor} {model_part}"
                else:
                    cpu_model = model_part
                
                xbmc.log(f"最终CPU型号: {cpu_model}", xbmc.LOGINFO)
            else:
                cpu_model = raw_model_str
                xbmc.log(f"未能精确匹配CPU型号，使用原始字符串: {cpu_model}", xbmc.LOGWARNING)

        # 3. 获取 Hardware 型号
        for line in lines:
            line_stripped = line.strip()
            if line_stripped.startswith('Hardware'):
                match = re.match(r'^Hardware\s*:\s*(.+)', line_stripped)
                if match:
                    hardware_model = match.group(1).strip()
                    xbmc.log(f"提取到硬件型号: {hardware_model}", xbmc.LOGINFO)
                    break
                        
    except Exception as e:
        xbmc.log(f"读取或解析 {cpuinfo_path} 失败: {e}", xbmc.LOGERROR)
        xbmc.executebuiltin('Skin.SetString(cputype,)')
        xbmc.executebuiltin('Skin.SetString(hwtype,)')
        return

    if cpu_model:
        xbmc.executebuiltin(f'Skin.SetString(cputype,{cpu_model})')
        xbmc.log(f"设置CPU型号变量: {cpu_model}", xbmc.LOGINFO)
    else:
        xbmc.executebuiltin('Skin.SetString(cputype,)')
        xbmc.log("未找到CPU型号信息，清空cputype变量", xbmc.LOGINFO)

    if hardware_model:
        xbmc.executebuiltin(f'Skin.SetString(hwtype,{hardware_model})')
        xbmc.log(f"设置硬件型号变量: {hardware_model}", xbmc.LOGINFO)
    else:
        if cpu_model:
            xbmc.executebuiltin(f'Skin.SetString(hwtype,{cpu_model})')
            xbmc.log(f"未找到独立硬件型号，hwtype 复用 CPU 型号: {cpu_model}", xbmc.LOGINFO)
        else:
            xbmc.executebuiltin('Skin.SetString(hwtype,)')
            xbmc.log("未找到硬件型号信息，清空hwtype变量", xbmc.LOGINFO)

def set_memory_total():
    """获取系统总内存并转换为整数GB，然后设置memtotal变量"""
    total_memory_raw = xbmc.getInfoLabel('System.Memory(total)')
    if not total_memory_raw:
        xbmc.log("无法获取系统总内存信息", xbmc.LOGWARNING)
        xbmc.executebuiltin('Skin.SetString(memtotal,)')
        return

    memory_value_gb = 0.0
    try:
        if 'GB' in total_memory_raw.upper():
            value_str = total_memory_raw.replace('GB', '').replace('gb', '').strip()
            memory_value_gb = float(value_str)
        elif 'MB' in total_memory_raw.upper():
            value_str = total_memory_raw.replace('MB', '').replace('mb', '').strip()
            memory_value_gb = float(value_str) / 1024.0
        else:
            memory_value_gb = float(total_memory_raw) / 1024.0
    except ValueError:
        xbmc.log(f"无法解析内存值: {total_memory_raw}", xbmc.LOGWARNING)
        xbmc.executebuiltin('Skin.SetString(memtotal,)')
        return

    standard_ram_sizes = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128]
    closest_ram = min(standard_ram_sizes, key=lambda x: abs(x - memory_value_gb))
    
    xbmc.executebuiltin(f'Skin.SetString(memtotal,{closest_ram}GB)')
    xbmc.log(f"设置内存总量: {closest_ram}GB (原始计算值: {memory_value_gb:.2f}GB)", xbmc.LOGINFO)

def set_storage_total():
    """执行df -h /storage命令获取存储信息并设置hdtotal变量"""
    try:
        result = subprocess.check_output(['df', '-h', '/storage'],
                                         stderr=subprocess.STDOUT,
                                         universal_newlines=True)
        
        lines = result.strip().split('\n')
        if len(lines) < 2:
            xbmc.log("df命令输出格式异常", xbmc.LOGWARNING)
            xbmc.executebuiltin('Skin.SetString(hdtotal,)')
            return
            
        data_line = lines[1]
        parts = data_line.split()
        
        if len(parts) < 2:
            xbmc.log("df命令输出数据不足", xbmc.LOGWARNING)
            xbmc.executebuiltin('Skin.SetString(hdtotal,)')
            return
            
        size_str = parts[1]
        size_value = 0
        if size_str.endswith('G'):
            size_value = float(size_str[:-1])
        elif size_str.endswith('M'):
            size_value = float(size_str[:-1]) / 1024
        elif size_str.endswith('T'):
            size_value = float(size_str[:-1]) * 1024
        else:
            size_value = float(size_str) / (1024 * 1024)
        
        log2_value = math.log2(size_value)
        rounded_log2 = round(log2_value)
        closest_power_of_2 = 2 ** rounded_log2
        
        xbmc.executebuiltin(f'Skin.SetString(hdtotal,{closest_power_of_2}GB)')
        xbmc.log(f"设置硬盘容量: {closest_power_of_2}GB (原始值: {size_value}GB)", xbmc.LOGINFO)
        
    except subprocess.CalledProcessError as e:
        xbmc.log(f"执行df命令失败: {str(e)}", xbmc.LOGERROR)
        xbmc.executebuiltin('Skin.SetString(hdtotal,)')
    except Exception as e:
        xbmc.log(f"处理存储信息时出错: {str(e)}", xbmc.LOGERROR)
        xbmc.executebuiltin('Skin.SetString(hdtotal,)')

if __name__ == '__main__':
    xbmc.log("开始执行版本信息脚本", xbmc.LOGINFO)
    set_build_date_with_prefix()
    set_version_from_file()
    get_cpu_and_hardware_info()
    set_memory_total()
    set_storage_total()
    xbmc.log("版本信息脚本执行完成", xbmc.LOGINFO)