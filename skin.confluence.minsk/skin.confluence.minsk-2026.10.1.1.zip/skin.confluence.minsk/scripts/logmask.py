# -*- coding: utf-8 -*-
"""日志脱敏工具：防止局域网/WebDAV 路径中的用户名密码明文写入 Kodi 日志。

背景
----
Kodi 在播放网络媒体时，``Player.Folderpath`` / ``Player.FileNameAndPath`` /
``ListItem.FileNameAndPath`` 等信息标签返回的路径可能带有明文凭据，形如::

    dav://USERNAME:PASSWORD@localhost:19798/dav/115open/高清电影/...

若把这些字符串直接拼进 ``xbmc.log(...)``，密码就会以明文形式落盘到
``kodi.log`` / ``kodi.old.log``，一旦日志被分享或上传即造成凭据泄漏。

本模块提供统一的脱敏函数，供各脚本在写日志前调用::

    from logmask import sanitize_credentials
    xbmc.log(sanitize_credentials(msg), level)

设计约束
--------
1. **只影响输出，不影响逻辑**：脱敏仅作用于最终写往日志的字符串，
   参与业务判断的路径（XML 记录、数据库匹配、播放调用）始终保持原样。
2. **不改变日志级别**：包装函数完整保留 ``level`` 参数语义，
   包括 ``xbmc.log`` 默认的 ``LOGDEBUG`` 行为。
3. **零副作用**：本模块只依赖标准库 ``re``，不导入 ``xbmc``，
   因此可以在任何脚本（含非 Kodi 环境）中安全使用。

Kodi 21.3 的 ``CPythonInvoker`` 会把脚本所在目录加入 ``sys.path``，
因此同目录下的脚本可直接 ``import logmask``。
"""

import re

# 密码掩码
LOG_CREDENTIAL_MASK = "***"

# 是否同时隐藏用户名。
# False（默认）：保留用户名，便于排查"是哪个账号/路径"的问题。
# True：用户名与密码一并隐藏，适合对外分享日志的场景。
LOG_MASK_USERNAME = False

# 匹配 URL 的 "scheme://authority" 部分。
# authority 以空白、/、?、# 或字符串结束为界；
# 排除 / 与 ? 是为了不把路径部分误当作主机信息。
_URL_CREDENTIAL_RE = re.compile(
    r'(?P<scheme>[A-Za-z][A-Za-z0-9+.\-]*://)(?P<authority>[^\s/?#]*)'
)


def sanitize_credentials(text):
    """将文本中 URL 里的明文密码替换为掩码（用户名可选一并隐藏）。

    处理示例::

        dav://USERNAME:PASSWORD@localhost:19798/dav/x
        -> dav://USERNAME:***@localhost:19798/dav/x

    仅当 authority 中存在 "user:password@" 形式时才改动，
    因此 ``nfs://host/path``、``special://home/``、``D:\\media\\a.mkv``
    等不含凭据的路径会被原样保留。

    参数
    ----
    text : 任意类型
        待脱敏的文本。非字符串会被先转为字符串。

    返回
    ----
    str
        脱敏后的文本。输入为 ``None`` 或空串时原样返回。
    """
    if text is None:
        return text

    try:
        if not isinstance(text, str):
            text = str(text)

        if not text:
            return text

        def _replace(match):
            scheme = match.group("scheme")
            authority = match.group("authority")

            if "@" not in authority:
                return match.group(0)

            # 用最后一个 @ 分割，保证密码本身含 @ 时也能正确处理
            userinfo, _sep, host = authority.rpartition("@")
            if not userinfo:
                return match.group(0)

            username, colon, password = userinfo.partition(":")
            if not colon or not password:
                # 没有密码部分（如 dav://token@host）：
                # 仅在要求隐藏用户名时才脱敏
                if LOG_MASK_USERNAME:
                    return "{}{}@{}".format(scheme, LOG_CREDENTIAL_MASK, host)
                return match.group(0)

            if LOG_MASK_USERNAME and username:
                username = LOG_CREDENTIAL_MASK

            return "{}{}:{}@{}".format(scheme, username, LOG_CREDENTIAL_MASK, host)

        return _URL_CREDENTIAL_RE.sub(_replace, text)
    except Exception:
        # 脱敏异常时保证不影响脚本运行
        return text
