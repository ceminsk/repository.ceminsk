# -*- coding: utf-8 -*-
import os
import sqlite3
import xbmc
import xbmcvfs
import glob

def log(msg):
    """简单的日志记录函数"""
    xbmc.log("[ChkPosterUrl] %s" % msg, level=xbmc.LOGINFO)

def get_database_path(db_name_pattern):
    """
    在 userdata/Database 目录下查找符合模式的最新数据库文件
    """
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    db_dir = os.path.join(userdata_path, 'Database')
    
    if not os.path.exists(db_dir):
        log("Database directory not found: %s" % db_dir)
        return None

    pattern = os.path.join(db_dir, db_name_pattern)
    files = glob.glob(pattern)
    
    if not files:
        log("No files found matching pattern: %s" % db_name_pattern)
        return None
    
    latest_file = max(files, key=os.path.getmtime)
    log("Found latest database: %s" % latest_file)
    return latest_file

def is_no_core():
    """
    检测当前系统是否为 No / LibreELEC 核心。
    方法：检查 /etc/os-release 文件内容是否包含 'no' 或 'libreelec'（均不区分大小写）。
    """
    release_file = '/etc/os-release'
    content = None
    try:
        if os.path.exists(release_file):
            try:
                with open(release_file, 'rb') as f:
                    content = f.read()
            except Exception:
                content = None
        if content is None:
            try:
                import xbmcvfs
                if xbmcvfs.exists(release_file):
                    with xbmcvfs.File(release_file) as f:
                        content = f.read()
            except Exception:
                content = None
        if content is None:
            return False
        if isinstance(content, bytes):
            content = content.decode('utf-8', 'ignore')
        lowered = content.lower()
        return ('no' in lowered) or ('libreelec' in lowered)
    except Exception:
        return False


def clean_wsrv_urls(video_db_path, texture_db_path):
    """
    清理视频数据库中的 wsrv.nl 代理链接
    """
    if not video_db_path:
        log("Video DB path is invalid. Aborting.")
        return

    log("Starting cleanup process...")
    log("Video DB: %s" % video_db_path)
    if texture_db_path:
        log("Texture DB: %s" % texture_db_path)
    else:
        log("Texture DB not found, will remove all wsrv prefixes without checking.")

    prefix = "https://wsrv.nl/?url="
    
    conn_vid = None
    conn_tex = None
    
    try:
        # 连接纹理数据库
        if texture_db_path and os.path.exists(texture_db_path):
            conn_tex = sqlite3.connect(texture_db_path)
            cursor_tex = conn_tex.cursor()
        else:
            cursor_tex = None
            
        # 连接视频数据库
        conn_vid = sqlite3.connect(video_db_path)
        cursor_vid = conn_vid.cursor()

        # 1. 获取 art 表中所有以 https://wsrv.nl 开头的 url
        # 注意: art 表的主键通常是 art_id
        query_art = "SELECT art_id, url FROM art WHERE url LIKE ?"
        cursor_vid.execute(query_art, (prefix + '%',))
        rows = cursor_vid.fetchall()
        
        log("Found %d entries with wsrv.nl prefix in art table." % len(rows))
        
        updated_count = 0
        skipped_count = 0
        
        for art_id, original_url in rows:
            should_update = True
            
            if cursor_tex:
                # 检查该完整 URL 是否存在于 texture 表的 url 字段中
                try:
                    # texture 表结构: id, url, ...
                    cursor_tex.execute("SELECT 1 FROM texture WHERE url = ?", (original_url,))
                    exists_in_texture = cursor_tex.fetchone()
                    
                    if exists_in_texture:
                        # 如果找到了，无需操作
                        skipped_count += 1
                        should_update = False
                except Exception as e:
                    log("Error querying texture DB: %s" % str(e))
            
            if should_update:
                # 如果没找到或者没有纹理库，删除前缀
                if original_url.startswith(prefix):
                    new_url = original_url[len(prefix):]
                    
                    # 更新视频数据库，使用 art_id
                    update_query = "UPDATE art SET url = ? WHERE art_id = ?"
                    cursor_vid.execute(update_query, (new_url, art_id))
                    updated_count += 1
                    
        # 提交更改
        conn_vid.commit()
        
        log("Cleanup finished. Updated: %d, Skipped (found in texture): %d" % (updated_count, skipped_count))

    except Exception as e:
        log("Error during database operation: %s" % str(e))
    finally:
        if conn_tex: conn_tex.close()
        if conn_vid: conn_vid.close()

def main():
    log("Script started.")
    
    # 1. 确定核心类型
    no_core = is_no_core()
    
    # 2. 确定数据库文件名模式
    if no_core:
        video_pattern = "MyVideos14*.db"
        texture_name = "Textures14.db"
    else:
        video_pattern = "MyVideos13*.db"
        texture_name = "Textures13.db"
        
    # 3. 获取数据库路径
    userdata_path = xbmcvfs.translatePath('special://userdata/')
    db_dir = os.path.join(userdata_path, 'Database')
    
    video_db_path = get_database_path(video_pattern)
    texture_db_path = os.path.join(db_dir, texture_name)
    
    # 检查纹理数据库是否存在
    if not os.path.exists(texture_db_path):
        log("Texture database not found: %s" % texture_db_path)
        texture_db_path = None
        
    # 4. 执行清理
    if video_db_path:
        clean_wsrv_urls(video_db_path, texture_db_path)
    else:
        log("Could not find video database. Exiting.")

if __name__ == '__main__':
    main()