# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import requests
import os
import re
import uuid
import base64
import platform
import traceback

token_b64_part1 = "NmVlYjAzZjc2ZDBhOWM4"
token_b64_part2 = "OTE1OTEzMzM5ZDk4NjQ5NmQ="
GITEE_TOKEN = base64.b64decode(f"{token_b64_part1}{token_b64_part2}".encode()).decode()

REPO_OWNER = "ce-fans"
REPO_NAME = "Minsk-skinauth"
FILE_PATH = "minsk-auth/authsort.txt"
GITEE_API_URL = f"https://gitee.com/api/v5/repos/{REPO_OWNER}/{REPO_NAME}/contents/{FILE_PATH}"

try:
    USERDATA_PATH = xbmcvfs.translatePath("special://userdata/")
except AttributeError:
    USERDATA_PATH = xbmc.translatePath("special://userdata/")

ADDON_DATA_DIR = os.path.join(USERDATA_PATH, "addon_data", "skin.confluence.minsk")
IDKEY_PATH = os.path.join(ADDON_DATA_DIR, "idkey")
DEVICE_ID_PATH = os.path.join(ADDON_DATA_DIR, ".device_unique_id")

LOG_PREFIX = "[AuthOption] "

def is_coreelec():
    try:
        if os.path.exists("/storage/.config"): return True
        uname = platform.uname()
        if "coreelec" in uname.release.lower() or "coreelec" in uname.version.lower(): return True
    except Exception: pass
    return False

def get_device_id():
    xbmc.log(f"{LOG_PREFIX}开始获取设备标识", level=xbmc.LOGINFO)
    device_id = None
    sys_name = platform.system()
    
    # CoreELEC or Linux: Try CPU Serial then MAC
    if is_coreelec() or sys_name == "Linux":
        cpuinfo_path = "/proc/cpuinfo"
        if xbmcvfs.exists(cpuinfo_path):
            try:
                with open(cpuinfo_path, "r", encoding="utf-8") as f:
                    content = f.read()
                match = re.search(r"Serial\s*:\s*(\w+)", content)
                if match:
                    device_id = match.group(1).strip()
                    if device_id and device_id != "0000000000000000":
                        xbmc.log(f"{LOG_PREFIX}获取CPU序列号成功", level=xbmc.LOGINFO)
                    else:
                        device_id = None
            except Exception as e:
                xbmc.log(f"{LOG_PREFIX}读取CPU序列号失败：{str(e)}", level=xbmc.LOGERROR)
        
        if not device_id:
            try:
                mac_int = uuid.getnode()
                if mac_int and mac_int != 0xffffffffffff:
                    device_id = hex(mac_int)[2:].zfill(12).upper()
                    xbmc.log(f"{LOG_PREFIX}获取MAC地址成功", level=xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"{LOG_PREFIX}读取MAC地址失败：{str(e)}", level=xbmc.LOGERROR)
                
    # Other Systems (Android, Windows, etc.): Use Persistent File ID
    if not device_id:
        try:
            if not os.path.exists(ADDON_DATA_DIR):
                os.makedirs(ADDON_DATA_DIR)
            
            if os.path.exists(DEVICE_ID_PATH):
                with open(DEVICE_ID_PATH, "r", encoding="utf-8") as f:
                    stored_id = f.read().strip()
                    if stored_id:
                        device_id = stored_id
                        xbmc.log(f"{LOG_PREFIX}从持久化文件读取设备ID成功", level=xbmc.LOGINFO)
                    else:
                        raise ValueError("Empty ID file")
            else:
                new_id = str(uuid.uuid4())
                with open(DEVICE_ID_PATH, "w", encoding="utf-8") as f:
                    f.write(new_id)
                device_id = new_id
                xbmc.log(f"{LOG_PREFIX}生成并保存新的持久化设备ID", level=xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"{LOG_PREFIX}持久化ID读写失败，使用临时UUID：{str(e)}", level=xbmc.LOGERROR)
            device_id = str(uuid.uuid4())

    # Normalize ID for comparison (remove separators, uppercase)
    clean_id = device_id.replace(":", "").replace("-", "").upper() if device_id else "UNKNOWN_DEVICE"
    xbmc.log(f"{LOG_PREFIX}最终设备标识：{clean_id}", level=xbmc.LOGINFO)
    return clean_id

def get_qq_number():
    xbmc.log(f"{LOG_PREFIX}开始获取QQ号", level=xbmc.LOGINFO)
    qq = None

    if xbmcvfs.exists(IDKEY_PATH):
        try:
            with open(IDKEY_PATH, "r", encoding="utf-8") as f:
                content = f.read().strip()
            match = re.search(r"(\d+)", content)
            if match:
                qq = match.group(1).strip()
                xbmc.log(f"{LOG_PREFIX}从idkey文件获取QQ号成功", level=xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"{LOG_PREFIX}读取idkey文件失败：{str(e)}", level=xbmc.LOGERROR)
    
    if not qq:
        window = xbmcgui.Window(10000)
        skinauth = window.getProperty("skinauth") or ""
        skinauth = skinauth.strip()
        if skinauth and skinauth.isdigit():
            qq = skinauth
            xbmc.log(f"{LOG_PREFIX}从Skin.String获取QQ号成功", level=xbmc.LOGINFO)
    
    return qq

def get_gitee_file():
    xbmc.log(f"{LOG_PREFIX}开始获取Gitee文件", level=xbmc.LOGINFO)
    headers = {
        "Authorization": f"token {GITEE_TOKEN}",
        "Accept": "application/json"
    }
    try:
        resp = requests.get(GITEE_API_URL, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        content = base64.b64decode(data["content"]).decode("utf-8")
        sha = data["sha"]
        return content, sha
    except Exception as e:
        xbmc.log(f"{LOG_PREFIX}获取Gitee文件失败：{str(e)}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("错误", f"获取授权文件失败：{str(e)}")
        return None, None

def update_gitee_file(new_content, sha):
    xbmc.log(f"{LOG_PREFIX}开始更新Gitee文件", level=xbmc.LOGINFO)
    headers = {
        "Authorization": f"token {GITEE_TOKEN}",
        "Accept": "application/json"
    }
    encoded_content = base64.b64encode(new_content.encode("utf-8")).decode("utf-8")
    payload = {
        "content": encoded_content,
        "sha": sha,
        "message": "Update authsort.txt via KODI auth script"
    }
    try:
        resp = requests.put(GITEE_API_URL, json=payload, headers=headers, timeout=10)
        resp.raise_for_status()
        return True
    except Exception as e:
        xbmc.log(f"{LOG_PREFIX}更新Gitee文件失败：{str(e)}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("错误", f"更新授权文件失败：{str(e)}")
        return False

def clear_auth_data():
    xbmc.log(f"{LOG_PREFIX}开始清空授权数据", level=xbmc.LOGINFO)
    
    xbmc.executebuiltin('Skin.SetString(authfail,1)')
    xbmc.executebuiltin('Skin.SetString(skinauth,"")')
    xbmc.executebuiltin('Skin.SetString(authdate,"")')
    xbmc.executebuiltin('Skin.SetString(skinauthhide,"")')
    
    window = xbmcgui.Window(10000)
    window.setProperty("authfail", "1")
    window.setProperty("skinauth", "")
    window.setProperty("authdate", "")
    window.setProperty("skinauthhide", "")

    if xbmcvfs.exists(IDKEY_PATH):
        if xbmcvfs.delete(IDKEY_PATH):
            xbmc.log(f"{LOG_PREFIX}idkey文件删除成功", level=xbmc.LOGINFO)
        else:
            xbmc.log(f"{LOG_PREFIX}idkey文件删除失败", level=xbmc.LOGERROR)

def handle_manual_auth():
    script_path = "special://skin/scripts/skinauto.py"
    xbmc.executebuiltin(f"RunScript({script_path},manual)")

def handle_view_delete_device(device_id):
    xbmc.log(f"{LOG_PREFIX}用户选择查看/删除授权设备", level=xbmc.LOGINFO)
    
    qq = get_qq_number()
    if not qq:
        xbmcgui.Dialog().ok("提示", "该机尚未获得任何账户授权！")
        return

    content, sha = get_gitee_file()
    if not content or not sha:
        return

    lines = content.splitlines()
    qq_lines = [line.strip() for line in lines if line.strip().startswith(qq)]
    if not qq_lines:
        xbmcgui.Dialog().ok("提示", "该账号暂无授权设备！")
        return

    options = []
    line_map = {}
    time_pattern = re.compile(r'(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})')
    
    for line in qq_lines:
        time_match = time_pattern.search(line)
        if not time_match: continue
        
        time_str = time_match.group(1)
        temp_line = line.replace(qq, "").replace(time_str, "").strip()
        line_parts = temp_line.split()
        
        device_parts = [part for part in line_parts if not (part.isdigit() and len(part) == 6)]
        if not device_parts: continue
        
        device_str_original = device_parts[0].strip()
        # Normalize the device ID from the file for comparison
        file_device_id_clean = device_str_original.replace(":", "").replace("-", "").upper()
        
        option_text = f"{time_str} {device_str_original}"
        
        # Compare cleaned IDs
        if file_device_id_clean == device_id:
            option_text = f"[COLOR green]（本机）[/COLOR] {option_text}"
        
        options.append(option_text)
        line_map[option_text] = line

    if not options:
        xbmcgui.Dialog().ok("提示", "未找到该账号的有效授权设备！")
        return

    dialog = xbmcgui.Dialog()
    selected_idx = dialog.select("查看/删除授权设备", options)
    if selected_idx == -1: return

    selected_text = options[selected_idx]
    selected_line = line_map[selected_text]
    is_local = "[COLOR green]（本机）[/COLOR]" in selected_text

    if is_local:
        confirm = dialog.yesno("确认", "您选择的是删除本机授权，是否确认？")
    else:
        clean_text = selected_text.replace("[COLOR green]（本机）[/COLOR] ", "")
        confirm = dialog.yesno("确认", f"是否确认删除授权：{clean_text}？")
    
    if not confirm: return

    new_lines = [line for line in lines if line.strip() != selected_line.strip()]
    new_content = "\n".join(new_lines)

    if update_gitee_file(new_content, sha):
        if is_local:
            clear_auth_data()
        dialog.ok("成功", "授权删除成功！")
    else:
        dialog.ok("失败", "授权删除失败！")

def handle_delete_all_auth():
    xbmc.log(f"{LOG_PREFIX}用户选择删除所有授权", level=xbmc.LOGINFO)
    
    qq = get_qq_number()
    if not qq:
        xbmcgui.Dialog().ok("提示", "该机尚未获得任何账户授权！")
        return

    dialog = xbmcgui.Dialog()
    confirm = dialog.yesno("确认", f"是否确认删除QQ号 {qq} 的所有授权？此操作不可恢复！")
    if not confirm: return

    content, sha = get_gitee_file()
    if not content or not sha: return

    lines = content.splitlines()
    new_lines = [line for line in lines if not line.strip().startswith(qq)]
    new_content = "\n".join(new_lines)

    if update_gitee_file(new_content, sha):
        clear_auth_data()
        dialog.ok("成功", "该账号所有授权已删除！")
    else:
        dialog.ok("失败", "删除所有授权失败！")

def main():
    xbmc.log(f"{LOG_PREFIX}授权管理脚本启动", level=xbmc.LOGINFO)
    
    device_id = get_device_id()
    
    dialog = xbmcgui.Dialog()
    main_options = [
        "手动输入取得授权",
        "查看本账号授权的设备(点击删除)",
        "删除本账号所有授权"
    ]
    selected_idx = dialog.select("授权管理", main_options)

    if selected_idx == 0:
        handle_manual_auth()
    elif selected_idx == 1:
        handle_view_delete_device(device_id)
    elif selected_idx == 2:
        handle_delete_all_auth()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        xbmc.log(f"{LOG_PREFIX}脚本执行异常：{str(e)}\n{traceback.format_exc()}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("脚本错误", f"授权管理脚本执行失败：{str(e)}")