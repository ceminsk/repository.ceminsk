# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import json
import re

def main():
    target_name = "播放记录"
    header = "影视分库管理"
    
    # 获取 favourites.xml 的物理路径
    fav_path = xbmcvfs.translatePath("special://userdata/favourites.xml")
    
    # 读取文件内容
    content = ""
    if xbmcvfs.exists(fav_path):
        with open(fav_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
    # 检查是否已存在 "播放记录"
    # 使用正则匹配 name="播放记录"，避免 XML 命名空间问题
    if re.search(r'name\s*=\s*"{}"'.format(re.escape(target_name)), content):
        xbmcgui.Dialog().ok(header, "影视分库（收藏夹）中已包含“播放记录”条目，无需重复添加！")
        return

    # 执行添加操作
    payload = {
        "jsonrpc": "2.0",
        "method": "Favourites.AddFavourite",
        "params": {
            "title": target_name,
            "type": "script",
            "path": "special://skin/scripts/history.py",
            "thumbnail": "special://skin/media/record.png"
        },
        "id": 1
    }
    
    xbmc.executeJSONRPC(json.dumps(payload))
    
    # 等待文件系统同步
    xbmc.sleep(1500)
    
    # 再次读取验证
    verify_content = ""
    if xbmcvfs.exists(fav_path):
        with open(fav_path, 'r', encoding='utf-8') as f:
            verify_content = f.read()
            
    if re.search(r'name\s*=\s*"{}"'.format(re.escape(target_name)), verify_content):
        xbmcgui.Dialog().ok(header, "已将“播放记录”添加至影视分库（收藏夹）中！")
    else:
        xbmcgui.Dialog().ok(header, "添加失败！请排查原因！")

if __name__ == '__main__':
    main()