import xbmc
import xbmcgui
import os
import subprocess
import re
import socket
import struct
import random
import ssl
import time

# ================= 配置项 =================
DNS_SERVERS = [
    "223.5.5.5",      # 阿里 DNS
    "119.29.29.29",   # 腾讯 DNS
    "114.114.114.114" # 114 DNS
]

# 可以添加多个需要优化的域名
DOMAINS = ["wsrv.nl", "assets.fanart.tv", "image.tmdb.org"] 

HOSTS_FILE = "/storage/.config/hosts.conf"
REBOOT_SCRIPT = "RunScript(special://skin/scripts/rebootoff.py,noask)"

# 快速退出阈值 (毫秒)
PERFORMANCE_THRESHOLD_MS = 100

def log(msg):
    try:
        xbmc.log(f"[DNSScript] {msg}", level=xbmc.LOGINFO)
    except AttributeError:
        try:
            xbmc.log(f"[DNSScript] {msg}", level=xbmc.LOGNOTICE)
        except AttributeError:
            xbmc.log(f"[DNSScript] {msg}")

# ================= 纯 Python DNS 查询模块 (绕过系统 hosts) =================

def build_dns_query(domain, txid=None):
    """构造标准的 DNS A记录 查询报文"""
    if txid is None:
        txid = random.randint(0, 65535)
    
    header = struct.pack('>HHHHHH', txid, 0x0100, 1, 0, 0, 0)
    
    qname = b''
    for part in domain.split('.'):
        if part:
            qname += bytes([len(part)]) + part.encode('utf-8')
    qname += b'\x00'
    
    question = qname + struct.pack('>HH', 1, 1)
    return header + question

def parse_dns_response(data):
    """解析 DNS 响应报文，提取 IPv4 地址"""
    if len(data) < 12:
        return []
        
    txid, flags, qdcount, ancount, nscount, arcount = struct.unpack('>HHHHHH', data[:12])
    if ancount == 0:
        return []
        
    offset = 12
    while offset < len(data) and data[offset] != 0:
        if (data[offset] & 0xC0) == 0xC0:
            offset += 2
            break
        offset += data[offset] + 1
    if offset < len(data) and data[offset] == 0:
        offset += 1
    offset += 4 
    
    ips = []
    for _ in range(ancount):
        if offset >= len(data):
            break
            
        if (data[offset] & 0xC0) == 0xC0:
            offset += 2
        else:
            while offset < len(data) and data[offset] != 0:
                offset += data[offset] + 1
            if offset < len(data):
                offset += 1
                
        if offset + 10 > len(data):
            break
            
        rtype, rclass, ttl, rdlength = struct.unpack('>HHIH', data[offset:offset+10])
        offset += 10
        
        if rtype == 1 and rdlength == 4:
            if offset + 4 <= len(data):
                ip = socket.inet_ntoa(data[offset:offset+4])
                ips.append(ip)
                
        offset += rdlength
        
    return ips

def query_dns_direct(domain, dns_server):
    """通过 UDP 直接向 DNS 服务器发送请求"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(3)
    try:
        query = build_dns_query(domain)
        sock.sendto(query, (dns_server, 53))
        data, _ = sock.recvfrom(1024)
        return parse_dns_response(data)
    except Exception as e:
        log(f"Direct DNS query to {dns_server} failed: {str(e)}")
        return []
    finally:
        sock.close()

def get_dns_ips(domain):
    """获取所有解析出的 IPv4 IP 集合"""
    all_ips = []
    
    for dns in DNS_SERVERS:
        try:
            resolved_ips = query_dns_direct(domain, dns)
            for ip_candidate in resolved_ips:
                if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip_candidate):
                    continue
                if ip_candidate == dns:
                    continue
                if ip_candidate.startswith('127.') or ip_candidate.startswith('0.'):
                    continue
                if ip_candidate not in all_ips:
                    all_ips.append(ip_candidate)
        except Exception as e:
            log(f"Direct DNS query exception for {dns}: {str(e)}")
            
    if not all_ips:
        try:
            log(f"Direct DNS failed, trying system DNS for {domain}")
            ip = socket.gethostbyname(domain)
            if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip):
                if ip not in DNS_SERVERS:
                    all_ips.append(ip)
        except Exception as e:
            log(f"System DNS resolution also failed: {str(e)}")

    return list(set(all_ips))

def ping_ip(ip):
    """Ping IP地址，返回平均响应时间(ms)。如果失败返回 None"""
    try:
        cmd = ['ping', '-c', '5', '-W', '1', '-w', '8', ip]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = process.communicate(timeout=15)
            output = stdout.decode('utf-8')
        except subprocess.TimeoutExpired:
            process.kill()
            return None

        match_ce = re.search(r'round-trip min/avg/max = \d+\.?\d*/(\d+\.?\d*)/\d+\.?\d* ms', output)
        if match_ce:
            avg_time = float(match_ce.group(1))
            loss_match = re.search(r'(\d+)% packet loss', output)
            if loss_match:
                loss_pct = int(loss_match.group(1))
                if loss_pct > 50:
                    return None
            return avg_time
            
        match_std = re.search(r'rtt min/avg/max/mdev = \d+\.?\d*/(\d+\.?\d*)/\d+\.?\d*/\d+\.?\d* ms', output)
        if match_std:
            return float(match_std.group(1))
            
        match_std2 = re.search(r'round-trip min/avg/max/stddev = \d+\.?\d*/(\d+\.?\d*)/\d+\.?\d*/\d+\.?\d* ms', output)
        if match_std2:
            return float(match_std2.group(1))
            
        if "0% packet loss" in output:
             times = re.findall(r'time=(\d+\.?\d*) ms', output)
             if times:
                 return float(times[-1])
        
        return None
            
    except Exception as e:
        log(f"Ping exception for {ip}: {str(e)}")
        return None

def check_tls_http(ip, domain, port=443, timeout=3):
    """
    检查IP是否支持TLS握手并能返回有效的HTTP响应。
    返回 (True, response_time_ms) 或 (False, None)
    """
    start_time = time.time()
    sock = None
    ssock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((ip, port))
        
        context = ssl.create_default_context()
        # 由于是IP直连，证书域名不匹配，需关闭主机名验证和证书验证
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        
        # 传入 server_hostname 以支持 SNI (Server Name Indication)
        ssock = context.wrap_socket(sock, server_hostname=domain)
        
        request = f"HEAD / HTTP/1.1\r\nHost: {domain}\r\nUser-Agent: Kodi-DNS-Optimizer\r\nConnection: close\r\n\r\n"
        ssock.sendall(request.encode('utf-8'))
        
        response = ssock.recv(1024).decode('utf-8', errors='ignore')
        
        elapsed_time = (time.time() - start_time) * 1000
        
        # 只要收到了标准的 HTTP 响应头，即认为 TLS 和 HTTP 通路正常
        if response.startswith("HTTP/"):
            return True, elapsed_time
        return False, None
    except Exception:
        return False, None
    finally:
        if ssock:
            try: ssock.close()
            except: pass
        if sock:
            try: sock.close()
            except: pass

def find_best_ip(ips, domain):
    """对列表中的所有 IP 进行 Ping 和 TLS/HTTP 测试，返回最快且可用的那个"""
    best_ip = None
    best_time = float('inf')
    
    log(f"Starting ping and TLS/HTTP test for {len(ips)} IPs: {ips}")
    
    for ip in ips:
        # 1. Ping 测试
        ping_time = ping_ip(ip)
        if ping_time is None:
            log(f"Ping failed for {ip}, skipping TLS/HTTP check.")
            continue
            
        log(f"Ping result for {ip}: {ping_time:.2f}ms")
        
        # 2. TLS/HTTP 探测
        tls_ok, tls_time = check_tls_http(ip, domain)
        if not tls_ok:
            log(f"TLS/HTTP check failed for {ip}, skipping.")
            continue
            
        log(f"TLS/HTTP OK for {ip} (Response time: {tls_time:.2f}ms)")
        
        # 以 Ping 时间作为主要排序依据（Ping 更能反映网络基础延迟）
        if ping_time < best_time:
            best_time = ping_time
            best_ip = ip
            
    return best_ip, best_time

def read_hosts_file():
    if not os.path.exists(HOSTS_FILE):
        return []
    with open(HOSTS_FILE, 'r') as f:
        return f.readlines()

def write_hosts_file(lines):
    dir_name = os.path.dirname(HOSTS_FILE)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
    with open(HOSTS_FILE, 'w') as f:
        f.writelines(lines)

def get_first_host_ip(domain):
    """
    从 hosts 文件中获取指定域名的第一个匹配 IP。
    如果有多条记录，只返回最上面的一条。
    """
    lines = read_hosts_file()
    for line in lines:
        stripped_line = line.strip()
        parts = stripped_line.split()
        if len(parts) >= 2 and parts[-1] == domain:
            return parts[0]
    return None

def check_and_optimize_domain(domain):
    """
    针对单个域名的完整检查与优化流程。
    返回 True 如果修改了 hosts 文件，否则 False。
    """
    log(f"--- Processing Domain: {domain} ---")
    
    # 1. 检查现有 IP 性能
    current_ip = get_first_host_ip(domain)
    
    if current_ip:
        log(f"Found existing IP for {domain}: {current_ip}. Testing performance...")
        latency = ping_ip(current_ip)
        
        if latency is not None and latency <= PERFORMANCE_THRESHOLD_MS:
            log(f"Existing IP performance is GOOD ({latency:.2f}ms <= {PERFORMANCE_THRESHOLD_MS}ms). Skipping optimization for {domain}.")
            return False
        else:
            if latency is None:
                log(f"Existing IP {current_ip} is unreachable.")
            else:
                log(f"Existing IP performance is POOR ({latency:.2f}ms > {PERFORMANCE_THRESHOLD_MS}ms). Will optimize.")
    else:
        log(f"No existing entry found for {domain}. Will optimize.")

    # 2. 执行 DNS 解析和优化
    dns_ips = get_dns_ips(domain)
    
    if not dns_ips:
        log(f"No valid IPv4 IPs resolved for {domain}")
        return False
        
    unique_ips = list(set(dns_ips))
    # 传入 domain 以便进行 TLS/HTTP 探测
    best_new_ip, best_new_time = find_best_ip(unique_ips, domain)
    
    if best_new_ip is None:
        log(f"All new IPs for {domain} are unreachable or unmeasurable")
        return False

    log(f"Selected Best New IP for {domain}: {best_new_ip} ({best_new_time:.2f}ms)")

    # 3. 更新 Hosts 文件
    lines = read_hosts_file()
    target_line_index = -1
    current_ip_in_host = None
    
    for i, line in enumerate(lines):
        stripped_line = line.strip()
        parts = stripped_line.split()
        if len(parts) >= 2 and parts[-1] == domain:
            target_line_index = i
            current_ip_in_host = parts[0]
            break
    
    if target_line_index == -1:
        new_line = f"{best_new_ip} {domain}\n"
        lines.append(new_line)
        write_hosts_file(lines)
        log(f"Added new entry: {best_new_ip} {domain}")
        return True
    else:
        if current_ip_in_host == best_new_ip:
            log(f"IP unchanged for {domain}")
            return False
        
        old_time = ping_ip(current_ip_in_host)
        
        should_update = False
        if old_time is None:
            log(f"Old IP {current_ip_in_host} is unreachable, replacing with {best_new_ip}")
            should_update = True
        elif old_time >= (best_new_time * 1.3):
            log(f"Update! Old({old_time:.2f}ms) is significantly slower than New({best_new_time:.2f}ms)")
            should_update = True
        else:
            log(f"No update. Old({old_time:.2f}ms) is acceptable compared to New({best_new_time:.2f}ms)")
            
        if should_update:
            parts = lines[target_line_index].strip().split()
            parts[0] = best_new_ip
            lines[target_line_index] = " ".join(parts) + "\n"
            write_hosts_file(lines)
            return True
            
    return False

def main():
    log("Script started.")
    
    any_modified = False
    
    for domain in DOMAINS:
        if check_and_optimize_domain(domain):
            any_modified = True
            
    if any_modified:
        log("DNS optimization completed. Hosts file has been modified. Please restart Kodi manually for changes to take effect.")
    else:
        log("No modifications were made.")
            
if __name__ == '__main__':
    main()