import xbmc
import xbmcvfs
import re
import os

# 定义锁文件路径，使用 xbmcvfs 兼容 Kodi 19+
LOCK_FILE_PATH = os.path.join(xbmcvfs.translatePath('special://temp/'), 'informat_script.lock')

def is_already_running():
    """检查是否已有实例通过文件锁运行"""
    if os.path.exists(LOCK_FILE_PATH):
        try:
            with open(LOCK_FILE_PATH, 'r') as f:
                old_pid = int(f.read().strip())
            # os.kill(pid, 0) 不发送信号，仅检查进程是否存在
            os.kill(old_pid, 0)
            return True
        except (OSError, ValueError, ProcessLookupError):
            # 进程不存在或文件格式错误，说明是残留锁文件，清理它
            try:
                os.remove(LOCK_FILE_PATH)
            except Exception:
                pass
    return False

def create_lock():
    """创建锁文件并写入当前 PID"""
    try:
        with open(LOCK_FILE_PATH, 'w') as f:
            f.write(str(os.getpid()))
    except Exception as e:
        xbmc.log('[script.informat] Failed to create lock file: {}'.format(e), xbmc.LOGERROR)

def remove_lock():
    """删除锁文件"""
    try:
        if os.path.exists(LOCK_FILE_PATH):
            os.remove(LOCK_FILE_PATH)
    except Exception:
        pass

def get_drop_fps():
    """
    读取 /sys/class/video/fps_info 文件，
    提取 drop_fps: 后面的十六进制数字并转换为十进制整数。
    """
    try:
        with open('/sys/class/video/fps_info', 'r') as f:
            content = f.read()
            match = re.search(r'drop_fps:\s*(?:0x)?([0-9a-fA-F]+)', content, re.IGNORECASE)
            if match:
                hex_str = match.group(1)
                return int(hex_str, 16)
    except Exception:
        pass
    return 0

def main():
    # 1. 单实例检查
    if is_already_running():
        xbmc.log('[script.informat] Another instance is already running. Exiting.', xbmc.LOGINFO)
        return
    
    # 2. 创建锁
    create_lock()
    
    try:
        monitor = xbmc.Monitor()
        last_info_str = ""
        
        # 网络监控相关变量
        last_net_str = ""
        last_total_bytes = 0
        first_net_read = True
        
        # 启动时将之前的网络结果清零
        xbmc.executebuiltin('Skin.SetString(netmbps,0.0)')
        
        # 持续循环，直到 Kodi 请求退出或满足退出条件
        while not monitor.abortRequested():
            # 获取两个窗口的可见状态
            is_process_info_visible = xbmc.getCondVisibility('Window.IsVisible(playerprocessinfo)')
            is_video_osd_visible = xbmc.getCondVisibility('Window.IsVisible(videoosd)')
            
            # 退出条件：当两个窗口的值全部为“否”时，立即退出关闭脚本
            if not is_process_info_visible and not is_video_osd_visible:
                break
                
            # 执行条件：在 playerprocessinfo 或 videoosd 的值为“真”的前提下
            if is_process_info_visible or is_video_osd_visible:
                
                # --- 逻辑1：AML FPS 监控 ---
                try:
                    videofps_raw = xbmc.getInfoLabel('Player.Process(videofps)')
                    aa = round(float(videofps_raw)) if videofps_raw else 0
                    bb = get_drop_fps()
                    diff = aa - bb
                    current_info_str = f"{aa} | {bb} | {diff} fps"
                    
                    if current_info_str != last_info_str:
                        xbmc.executebuiltin(f'Skin.SetString(amlfps,{current_info_str})')
                        last_info_str = current_info_str
                except Exception as e:
                    xbmc.log('[script.informat] Error in FPS logic: {}'.format(e), xbmc.LOGERROR)

                # --- 逻辑2：网络流量监控 (MB/s) ---
                try:
                    current_total_bytes = 0
                    with open('/proc/net/dev', 'r') as f:
                        for line in f:
                            parts = line.split(':')
                            if len(parts) == 2:
                                iface = parts[0].strip()
                                # 匹配 eth* 和 wlan* 接口
                                if iface.startswith('eth') or iface.startswith('wlan'):
                                    stats = parts[1].split()
                                    if stats:
                                        # 提取第一个数字（接收字节数）
                                        current_total_bytes += int(stats[0])
                    
                    if first_net_read:
                        # 第一次读取只记录基准值，不计算差值
                        last_total_bytes = current_total_bytes
                        first_net_read = False
                    else:
                        bytes_diff = current_total_bytes - last_total_bytes
                        last_total_bytes = current_total_bytes
                        
                        # 防止计数器溢出或重置导致的负数
                        if bytes_diff < 0:
                            bytes_diff = 0
                            
                        # 转换为兆字节 (MB)，保留一位小数
                        mbps_val = bytes_diff / (1024.0 * 128.0)
                        current_net_str = f"{mbps_val:.1f}"
                        
                        if current_net_str != last_net_str:
                            xbmc.executebuiltin(f'Skin.SetString(netmbps,{current_net_str})')
                            last_net_str = current_net_str
                except Exception as e:
                    xbmc.log('[script.informat] Error in Network logic: {}'.format(e), xbmc.LOGERROR)
                    
            # 每秒读取一次，使用 waitForAbort 以优雅响应 Kodi 的退出信号
            if monitor.waitForAbort(1):
                break

    finally:
        # 3. 无论正常退出还是异常，都确保删除锁文件
        remove_lock()
        xbmc.log('[script.informat] Script finished and lock removed.', xbmc.LOGINFO)

if __name__ == '__main__':
    main()