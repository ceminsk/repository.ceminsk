import xbmc
import xbmcgui

def run_first_run_check():
    """
    检查是否为首次运行，并弹出提示窗口。
    """
    # 定义标题
    heading = "首次扫描媒体库提示"
    
    # 定义消息内容
    # 使用 \n 进行换行
    # 使用 [color green]...[/color] 进行颜色标记
    message = (
        "首次进入媒体库，请呼出侧边栏点击“[COLOR=green]添加文件夹扫描刮削[/COLOR]”开始扫描海报，以便开始建立你的媒体库。\n(首次点击会自动安装刮削插件，请等待。。。)\n"
        "\n选择“是”打开侧边栏，选择“否”返回页面。"
    )
    
    # 创建 Yes/No 对话框
    # xbmcgui.Dialog().yesno 返回 True (Yes) 或 False (No)
    dialog = xbmcgui.Dialog()
    result = dialog.yesno(heading, message)
    
    if not result:
        # 用户选择“否”
        # 执行 Skin.SetString(libfirstrun, 1)
        xbmc.executebuiltin("Skin.SetString(libfirstrun, 1)")
    else:
        # 用户选择“是”
        # 执行 Skin.SetString(libfirstrun, 1)
        xbmc.executebuiltin("Skin.SetString(libfirstrun, 1)")
        
        # 执行 SetFocus(43)
        # 注意：SetFocus 是窗口内的命令，确保当前活动窗口中存在 ID 为 43 的控件
        xbmc.executebuiltin("SetFocus(43)")

if __name__ == '__main__':
    run_first_run_check()