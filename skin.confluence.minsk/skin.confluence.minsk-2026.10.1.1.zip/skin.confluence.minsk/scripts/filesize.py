# -*- coding: utf-8 -*-
import xbmc
# ---- 日志脱敏（防止局域网/WebDAV 路径中的用户名密码明文写入日志）----
try:
    from logmask import sanitize_credentials
except Exception:  # 兜底：模块缺失时不影响脚本原有功能
    def sanitize_credentials(text):
        return text
def _masked_log(*args, **kwargs):
    """写日志前自动脱敏路径中的用户名密码。

    用 *args/**kwargs 转发，保证 level 等参数语义与 xbmc.log 完全一致
    （xbmc.log 的默认级别为 LOGDEBUG）。
    """
    try:
        if args:
            args = (sanitize_credentials(args[0]),) + args[1:]
        elif "msg" in kwargs:
            kwargs["msg"] = sanitize_credentials(kwargs["msg"])
    except Exception:
        pass
    xbmc.log(*args, **kwargs)


def _masked_print(*args, **kwargs):
    """print 同样会被 Kodi 转发到日志，输出前先脱敏。"""
    try:
        args = tuple(sanitize_credentials(a) for a in args)
    except Exception:
        pass
    print(*args, **kwargs)

import xbmcvfs
import re
import sys
import time
import urllib.parse 
import xml.etree.ElementTree as ET

# 单位换算常量
UNIT_GB = 1024 ** 3
UNIT_MB = 1024 ** 2
UNIT_TB = 1024 ** 4
LOG_TAG = "[FileInfo] "

# juku 播放路径前缀
JUKU_PLUGIN_PREFIX = "plugin://plugin.video.juku"

# shortpath 尾部的大小信息：由 embypath.py 追加，格式形如 "...文件名 49.15GB"
# 约束1：必须位于字符串末尾（其后不允许再有其他字符），避免命中路径中间如 "[24.74TB]" 的目录名
# 约束2：必须以空白分隔，保证与真实文件名区分开
# 约束3：单位仅接受 MB / GB / TB，且数值允许整数或小数
SIZE_TAIL_PATTERN = re.compile(r'\s(\d+(?:\.\d+)?)\s*(TB|GB|MB)\s*$', re.IGNORECASE)

# 用于从 shortpath 末尾剥离大小信息，还原出真实文件名（与 SIZE_TAIL_PATTERN 保持一致）
SIZE_SUFFIX_PATTERN = re.compile(r'\s*\d+(?:\.\d+)?\s*(?:TB|GB|MB)\s*$', re.IGNORECASE)

# 合理体积区间：单部电影 / 剧集文件一般在几百 MB ~ 200GB 之间
# 超出该区间的一律不认为是文件大小信息（多为目录名、集数编号等误命中），应走后续获取方式
MIN_PLAUSIBLE_SIZE_BYTES = 100 * UNIT_MB
MAX_PLAUSIBLE_SIZE_BYTES = 200 * UNIT_GB

# 单位文本 -> 字节数
SIZE_UNIT_BYTES = {
    'TB': UNIT_TB,
    'GB': UNIT_GB,
    'MB': UNIT_MB,
}

def log_info(msg):
    _masked_log(sanitize_credentials(LOG_TAG + str(msg)), level=xbmc.LOGINFO)

def log_error(msg):
    _masked_log(sanitize_credentials(LOG_TAG + str(msg)), level=xbmc.LOGERROR)

def log_warning(msg):
    _masked_log(sanitize_credentials(LOG_TAG + str(msg)), level=xbmc.LOGWARNING)

def split_dav_host_path(url):
    """把 dav URL 拆成 (前缀, host_part, path_part)。

    host_part 保留原始书写形式（含端口、可能的尾部斜杠），
    以便原样拼接回去，不破坏 Kodi 构造的 URL 结构。

    兼容 "host/:port/path" 这种端口位于斜杠之后的变体：
    此时端口会被并入 host_part，路径从端口之后开始。
    """
    rest = url[6:]
    unc_prefix = rest.startswith("//")
    if unc_prefix:
        rest = rest[2:]

    # 剥离凭据（若已含 user:pass@）
    at_index = rest.find('@')
    if at_index != -1:
        rest = rest[at_index + 1:]

    slash_index = rest.find('/')
    if slash_index == -1:
        host_part, path_part = rest, "/"
    else:
        host_part, path_part = rest[:slash_index], rest[slash_index:]

    # 变体：端口位于斜杠之后，形如 'localhost' + '/:19798/dav/...'
    # （Kodi 21 的 UNC 写法会把端口放在主机名后的斜杠后面）
    if path_part.startswith('/:'):
        colon_index = path_part.find('/', 2)
        if colon_index == -1:
            host_part = host_part + path_part[1:]
            path_part = "/"
        else:
            host_part = host_part + path_part[1:colon_index]
            path_part = path_part[colon_index:]

    return ("//" if unc_prefix else ""), host_part, path_part


def parse_dav_url_components(url):
    """解析 DAV URL 组件: host, port, path

    兼容 Kodi 的多种 dav:// 形态：
      1) 标准形式   dav://host:port/path
      2) UNC 形式   dav:////host:port/path   （dav:// 后接 UNC，Kodi 21 实际使用）
      3) UNC 变体   dav:////host/:port/path  （端口在斜杠之后）
      4) 含凭据形式 dav://user:pass@host:port/path

    返回 (host, port, path)；host 不含凭据部分。
    """
    try:
        if not url.startswith("dav://"):
            return None, None, None

        _prefix, host_part, path_part = split_dav_host_path(url)

        host = host_part
        port = None
        if ':' in host_part:
            host, _colon, port = host_part.partition(':')

        return host, port, path_part
    except Exception:
        return None, None, None

def get_webdav_auth_from_passwords_xml(target_url):
    """
    从 passwords.xml 中查找匹配的 WebDAV 凭据
    支持忽略端口号的智能匹配
    """
    passwords_path = xbmcvfs.translatePath('special://userdata/passwords.xml')
    
    if not xbmcvfs.exists(passwords_path):
        return None, None
        
    target_host, target_port, target_path = parse_dav_url_components(target_url)
    if not target_host:
        return None, None
        
    try:
        f = xbmcvfs.File(passwords_path, 'r')
        content = f.read()
        f.close()
        
        root = ET.fromstring(content)
        best_match = None
        
        for path_node in root.findall('path'):
            from_node = path_node.find('from')
            to_node = path_node.find('to')
            
            if from_node is not None and to_node.text:
                from_path = from_node.text.strip()
                to_path = to_node.text.strip()
                
                if not from_path.startswith("dav://"):
                    continue
                    
                conf_host, conf_port, conf_path = parse_dav_url_components(from_path)
                if not conf_host:
                    continue
                
                # 匹配逻辑：主机名相同 且 配置路径是目标路径的前缀
                if conf_host == target_host and (target_path.startswith(conf_path) if conf_path else True):
                    # 优先选择端口一致的，其次选择无端口配置的
                    if conf_port == target_port or conf_port is None:
                        best_match = to_path
                        break
                    elif best_match is None:
                        best_match = to_path
                        
        if best_match:
            # 提取凭据但不记录明文
            if '@' in best_match:
                protocol_end = best_match.find('://')
                if protocol_end != -1:
                    auth_and_host_part = best_match[protocol_end+3:]
                    # 用最后一个 @ 分割：主机在前、凭据在后，
                    # 密码若含 @（已编码）也能正确处理
                    at_index = auth_and_host_part.rfind('@')
                    if at_index != -1:
                        auth_str = auth_and_host_part[:at_index]
                        if ':' in auth_str:
                            user, pwd = auth_str.split(':', 1)
                            # URL 解码
                            user = urllib.parse.unquote(user)
                            pwd = urllib.parse.unquote(pwd)
                            return user, pwd
                            
    except Exception as e:
        log_error(f"解析 passwords.xml 出错: {str(e)}")
        
    return None, None

def encode_dav_path_safely(path_part):
    """安全编码 dav 路径，避免对已编码内容二次编码。

    Kodi 传回的路径中，中文等字符已经是 %XX 形式（如 %E7%8B%AE = 狮），
    若再整体 quote() 一次会变成 %25E7%258B%25AE，
    服务器会去找字面量 "%E7%8B%AE" 目录，导致 404。

    这里改为"先解码再编码"：已编码的内容解码成原文后重新编码一次，
    结果与原始路径一致；对未编码的原始字符也能正确转义。
    """
    if not path_part:
        return path_part
    try:
        decoded = urllib.parse.unquote(path_part)
        # 只保留 / 与常见路径安全字符，其余全部编码
        return urllib.parse.quote(decoded, safe='/:')
    except Exception:
        return path_part


def fix_dav_url(url):
    """修复 WebDAV URL：注入凭据并规范化路径编码。

    重要说明：
    Kodi 自身通过 passwords.xml 的 from->to 映射会自动补全凭据，
    因此这里的"注入凭据"仅作兜底；真正必须修正的是**路径不能被二次编码**。
    """
    if not url.startswith("dav://"):
        return url

    try:
        prefix, host_part, path_part = split_dav_host_path(url)

        # 路径规范化：解码后再编码，避免二次编码
        encoded_path = encode_dav_path_safely(path_part)

        # 如果已有认证信息，直接返回
        if '@' in url[6:]:
            final_url = f"dav://{prefix}{host_part}{encoded_path}"
            log_info(f"🔧 URL已存在认证，规范化路径编码: {final_url[:60]}...")
            return final_url

        # 获取凭据
        user, pwd = get_webdav_auth_from_passwords_xml(url)

        if user is None or pwd is None:
            log_warning("⚠️ 未找到凭据，尝试匿名访问")
            return f"dav://{prefix}{host_part}{encoded_path}"

        # 注入凭据
        user_encoded = urllib.parse.quote(user, safe='')
        pass_encoded = urllib.parse.quote(pwd, safe='')

        final_url = f"dav://{user_encoded}:{pass_encoded}@{prefix}{host_part}{encoded_path}"

        # 日志脱敏：不显示密码
        log_info(f"🔧 URL修复完成: dav://{user_encoded}:***@{prefix}{host_part}{encoded_path[:60]}...")
        return final_url

    except Exception as e:
        log_error(f"URL修复失败: {str(e)}")
        return url

def get_directory_total_size_by_xbmcvfs(dir_path):
    """递归计算文件夹总大小"""
    total_size = 0
    dir_path = dir_path.rstrip("/\\").strip()
    try:
        dirs, files = xbmcvfs.listdir(dir_path)
    except Exception as e:
        log_warning(f"无法读取目录: {dir_path}, 错误: {str(e)}")
        return total_size

    for file_name in files:
        file_path = f"{dir_path}\\{file_name}"
        try:
            f = xbmcvfs.File(file_path)
            file_size = f.size()
            f.close()
            if file_size > 0:
                total_size += file_size
        except:
            continue

    for sub_dir in dirs:
        sub_dir_path = f"{dir_path}\\{sub_dir}"
        total_size += get_directory_total_size_by_xbmcvfs(sub_dir_path)
    return total_size

def build_dav_url_candidates(url):
    """构造 dav 路径的候选访问 URL（按优先级排列）。

    Kodi 已经会把 Player.FilenameAndPath 构造成可直接访问的 URL，
    并通过 passwords.xml 的 from->to 映射自动补全凭据，
    因此【原始 URL 本身就是最可靠的首选】。

    这里只在其不可用时，依次尝试若干等价形态作为兜底，
    避免因手工拆分/编码破坏 URL 结构而导致 404。
    """
    candidates = []
    seen = set()

    def _add(u):
        if u and u not in seen:
            seen.add(u)
            candidates.append(u)

    # 1) 原样 —— Kodi 内部会自行注入凭据
    _add(url)

    # 2) 规范化路径编码（解码后再编码），不注入凭据
    try:
        prefix, host_part, path_part = split_dav_host_path(url)
        _add(f"dav://{prefix}{host_part}{encode_dav_path_safely(path_part)}")
    except Exception:
        pass

    # 3) 注入凭据（仅当前两种都不行时的兜底）
    try:
        fixed = fix_dav_url(url)
        _add(fixed)
    except Exception:
        pass

    # 4) 注入凭据 + 规范化编码
    try:
        prefix, host_part, path_part = split_dav_host_path(url)
        user, pwd = get_webdav_auth_from_passwords_xml(url)
        if user and pwd:
            u_enc = urllib.parse.quote(user, safe='')
            p_enc = urllib.parse.quote(pwd, safe='')
            _add(f"dav://{u_enc}:{p_enc}@{prefix}{host_part}"
                 f"{encode_dav_path_safely(path_part)}")
    except Exception:
        pass

    return candidates


def get_file_size_by_xbmcvfs(file_path):
    """获取单个文件大小"""
    file_size = 0

    original_path = file_path

    if file_path.lower().startswith("dav://"):
        candidates = build_dav_url_candidates(file_path)
    else:
        candidates = [file_path]

    # 依次尝试候选 URL，取第一个能成功读取的
    last_error = ""
    for candidate in candidates:
        log_info(f"📂 尝试访问: {candidate[:80]}...")

        try:
            exists = xbmcvfs.exists(candidate)
        except Exception as e:
            last_error = str(e)
            exists = False

        log_info(f"🔍 xbmcvfs.exists 结果: {exists}")

        if not exists:
            continue

        try:
            f = xbmcvfs.File(candidate)
            file_size = f.size()
            f.close()
            log_info(f"✅ 成功获取文件大小: {file_size} bytes")
            return file_size
        except Exception as e:
            last_error = str(e)
            log_error(f"❌ 读取文件失败: {candidate}, 异常类型: {type(e).__name__}, 详情: {str(e)}")
            continue

    log_warning(f"❌ 文件不存在或无法访问: {original_path}"
                + (f" (最后错误: {last_error})" if last_error else ""))
    return 0

def format_file_size(size_bytes):
    """格式化文件大小"""
    if size_bytes >= UNIT_GB:
        size = round(size_bytes / UNIT_GB, 2)
        return f"{size}GB"
    else:
        size = round(size_bytes / UNIT_MB, 2)
        return f"{size}MB"

def get_url_param(url_string, param_name):
    """从查询字符串中提取指定参数的值（取最左侧一次出现），未找到返回 ""。"""
    if not url_string:
        return ""

    match = re.search(
        r'(?:^|[?&])' + re.escape(param_name) + r'=([^&]*)',
        url_string,
        re.IGNORECASE
    )
    if not match:
        return ""

    return match.group(1).strip()

def is_juku_path(path_string):
    """判断路径是否为 juku 播放路径（不区分大小写）"""
    if not path_string:
        return False

    stripped = path_string.strip().lower()
    if not stripped.startswith(JUKU_PLUGIN_PREFIX):
        return False

    # 前缀之后必须是 "/"、"?" 或字符串结束，避免误匹配 plugin.video.juku2 等相似插件ID
    next_char = stripped[len(JUKU_PLUGIN_PREFIX):len(JUKU_PLUGIN_PREFIX) + 1]
    return next_char in ('', '/', '?')

def build_juku_candidates(path_string):
    """
    生成 juku 路径的候选串：原串 + 整体解码一次的串。
    用于兼容路径被整体 URL 编码的情况。
    """
    candidates = [path_string.strip()]

    if '%' in path_string:
        once_decoded = urllib.parse.unquote(path_string)
        if once_decoded != candidates[0]:
            candidates.append(once_decoded)

    return candidates

def parse_size_bytes(raw_size_value):
    """
    解析字节数字文本为 int。
    仅接受纯数字（允许千分位分隔），非法或非正数返回 0。
    """
    if not raw_size_value:
        return 0

    size_text = raw_size_value.strip()

    if not re.fullmatch(r'\d+(?:[,\s\u00a0]\d{3})*', size_text):
        return 0

    try:
        size_bytes = int(re.sub(r'[,\s\u00a0]', '', size_text))
    except (ValueError, TypeError):
        return 0

    return size_bytes if size_bytes > 0 else 0

def extract_size_from_shortpath(shortpath_value):
    """
    从 shortpath 末尾提取 embypath.py 追加的大小文本（形如 "巨库源-网盘-文件名 49.15GB"）。
    仅接受位于字符串末尾、以空白分隔、且换算后落在 100MB ~ 200GB 合理区间内的文本，
    避免把目录名中的 "[24.74TB]" 等内容误判为文件大小。
    返回 (size_text, size_bytes)，无法提取时返回 (None, 0)。
    """
    if not shortpath_value:
        return None, 0

    value = shortpath_value.strip()

    # 只认末尾出现的大小信息（锚定 $，路径中间的相似文本不会命中）
    match = SIZE_TAIL_PATTERN.search(value)
    if not match:
        return None, 0

    number_text, unit_text = match.group(1), match.group(2)
    unit = unit_text.upper()

    try:
        size_bytes = int(float(number_text) * SIZE_UNIT_BYTES[unit])
    except (ValueError, TypeError, KeyError):
        return None, 0

    # 合理性校验：超出单部电影/剧集的体积区间，视为误命中，交由后续方式获取
    if not (MIN_PLAUSIBLE_SIZE_BYTES <= size_bytes <= MAX_PLAUSIBLE_SIZE_BYTES):
        log_warning(
            f"⚠️ shortpath 尾部候选大小不合理，忽略: {number_text}{unit} "
            f"(允许区间 {MIN_PLAUSIBLE_SIZE_BYTES // UNIT_MB}MB ~ "
            f"{MAX_PLAUSIBLE_SIZE_BYTES // UNIT_GB}GB)"
        )
        return None, 0

    return f"{number_text}{unit}", size_bytes

def extract_size_from_juku_path(path_value):
    """
    若路径以 plugin://plugin.video.juku 开头，则提取 file_size 字段，
    将字节数换算为 GB 并保留两位小数。
    返回 (size_text, size_bytes)，不适用或无效时返回 (None, 0)。
    """
    if not is_juku_path(path_value):
        return None, 0

    for candidate in build_juku_candidates(path_value):
        raw_size = get_url_param(candidate, 'file_size')
        size_bytes = parse_size_bytes(raw_size)
        if size_bytes > 0:
            size_gb = size_bytes / UNIT_GB
            return f"{size_gb:.2f}GB", size_bytes

    return None, 0

def resolve_size_from_metadata(shortpath_value, player_path):
    """
    按优先级解析文件大小：
      1) shortpath 中已带单位的大小信息
      2) FileNameAndPath 为 juku 路径时，提取其中的 file_size
    均无法获取时返回 (None, 0)，由调用方回退到原有探测逻辑。
    """
    size_text, size_bytes = extract_size_from_shortpath(shortpath_value)
    if size_text:
        log_info(f"✅ 从 shortpath 获取大小: {size_text}")
        return size_text, size_bytes

    size_text, size_bytes = extract_size_from_juku_path(player_path)
    if size_text:
        log_info(f"✅ 从 juku 路径获取大小: {size_text}")
        return size_text, size_bytes

    return None, 0

def get_file_basename(path):
    path = path.replace("\\", "/")
    return path.split("/")[-1] if "/" in path else path

def get_file_dirname(path):
    path = path.replace("\\", "/").rstrip("/")
    return path.rsplit("/", 1)[0] if "/" in path else ""

def get_upper_file_ext_custom(file_name):
    keep_4_char = ["M2TS", "WEBM", "AVCH", "M4V"]
    if "." in file_name:
        ext = file_name.split(".")[-1].strip().upper()
        if ext in keep_4_char:
            return ext
        else:
            return ext[:3]
    return ""

def standardize_filesize_str(s):
    if not s:
        return ""
    while s:
        first_char_valid = s[0].strip() and s[0] in "0123456789未"
        if not first_char_valid:
            s = s[1:]
        else:
            break
    while s:
        last_char_valid = s[-1].strip() and s[-1] in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ盘"
        if not last_char_valid:
            s = s[:-1]
        else:
            break
    return s.strip()

def read_strm_real_path(strm_file_path):
    real_video_path = ""
    try:
        strm_file = xbmcvfs.File(strm_file_path, 'r')
        real_video_path = strm_file.read().strip()
        strm_file.close()
    except Exception:
        pass
    return real_video_path

def wait_for_shortpath():
    start_time = time.time()
    timeout = 30 
    while True:
        shortpath_value = xbmc.getInfoLabel("Skin.String(shortpath)").strip()
        if shortpath_value:
            return shortpath_value
        if time.time() - start_time > timeout:
             return ""
        xbmc.sleep(500)

def wait_for_chapter_count(min_count=8, timeout_sec=60):
    start_time = time.time()
    while True:
        chapter_count_str = xbmc.getInfoLabel("Player.ChapterCount").strip()
        try:
            chapter_count = int(chapter_count_str) if chapter_count_str else 0
        except ValueError:
            chapter_count = 0
            
        if chapter_count >= min_count:
            return
            
        if time.time() - start_time > timeout_sec:
            return
            
        xbmc.sleep(500)

def get_player_duration_in_seconds():
    has_menu = xbmc.getCondVisibility("VideoPlayer.HasMenu")
    if has_menu:
        wait_for_chapter_count(8)
        
    duration_str = xbmc.getInfoLabel("Player.Duration").strip()
    if not duration_str:
        return 0
    
    try:
        parts = duration_str.split(':')
        if len(parts) == 3:
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(parts[2])
            return hours * 3600 + minutes * 60 + seconds
        elif len(parts) == 2:
            minutes = int(parts[0])
            seconds = int(parts[1])
            return minutes * 60 + seconds
        else:
            return int(duration_str)
    except:
        return 0

def calculate_bitrate(file_size_mb, duration_seconds):
    if duration_seconds <= 0:
        return 0
    bitrate = (file_size_mb * 8) / duration_seconds
    return round(bitrate, 2)

def main():
    use_shortpath_force = False
    need_delay = False

    if 'detail' in sys.argv:
        use_shortpath_force = True
        
    if 'delay' in sys.argv:
        need_delay = True

    if need_delay:
        while True:
            play_time_ss = xbmc.getInfoLabel("Player.Time(ss)")
            try:
                play_seconds = float(play_time_ss) if play_time_ss else 0.0
            except:
                play_seconds = 0.0
            if play_seconds > 1.0:
                break
            xbmc.sleep(1000)

    file_path = ""
    shortpath_value = ""
    player_path = xbmc.getInfoLabel("Player.FileNameAndPath").strip()
    
    if use_shortpath_force:
        file_path = wait_for_shortpath()
        shortpath_value = file_path
    else:
        if player_path.lower().endswith(".mpls"):
            file_path = wait_for_shortpath()
            shortpath_value = file_path
        else:
            file_path = player_path
            
        if not file_path:
             file_path = wait_for_shortpath()
             shortpath_value = file_path

        # 非强制模式下 shortpath 可能已由 embypath.py 写入，单独读取一次（非阻塞）
        if not shortpath_value:
            shortpath_value = xbmc.getInfoLabel("Skin.String(shortpath)").strip()

    if not file_path:
        xbmc.executebuiltin('Skin.SetString(filesize, "")')
        xbmc.executebuiltin('Skin.SetString(totalbitrate, "")')
        return

    if file_path.lower().endswith(".strm"):
        real_path = read_strm_real_path(file_path)
        if real_path:
            file_path = real_path

    # 【新增】大小来源优先级：shortpath 中的大小 > juku 路径的 file_size > 原生探测
    meta_size_text, meta_size_bytes = resolve_size_from_metadata(shortpath_value, player_path)

    # 计算用于取扩展名的名称：剥离 shortpath 尾部大小信息 / 解析 juku 的 file_name
    name_source = file_path
    if is_juku_path(file_path):
        for candidate in build_juku_candidates(file_path):
            juku_file_name = get_url_param(candidate, 'file_name')
            if juku_file_name:
                name_source = juku_file_name
                break
    elif meta_size_text and file_path == shortpath_value:
        name_source = SIZE_SUFFIX_PATTERN.sub('', file_path).strip()

    raw_filename = get_file_basename(name_source)
    file_name = raw_filename.lower()
    file_dir = get_file_dirname(file_path)
    final_size = 0
    filesize_value = ""

    if meta_size_text:
        # 元数据已提供大小，直接采用
        final_size = meta_size_bytes
        size_label = "BDMV原盘文件夹" if file_name == "index.bdmv" else get_upper_file_ext_custom(raw_filename)
        filesize_value = f"{meta_size_text} - {size_label}"
    elif file_name != "index.bdmv":
        file_ext = get_upper_file_ext_custom(raw_filename)
        final_size = get_file_size_by_xbmcvfs(file_path)
        if final_size > 0:
            size_text = format_file_size(final_size)
            filesize_value = f"{size_text} - {file_ext}"
        else:
            filesize_value = f"未知大小 - {file_ext}"
    else:
        file_type = "BDMV原盘文件夹"
        stream_folder = f"{file_dir}\\STREAM"
        final_size = get_directory_total_size_by_xbmcvfs(stream_folder)
        if final_size == 0:
            stream_folder = f"{file_dir}\\stream"
            final_size = get_directory_total_size_by_xbmcvfs(stream_folder)
        if final_size > 0:
            size_text = format_file_size(final_size)
            filesize_value = f"{size_text} - {file_type}"
        else:
            filesize_value = f"未知大小 - {file_type}"

    filesize_standard = standardize_filesize_str(filesize_value)
    xbmc.executebuiltin(f'Skin.SetString(filesize, "{filesize_standard}")')

    duration_seconds = get_player_duration_in_seconds()
    
    if "未知" in filesize_standard or final_size <= 0:
        xbmc.executebuiltin('Skin.SetString(totalbitrate, "")')
    else:
        file_size_mb = final_size / UNIT_MB
        bitrate = calculate_bitrate(file_size_mb, duration_seconds)
        xbmc.executebuiltin(f'Skin.SetString(totalbitrate, "{bitrate}")')

    sys.exit()

if __name__ == "__main__":
    main()